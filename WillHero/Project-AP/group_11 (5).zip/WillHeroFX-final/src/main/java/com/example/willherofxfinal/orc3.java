package com.example.willherofxfinal;

public class orc3 extends orc {

    orc3(long id, String type, float x, float y, float jumpSpeed, float life, int onDeathCoins, float size) {
        super(id, type, x, y, jumpSpeed, life, onDeathCoins, size);
    }
    public Boolean orc1collision(hero h, Coordinate c)
    {
        return super.collision(h,c);
    }
}