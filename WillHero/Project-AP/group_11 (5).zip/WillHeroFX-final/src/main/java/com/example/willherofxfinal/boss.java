package com.example.willherofxfinal;

public class boss extends orc{

    boss(long id, String type, float x, float y, float jumpSpeed, float life, int onDeathCoins, float size ){
        super(id,type,x,y,jumpSpeed,life,onDeathCoins,size);

    }
}
