package com.example.willherofxfinal;

public class treasure extends gameObjects {


    public static gameObjects getInstance(String g, long id, String type, float x, float y, float xspeed)
    {

        if(!instances.containsKey(g))
        {
            instances.put(g, new treasure(id, type, x, y,xspeed));
        }
        return instances.get(g);
    }
     treasure(long id, String type, float x, float y, float xspeed)
    {
        super(id,type,x,y);
    }

    public boolean collision(hero h)
    {
        if(h.getBoundsInParent().intersects(this.getBoundsInParent()))
        {
            return true;
        }

        return false;

    }

    @Override
    public boolean collision(hero h, Coordinate c) {
        return false;
    }
}
