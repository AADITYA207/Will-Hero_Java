package com.example.willherofxfinal;

public interface fire {
    public void fire();
}
