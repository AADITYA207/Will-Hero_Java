package com.example.willherofxfinal;

public class weapchest extends treasure {

    weapons w;
    hero h;

    weapchest(long id, String type, float x, float y, float xspeed) {
        super(id, type, x, y, xspeed);
    }

    public boolean collision(hero h)
    {
        return super.collision(h);
    }

    public void setWeapon(helmet h, hero h1)
    {
        if(this.collision(h1)==true)
        {
            h.setWeapon(h,h1);
        }
    }


}
