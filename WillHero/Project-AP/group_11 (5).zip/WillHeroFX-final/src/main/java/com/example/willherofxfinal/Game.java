package com.example.willherofxfinal;

import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class Game implements Serializable {

    hero h;
    ArrayList<gameObjects> orc = new ArrayList<>();
    ArrayList<gameObjects> islands = new ArrayList<>();
    ArrayList<gameObjects> treasure = new ArrayList<>();
    ArrayList<gameObjects> obstacle = new ArrayList<>();
    ArrayList<gameObjects> coins = new ArrayList<>();
    ArrayList<gameObjects> weapons = new ArrayList<>();
    long high_score;
    user User;
    ObjectOutputStream out;
    ObjectOutputStream in;
    long SERIALVERSIONID;


    public void serialize() throws ClassNotFoundException, IOException
    {

    }
    public void deserialize() throws ClassNotFoundException, IOException{

    }
    public void entry()
    {

    }
    public void loadgame()
    {

    }
    public void close()
    {

    }
    public void save()
    {

    }
    public void leaderb()
    {

    }
    public void showins()
    {

    }
}

