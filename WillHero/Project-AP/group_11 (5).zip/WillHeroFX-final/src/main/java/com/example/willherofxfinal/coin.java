package com.example.willherofxfinal;

public class coin extends gameObjects{

    public static gameObjects getInstance(String g, long id, String type, float x, float y )
    {

        if(!instances.containsKey(g))
        {
            instances.put(g, new coin(id, type, x, y));
        }
        return instances.get(g);
    }

     coin(long id, String type, float x, float y) {


        super(id, type, x, y);
    }

    @Override
    public boolean collision(hero h, Coordinate c) {
        return false;
    }

    public void upd_coins(hero h)
    {
        int x = h.getCoinsCollected();
        x=x+1;
        h.setCoinsCollected(x);
    }
}
