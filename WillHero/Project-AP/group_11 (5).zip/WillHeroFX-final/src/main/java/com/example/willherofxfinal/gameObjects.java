package com.example.willherofxfinal;

import javafx.scene.shape.Rectangle;

import java.util.HashMap;
import java.util.Map;

public abstract class gameObjects extends Rectangle {

    protected static Map<String,gameObjects> instances = new HashMap<String,gameObjects>();
    private long id;
    private String type;
    private Coordinate coord;


    public gameObjects(long id, String type, float x, float y){
        this.coord.x=x;
        this.coord.y=y;
        this.type=type;
        this.id=id;
        setTranslateX(x);
        setTranslateY(y);
    }
    public Coordinate getCoord(){
        return this.coord;
    }
    public void setCoord(float x, float y){
        this.coord.x=x;
        this.coord.y=y;
    }
    public Map getInstances()
    {
        return instances;
    }
    public String getType(){
        return this.type;
    }
    public long getObjId(){
        return this.id;
    }
    public abstract boolean collision(hero h,Coordinate c);
    public void jump(){}

}
