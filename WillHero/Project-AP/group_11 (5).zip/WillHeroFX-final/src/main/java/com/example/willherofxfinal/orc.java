package com.example.willherofxfinal;

public class orc extends gameObjects implements jump{
    private float jumpSpeed;
    private float life;
    private int onDeathCoins;
    private float size;

    public static gameObjects getInstance(String g, long id, String type, float x, float y, float jumpSpeed, float life, int onDeathCoins, float size )
    {

        if(!instances.containsKey(g))
        {
            instances.put(g, new orc(id, type, x, y,jumpSpeed,life,onDeathCoins,size));
        }
        return instances.get(g);
    }

     orc(long id, String type, float x, float y, float jumpSpeed, float life, int onDeathCoins, float size ){
        super(id,type,x,y);
        this.onDeathCoins=onDeathCoins;
        this.life=life;
        this.size=size;
        this.jumpSpeed=jumpSpeed;
    }
    public void upd_coins(){

    }
    public void fall(){

    }
    public float getJumpSpeed(){
        return  this.jumpSpeed;
    }
    public float getLife(){
        return  this.life;
    }
    public float getSize(){
        return  this.size;
    }
    public int getOnDeathCoins(){
        return this.onDeathCoins;
    }
    public void setLife(float l) {this.life=l;}

    @Override
    public boolean collision(hero h, Coordinate c) {
        Coordinate x =h.getCoord();
        if(x.x==c.x && x.y == x.y)
        {
            return true;
        }
        return false;
    }

    public void jump()
    {
        Coordinate c = this.getCoord();
        c.y+=10;
        this.setCoord(c.x,c.y);
        c.y-=10;
        this.setCoord(c.x,c.y);
    }

}