
package com.example.willherofxfinal;

import javafx.animation.*;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.*;
import javafx.scene.control.*;
import javafx.scene.effect.ColorAdjust;
import javafx.scene.effect.Light;
import javafx.scene.effect.Lighting;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Path;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.io.*;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.ResourceBundle;
import java.util.stream.IntStream;


public class controller implements Initializable, Serializable {


    private Stage stage;
    private Stage stage1;
    private Scene scene;
    private Parent root;
    private AnchorPane anchorPane;
    //boolean respawn_check=false;
    int health=500;
    double progress=0;
    @FXML
    private Label cntrlabel;
    @FXML
    private Button winner;
    @FXML
    private Label maxscore_label;
    @FXML
    private VBox rect;
    @FXML
    private HBox inrect;
    @FXML
    private HBox respbox;
    @FXML
    private VBox respvbox;
    //@FXML

    //private AnchorPane pausepane;
    @FXML
    private HBox layoutbox;
    @FXML
    private ImageView layoutaxe;
    @FXML
    private ImageView rspn1;
    @FXML
    private ImageView save;
    @FXML
    private ImageView load;
    @FXML
    private ImageView ryes;
    @FXML
    private ImageView rno;
    @FXML
    private ImageView resume1;
    @FXML
    private ImageView one_save;
    @FXML
    private ImageView two_save;
    @FXML
    private ImageView one_load;
    @FXML
    private ImageView two_load;
    @FXML
    private ImageView marble1;
    @FXML
    private ImageView marble2;
    @FXML
    private ImageView marble3;
    @FXML
    private ImageView layoutfire;
    @FXML
    private ImageView layoutasaxe;
    @FXML
    private Text axetext;
    @FXML
    private Text firetext;
    @FXML
    private ImageView cntrimg;
    @FXML
    private ImageView heart;
    @FXML
    private ImageView heartlabel;
    @FXML
    private ImageView chkpnt1;
    @FXML
    private ImageView chkpnt2;
    @FXML
    private ImageView chkpnt3;
    @FXML
    private ImageView chkpnt4;
    @FXML
    private ImageView spawnchk;
    @FXML
    private ImageView asgaxe;
    @FXML
    private ImageView menuimg;
    @FXML
    private ImageView pauseimg;
    @FXML
    private ImageView sky;
    @FXML
    private ImageView thraxe;
    @FXML
    private ImageView thraxe1;
    @FXML
    private ImageView thraxe11;
    @FXML
    private ImageView thraxe12;
@FXML
private ImageView chest12;
    @FXML
    private Label proglabel;

    @FXML
    private ProgressBar progbar;
    @FXML
    private ImageView abyss;
    @FXML
    private Button deser;
    @FXML
    private ImageView heroimg;
    @FXML
    private ImageView redorc;
    @FXML
    private ImageView redorc1;
    @FXML
    private ImageView redorc2;
    @FXML
    private ImageView redorc3;
    @FXML
    private ImageView redorc4;
    @FXML
    private ImageView redorc5;
    @FXML
    private ImageView greenorc;
    @FXML
    private ImageView boss;
    @FXML
    private ImageView greenorc2;
    @FXML
    private ImageView greenorc3;
    @FXML
    private ImageView greenorc4;
    @FXML
    private ImageView isl1;
    @FXML
    private ImageView isl2;
    @FXML
    private ImageView isl3;
    @FXML
    private ImageView isl4;
    @FXML
    private ImageView isl5;
    @FXML
    private ImageView isl53;
    @FXML
    private ImageView isl531;
    @FXML
    private ImageView isl51;
    @FXML
    private ImageView isl52;
    @FXML
    private ImageView isl55;
    @FXML
    private ImageView isl54;

    @FXML
    private ImageView isl6;
    @FXML
    private ImageView isl7;
    @FXML
    private ImageView isl71;
    @FXML
    private ImageView isl72;
    @FXML
    private ImageView isl73;
    @FXML
    private ImageView isl74;
    @FXML
    private ImageView isl75;
    @FXML
    private ImageView isl76;

    @FXML
    private ImageView chest1;
    @FXML
    private ImageView chest2;
    @FXML
    private ImageView chest3;
    @FXML
    private ImageView chest4;
    @FXML
    private ImageView chest5;
    @FXML
    private ImageView chest6;
    @FXML
    private ImageView chest7;
    @FXML
    private ImageView chest8;
    @FXML
    private ImageView chest9;
    @FXML
    private ImageView chest10;
    @FXML
    private ImageView chest11;
    @FXML
    private ImageView chest13;
    @FXML
    private ImageView tnt1;
    @FXML
    private ImageView tnt2;
    @FXML
    private ImageView tnt3;
    @FXML
    private ImageView tnt4;
    @FXML
    private ImageView tnt5;
    @FXML
    private ImageView tnt6;
    @FXML
    private ImageView tnt7;
    @FXML
    private ImageView tnt8;
    @FXML
    private ImageView tnt9;
    @FXML
    private ImageView tnt10;
    @FXML
    private ImageView tnt11;
    @FXML
    private ImageView tnt12;
    @FXML
    private ImageView tnt13;
    @FXML
    private ImageView tnt14;

    @FXML
    private ImageView coin;
    @FXML
    private ImageView isl8;
    @FXML
    private ImageView isl9;
    @FXML
    private ImageView isl91;
    @FXML
    private ImageView isl911;
    @FXML
    private ImageView coin1;
    @FXML
    private ImageView coin2;
    @FXML
    private ImageView coin3;
    @FXML
    private ImageView coin4;
    @FXML
    private ImageView coin5;
    @FXML
    private ImageView coin6;
    @FXML
    private ImageView coin7;
    @FXML
    private ImageView coin8;
    @FXML
    private ImageView coin9;
    @FXML
    private ImageView brick1;
    @FXML
    private ImageView brick2;
    @FXML
    private ImageView brick3;
    @FXML
    private ImageView brick4;
    @FXML
    private ImageView brick5;
    @FXML
    private ImageView brick6;
    @FXML
    private ImageView brick7;
    @FXML
    private ImageView brick11;
    @FXML
    private ImageView brick21;
    @FXML
    private ImageView brick31;
    @FXML
    private ImageView brick41;
    @FXML
    private ImageView brick51;
    @FXML
    private ImageView brick52;
    @FXML
    private ImageView brick61;
    @FXML
    private ImageView brick71;

    @FXML
    private ImageView brick111;
    @FXML
    private ImageView brick211;
    @FXML
    private ImageView brick311;
    @FXML
    private ImageView brick411;
    @FXML
    private ImageView brick511;
    @FXML
    private ImageView brick611;
    @FXML
    private ImageView brick711;

    @FXML
    private ImageView brick112;
    @FXML
    private ImageView brick212;
    @FXML
    private ImageView brick312;
    @FXML
    private ImageView brick412;
    @FXML
    private ImageView brick512;
    @FXML
    private ImageView brick612;
    @FXML
    private ImageView brick712;
    @FXML
    private ImageView axe;
    @FXML
    private ImageView helmet;
    @FXML
    private ImageView bigOrc1;
    @FXML
    private ImageView bgnight;

    @FXML
    private ImageView temp1;
    @FXML
    private ImageView temp2;
    @FXML
    private ImageView obs1;
    @FXML
    private ImageView obs2;

    @FXML
    private Button pause;
    @FXML
    private Button dead;
    @FXML
    private Button newUP;
    @FXML
    private Button test;
    @FXML
    private Button right;
    @FXML
    private Button test1;
    @FXML
    private Pane pausemenu;
    @FXML
    private Button menu;
    @FXML
    private Pane buttonpane;


    TranslateTransition t1 = new TranslateTransition();
    TranslateTransition t1test = new TranslateTransition();
    TranslateTransition t2;
    TranslateTransition t3;
    TranslateTransition t11;
    SequentialTransition sequentialTransition;
    TranslateTransition tbutton;
    TranslateTransition tbutton1;
    ArrayList<ImageView> islands = new ArrayList<>();
    ArrayList<ImageView> orcs = new ArrayList<>();
    ArrayList<ImageView> isl = new ArrayList<>();
    HashMap<ImageView,ImageView> orctoimg = new HashMap<ImageView,ImageView>();
    RotateTransition c1 = new RotateTransition();
    RotateTransition c2 = new RotateTransition();
    RotateTransition c3 = new RotateTransition();
    RotateTransition c4 = new RotateTransition();
    RotateTransition c5 = new RotateTransition();
    RotateTransition c6 = new RotateTransition();
    RotateTransition c7 = new RotateTransition();
    RotateTransition c8 = new RotateTransition();
    RotateTransition c9 = new RotateTransition();
boolean respwaned=false;


    public void ser_score()
    {



        try{
            FileOutputStream fout=new FileOutputStream("maxscore.txt");
            ObjectOutputStream out=new ObjectOutputStream(fout);
            System.out.println(progress);
            out.writeObject(progress);
            out.flush();
            out.close();

            //System.out.println("success");
        }catch(Exception e){System.out.println(e);}
    }

    public void deser_score()
    {



        try{
            ObjectInputStream in=new ObjectInputStream(new FileInputStream("maxscore.txt"));
            maxscore=(Double) in.readObject();
            System.out.println(maxscore);
            in.close();
            //System.out.println("success");
        }catch(Exception e){System.out.println(e);}
    }

    public void ser(int x)
    {

        heroimg = (ImageView) scene.lookup("#heroimg");
        bgnight = (ImageView)scene.lookup("#bgnight");
        double xbg = bgnight.getBoundsInParent().getCenterX();
      //  double ybg = heroimg.getBoundsInParent().getCenterY();
        double xb = heroimg.getBoundsInParent().getCenterX();
        double yb = heroimg.getBoundsInParent().getCenterY();
        String filename = "respawn.txt";
        double c = camera.getBoundsInParent().getMaxX();
        double p = progress;
       // System.out.println(filename);

       // System.out.println("X:"+heroimg.getBoundsInParent());
        try{
            FileOutputStream fout=new FileOutputStream(filename);
            ObjectOutputStream out=new ObjectOutputStream(fout);
            out.writeObject(xb);
            out.flush();
            out.close();

            FileOutputStream f2out=new FileOutputStream("resp.txt");
            ObjectOutputStream out2=new ObjectOutputStream(f2out);
            out2.writeObject(yb);
            out2.flush();
            out2.close();
          //  System.out.println("success");
           // System.out.println("XB:"+xb);
            FileOutputStream fout1=new FileOutputStream("camera_respawn.txt");
            ObjectOutputStream out1=new ObjectOutputStream(fout1);
            out1.writeObject(c);
            out1.flush();
            out1.close();

            FileOutputStream fout2=new FileOutputStream("bg_respawn.txt");
            ObjectOutputStream out22=new ObjectOutputStream(fout2);
            out22.writeObject(c);
            out22.flush();
            out22.close();

            FileOutputStream fout13=new FileOutputStream("progress2.txt");
            ObjectOutputStream out13=new ObjectOutputStream(fout13);
            out13.writeObject(p);
            out13.flush();
            out13.close();

            FileOutputStream fout15=new FileOutputStream("weapon1.txt");
            ObjectOutputStream out15=new ObjectOutputStream(fout15);
            out15.writeObject(weaponGot);
            out15.flush();
            out15.close();

            FileOutputStream fout16=new FileOutputStream("weapon2.txt");
            ObjectOutputStream out16=new ObjectOutputStream(fout16);
            out16.writeObject(weaponGot2);
            out16.flush();
            out16.close();

            FileOutputStream fout17=new FileOutputStream("weapon3.txt");
            ObjectOutputStream out17=new ObjectOutputStream(fout17);
            out17.writeObject(weaponupg);
            out17.flush();
            out17.close();


            //System.out.println("success");
        }catch(Exception e){System.out.println(e);}
    }

    boolean savechk =false;

    public void ser_save1(int x, int c, double p)
    {

        savechk = true;
        bgnight=(ImageView)scene.lookup("#bgnight");
        heroimg = (ImageView) scene.lookup("#heroimg");
        cntrimg=(ImageView)scene.lookup("#cntrimg");
        cntrlabel = (Label) scene.lookup("#cntrlabel");
        pauseimg=(ImageView)scene.lookup("#pauseimg");
        menuimg = (ImageView) scene.lookup("#menuimg");
        proglabel=(Label) scene.lookup("#proglabel");
        double xb = heroimg.getBoundsInParent().getCenterX();
        double xcc = cntrimg.getBoundsInParent().getCenterX();
        double xcl = cntrlabel.getBoundsInParent().getCenterX();
        double xp = pauseimg.getBoundsInParent().getCenterX();
        double xm = menuimg.getBoundsInParent().getCenterX();
        double xpl = proglabel.getBoundsInParent().getCenterX();
        double xbg = bgnight.getBoundsInParent().getCenterX();
        double prog = progbar.getBoundsInParent().getMinX();

//        double xcl = cn.getBoundsInParent().getCenterX();
//        double xcc = bgnight.getBoundsInParent().getCenterX();
//
//        double xp = heroimg.getBoundsInParent().getCenterX();
//        double xm = bgnight.getBoundsInParent().getCenterX();
//        double yb = heroimg.getBoundsInParent().getCenterY();
        String filename = "S1.txt";
        double cx = camera.getBoundsInParent().getCenterX();
        //System.out.println(filename);

        // System.out.println("X:"+heroimg.getBoundsInParent());
        try{
            FileOutputStream fout=new FileOutputStream(filename);
            ObjectOutputStream out=new ObjectOutputStream(fout);
            out.writeObject(xb);
            out.flush();
            out.close();

            FileOutputStream foutp=new FileOutputStream("progl.txt");
            ObjectOutputStream outp=new ObjectOutputStream(foutp);
            outp.writeObject(prog);
            outp.flush();
            outp.close();

            //   System.out.println("success");
            //     System.out.println("XB:"+xb);
            FileOutputStream fout1=new FileOutputStream("coin1.txt");
            ObjectOutputStream out1=new ObjectOutputStream(fout1);
            out1.writeObject(c);
            out1.flush();
            out1.close();

            FileOutputStream fout13=new FileOutputStream("progress1.txt");
            ObjectOutputStream out13=new ObjectOutputStream(fout13);
            out13.writeObject(p);
            out13.flush();
            out13.close();

            FileOutputStream fout12=new FileOutputStream("camera1.txt");
            ObjectOutputStream out12=new ObjectOutputStream(fout12);
            out12.writeObject(cx);
            out12.flush();
            out12.close();

            FileOutputStream fout14=new FileOutputStream("bg.txt");
            ObjectOutputStream out14=new ObjectOutputStream(fout14);
            out14.writeObject(cx);
            out14.flush();
            out14.close();

            FileOutputStream fout15=new FileOutputStream("cl.txt");
            ObjectOutputStream out15=new ObjectOutputStream(fout15);
            out15.writeObject(xcl);
            out15.flush();
            out15.close();

            FileOutputStream fout16=new FileOutputStream("cc.txt");
            ObjectOutputStream out16=new ObjectOutputStream(fout16);
            out16.writeObject(xcc);
            out16.flush();
            out16.close();

            FileOutputStream fout17=new FileOutputStream("pause.txt");
            ObjectOutputStream out17=new ObjectOutputStream(fout17);
            out17.writeObject(xp);
            out17.flush();
            out17.close();

            FileOutputStream fout18=new FileOutputStream("menu.txt");
            ObjectOutputStream out18=new ObjectOutputStream(fout18);
            out18.writeObject(xm);
            out18.flush();
            out18.close();

            FileOutputStream fout19=new FileOutputStream("pl.txt");
            ObjectOutputStream out19=new ObjectOutputStream(fout19);
            out19.writeObject(xpl);
            out19.flush();
            out19.close();

            FileOutputStream fout20=new FileOutputStream("weapon11.txt");
            ObjectOutputStream out20=new ObjectOutputStream(fout20);
            out20.writeObject(weaponGot);
            out20.flush();
            out20.close();

            FileOutputStream fout21=new FileOutputStream("weapon21.txt");
            ObjectOutputStream out21=new ObjectOutputStream(fout21);
            out21.writeObject(weaponGot2);
            out21.flush();
            out21.close();

            FileOutputStream fout23=new FileOutputStream("weapon31.txt");
            ObjectOutputStream out23=new ObjectOutputStream(fout23);
            out23.writeObject(weaponupg);
            out23.flush();
            out23.close();

            // System.out.println("success");
        }catch(Exception e){System.out.println(e);}
    }

    public void ser_save(int x, int c, double p)
    {

        savechk = true;
        proglabel=(Label) scene.lookup("#proglabel");
        bgnight=(ImageView)scene.lookup("#bgnight");
        heroimg = (ImageView) scene.lookup("#heroimg");
        cntrimg=(ImageView)scene.lookup("#cntrimg");
        cntrlabel = (Label) scene.lookup("#cntrlabel");
        pauseimg=(ImageView)scene.lookup("#pauseimg");
        menuimg = (ImageView) scene.lookup("#menuimg");
        double xb = heroimg.getBoundsInParent().getCenterX();
        double xcl = cntrlabel.getBoundsInParent().getCenterX();
        double xcc = cntrimg.getBoundsInParent().getCenterX();
        double xp = pauseimg.getBoundsInParent().getCenterX();
        double xm = menuimg.getBoundsInParent().getCenterX();
        double xbg = bgnight.getBoundsInParent().getCenterX();
        double yb = heroimg.getBoundsInParent().getCenterY();
        double xpl = proglabel.getBoundsInParent().getCenterX();

        String filename = "S.txt";
        double cx = camera.getBoundsInParent().getCenterX();
        //System.out.println(filename);

       // System.out.println("X:"+heroimg.getBoundsInParent());
        try{
            FileOutputStream fout=new FileOutputStream(filename);
            ObjectOutputStream out=new ObjectOutputStream(fout);
            out.writeObject(xb);
            out.flush();
            out.close();
         //   System.out.println("success");
       //     System.out.println("XB:"+xb);
            FileOutputStream fout1=new FileOutputStream("coin.txt");
            ObjectOutputStream out1=new ObjectOutputStream(fout1);
            out1.writeObject(c);
            out1.flush();
            out1.close();

            FileOutputStream fout13=new FileOutputStream("progress.txt");
            ObjectOutputStream out13=new ObjectOutputStream(fout13);
            out13.writeObject(p);
            out13.flush();
            out13.close();

            FileOutputStream fout12=new FileOutputStream("camera.txt");
            ObjectOutputStream out12=new ObjectOutputStream(fout12);
            out12.writeObject(cx);
            out12.flush();
            out12.close();

            FileOutputStream fout14=new FileOutputStream("bg2.txt");
            ObjectOutputStream out14=new ObjectOutputStream(fout14);
            out14.writeObject(xbg);
            out14.flush();
            out14.close();

            FileOutputStream fout15=new FileOutputStream("cl2.txt");
            ObjectOutputStream out15=new ObjectOutputStream(fout15);
            out15.writeObject(xcl);
            out15.flush();
            out15.close();

            FileOutputStream fout16=new FileOutputStream("cc2.txt");
            ObjectOutputStream out16=new ObjectOutputStream(fout16);
            out16.writeObject(xcc);
            out16.flush();
            out16.close();

            FileOutputStream fout17=new FileOutputStream("pause2.txt");
            ObjectOutputStream out17=new ObjectOutputStream(fout17);
            out17.writeObject(xp);
            out17.flush();
            out17.close();

            FileOutputStream fout18=new FileOutputStream("menu2.txt");
            ObjectOutputStream out18=new ObjectOutputStream(fout18);
            out18.writeObject(xm);
            out18.flush();
            out18.close();

            FileOutputStream fout19=new FileOutputStream("pl2.txt");
            ObjectOutputStream out19=new ObjectOutputStream(fout19);
            out19.writeObject(xpl);
            out19.flush();
            out19.close();

            FileOutputStream fout20=new FileOutputStream("weapon12.txt");
            ObjectOutputStream out20=new ObjectOutputStream(fout20);
            out20.writeObject(weaponGot);
            out20.flush();
            out20.close();

            FileOutputStream fout21=new FileOutputStream("weapon22.txt");
            ObjectOutputStream out21=new ObjectOutputStream(fout21);
            out21.writeObject(weaponGot2);
            out21.flush();
            out21.close();

            FileOutputStream fout23=new FileOutputStream("weapon32.txt");
            ObjectOutputStream out23=new ObjectOutputStream(fout23);
            out23.writeObject(weaponupg);
            out23.flush();
            out23.close();


           // System.out.println("success");
        }catch(Exception e){System.out.println(e);}
    }
    public void ser1(int x)
    {
        heroimg = (ImageView) scene.lookup("#heroimg");
        bgnight=(ImageView) scene.lookup("#bgnight");
        double xb = heroimg.getBoundsInParent().getCenterX();
        double xbg = bgnight.getBoundsInParent().getCenterX();
        double yb = heroimg.getBoundsInParent().getCenterY();
        double cb = camera.getBoundsInParent().getMaxX();

        String filename = "D.txt";
       // System.out.println(filename);

      //  System.out.println("X:"+heroimg.getBoundsInParent());
        try{
            FileOutputStream fout=new FileOutputStream(filename);
            ObjectOutputStream out=new ObjectOutputStream(fout);
            out.writeObject(xb);
            out.flush();
            out.close();
          //  System.out.println("success");
          //  System.out.println("XB:"+xb);
            FileOutputStream fout1=new FileOutputStream("camera_resume.txt");
            ObjectOutputStream out1=new ObjectOutputStream(fout1);
            out1.writeObject(cb);
            out1.flush();
            out1.close();

            FileOutputStream fout2=new FileOutputStream("bg_resume.txt");
            ObjectOutputStream out2=new ObjectOutputStream(fout2);
            out2.writeObject(xbg);
            out2.flush();
            out2.close();

            FileOutputStream fout20=new FileOutputStream("weapon13.txt");
            ObjectOutputStream out20=new ObjectOutputStream(fout20);
            out20.writeObject(weaponGot);
            out20.flush();
            out20.close();

            FileOutputStream fout21=new FileOutputStream("weapon23.txt");
            ObjectOutputStream out21=new ObjectOutputStream(fout21);
            out21.writeObject(weaponGot2);
            out21.flush();
            out21.close();

            FileOutputStream fout23=new FileOutputStream("weapon33.txt");
            ObjectOutputStream out23=new ObjectOutputStream(fout23);
            out23.writeObject(weaponupg);
            out23.flush();
            out23.close();
           // System.out.println("success");
        }catch(Exception e){System.out.println(e);}
    }
    public boolean checkHero(){
        return herodead;
    }


    public void deser() throws IOException, ClassNotFoundException {
        herodead=false;
        spawner.stop();
        double xb1;
        double xb2;
      //  double bgx1;
        String filename = "respawn.txt";
     //   System.out.println(filename);
        heroimg = (ImageView) scene.lookup("#heroimg");
        heart = (ImageView) scene.lookup("#heart");
        heartlabel = (ImageView) scene.lookup("#heartlabel");
        heart.setVisible(true);
        heartlabel.setVisible(true);
        ObjectInputStream in=new ObjectInputStream(new FileInputStream(filename));
        xb1=(Double) in.readObject();
        in.close();
        ObjectInputStream in1=new ObjectInputStream(new FileInputStream("camera_respawn.txt"));
        double temp_c=(Double) in1.readObject();
        in1.close();

        ObjectInputStream in3=new ObjectInputStream(new FileInputStream("progress2.txt"));

        double p=(Double) in3.readObject();
      //  p = (Double) in3.readObject();
        progbar.setProgress(p/165);
        proglabel.setText(Integer.toString((int) Math.round(p)));
        in3.close();

        ObjectInputStream in2=new ObjectInputStream(new FileInputStream("bg_respawn.txt"));
        double bgx1=(Double) in2.readObject();
        in2.close();

        ObjectInputStream in22=new ObjectInputStream(new FileInputStream("resp.txt"));
        double xy=(Double) in22.readObject();
        in22.close();

        ObjectInputStream in23=new ObjectInputStream(new FileInputStream("weapon1.txt"));
        weaponGot=(boolean) in23.readObject();
        in23.close();

        ObjectInputStream in24=new ObjectInputStream(new FileInputStream("weapon2.txt"));
        weaponGot2=(boolean) in24.readObject();
        in24.close();

        ObjectInputStream in25=new ObjectInputStream(new FileInputStream("weapon3.txt"));
        weaponupg=(boolean) in25.readObject();
        in25.close();

        TranslateTransition tx = new TranslateTransition();
        tx.setNode(heroimg);
        tx.setToX(xb1);
        tx.setToY(xy);
        tx.setDuration(Duration.millis(1));

        TranslateTransition t1=new TranslateTransition();
        t1.setNode(camera);
        t1.setToX(temp_c);
        t1.setDuration(Duration.millis(1));

        TranslateTransition t2=new TranslateTransition();
        t2.setNode(bgnight);
        t2.setToX(temp_c);
        t2.setDuration(Duration.millis(1));




        TranslateTransition t3=new TranslateTransition();
        t3.setNode(cntrimg);
        t3.setToX(temp_c);
        t3.setDuration(Duration.millis(1));
        t3.setInterpolator(Interpolator.LINEAR);

        TranslateTransition t4=new TranslateTransition();
        t4.setNode(cntrlabel);
        t4.setToX(temp_c);
        t4.setDuration(Duration.millis(1));
        t4.setInterpolator(Interpolator.LINEAR);

        TranslateTransition t5=new TranslateTransition();
        t5.setNode(pauseimg);
        t5.setToX(temp_c);
        t5.setDuration(Duration.millis(1));
        t5.setInterpolator(Interpolator.LINEAR);

        TranslateTransition t6=new TranslateTransition();
        t6.setNode(menuimg);
        t6.setToX(temp_c);
        t6.setDuration(Duration.millis(1));
        t6.setInterpolator(Interpolator.LINEAR);

        TranslateTransition t7=new TranslateTransition();
        t7.setNode(proglabel);
        t7.setToX(temp_c);
        t7.setDuration(Duration.millis(1));
        t7.setInterpolator(Interpolator.LINEAR);

        TranslateTransition t77=new TranslateTransition();
        t77.setNode(respbox);
        t77.setToX(temp_c);
        t77.setDuration(Duration.millis(1));
        t77.setInterpolator(Interpolator.LINEAR);

        TranslateTransition t777=new TranslateTransition();
        t777.setNode(respvbox);
        t777.setToX(temp_c);
        t777.setDuration(Duration.millis(1));
        t777.setInterpolator(Interpolator.LINEAR);

        TranslateTransition t7771=new TranslateTransition();
        t7771.setNode(rect);
        t7771.setToX(temp_c);
        t7771.setDuration(Duration.millis(1));
        t7771.setInterpolator(Interpolator.LINEAR);

        ParallelTransition p1 = new ParallelTransition(tx,t1,t2,t3,t4,t5,t6,t7,t77,t777,t7771);
        p1.play();
        p1.setOnFinished(event -> spawner.start());

        //tx.play();
    }
    public void deser_save1() throws IOException, ClassNotFoundException {

        // spawner.stop();
        double xb1;
        double xb2;
        String filename = "S1.txt";
        //   System.out.println(filename);
        heroimg = (ImageView) scene.lookup("#heroimg");
        heart = (ImageView) scene.lookup("#heart");
        heartlabel = (ImageView) scene.lookup("#heartlabel");
        //heart.setVisible(true);
        //heartlabel.setVisible(true);
        ObjectInputStream in=new ObjectInputStream(new FileInputStream(filename));
        xb1=(Double) in.readObject();
        in.close();
        ObjectInputStream in1=new ObjectInputStream(new FileInputStream("camera1.txt"));
        double temp_c =(Double) in1.readObject();
        in1.close();

        ObjectInputStream in2=new ObjectInputStream(new FileInputStream("bg.txt"));
        double bgx =(Double) in2.readObject();
        in2.close();

        ObjectInputStream in3=new ObjectInputStream(new FileInputStream("cl.txt"));
        double cl  =(Double) in3.readObject();
        in3.close();

        ObjectInputStream in4=new ObjectInputStream(new FileInputStream("cc.txt"));
        double cc =(Double) in4.readObject();
        in4.close();

        ObjectInputStream in5=new ObjectInputStream(new FileInputStream("pause.txt"));
        double p =(Double) in5.readObject();
        in5.close();

        ObjectInputStream in6=new ObjectInputStream(new FileInputStream("menu.txt"));
        double m =(Double) in6.readObject();
        in6.close();

        ObjectInputStream in41=new ObjectInputStream(new FileInputStream("progl.txt"));
        double pr =(Double) in41.readObject();
        in41.close();

        ObjectInputStream in23=new ObjectInputStream(new FileInputStream("weapon11.txt"));
        weaponGot=(boolean) in23.readObject();
        in23.close();

        ObjectInputStream in24=new ObjectInputStream(new FileInputStream("weapon21.txt"));
        weaponGot2=(boolean) in24.readObject();
        in24.close();

        ObjectInputStream in25=new ObjectInputStream(new FileInputStream("weapon31.txt"));
        weaponupg=(boolean) in25.readObject();
        in25.close();

        ObjectInputStream in11=new ObjectInputStream(new FileInputStream("progress1.txt"));
        progress = (Double) in11.readObject();
        progbar.setProgress(progress/165);
        proglabel.setText(Integer.toString((int) Math.round(progress)));
        in11.close();
        ObjectInputStream in12=new ObjectInputStream(new FileInputStream("coin1.txt"));
        coinCounter =(Integer) in12.readObject();
        cntrlabel.setText(Integer.toString(coinCounter));
        in12.close();
        //ObjectInputStream in2=new ObjectInputStream(new FileInputStream("f1.txt"));
        // xb2=(Double) in1.readObject();
        // in2.close();
        TranslateTransition tx = new TranslateTransition();
        tx.setNode(heroimg);
        tx.setToX(xb1);
        tx.setToY(-500);
        tx.setDuration(Duration.millis(1));

        TranslateTransition tx1 = new TranslateTransition();
        tx1.setNode(progbar);
        tx1.setToX(temp_c);
        tx1.setDuration(Duration.millis(1));

        TranslateTransition t1=new TranslateTransition();
        t1.setNode(camera);
        t1.setToX(temp_c);
        t1.setDuration(Duration.millis(1));
        t1.setInterpolator(Interpolator.LINEAR);

        TranslateTransition t2=new TranslateTransition();
        t2.setNode(bgnight);
        t2.setToX(temp_c);
        t2.setDuration(Duration.millis(1));
        t2.setInterpolator(Interpolator.LINEAR);

        TranslateTransition t3=new TranslateTransition();
        t3.setNode(cntrimg);
        t3.setToX(temp_c);
        t3.setDuration(Duration.millis(1));
        t3.setInterpolator(Interpolator.LINEAR);

        TranslateTransition t4=new TranslateTransition();
        t4.setNode(cntrlabel);
        t4.setToX(temp_c);
        t4.setDuration(Duration.millis(1));
        t4.setInterpolator(Interpolator.LINEAR);

        TranslateTransition t5=new TranslateTransition();
        t5.setNode(pauseimg);
        t5.setToX(temp_c);
        t5.setDuration(Duration.millis(1));
        t5.setInterpolator(Interpolator.LINEAR);

        TranslateTransition t6=new TranslateTransition();
        t6.setNode(menuimg);
        t6.setToX(temp_c);
        t6.setDuration(Duration.millis(1));
        t6.setInterpolator(Interpolator.LINEAR);

        TranslateTransition t7=new TranslateTransition();
        t7.setNode(proglabel);
        t7.setToX(temp_c);
        t7.setDuration(Duration.millis(1));
        t7.setInterpolator(Interpolator.LINEAR);

        TranslateTransition t77=new TranslateTransition();
        t77.setNode(respbox);
        t77.setToX(temp_c);
        t77.setDuration(Duration.millis(1));
        t77.setInterpolator(Interpolator.LINEAR);

        TranslateTransition t777=new TranslateTransition();
        t777.setNode(respvbox);
        t777.setToX(temp_c);
        t777.setDuration(Duration.millis(1));
        t777.setInterpolator(Interpolator.LINEAR);

        TranslateTransition t7771=new TranslateTransition();
        t7771.setNode(rect);
        t7771.setToX(temp_c);
        t7771.setDuration(Duration.millis(1));
        t7771.setInterpolator(Interpolator.LINEAR);

        ParallelTransition p1 = new ParallelTransition(tx,tx1,t1,t2,t3,t4,t5,t6,t7,t77,t777,t7771);
        p1.play();



        // heartlabel.setVisible(false);
        // heart.setVisible(false);
        p1.setOnFinished(event -> spawner.start());

        //tx.play();
    }
    public void deser_save() throws IOException, ClassNotFoundException {

        // spawner.stop();
        double xb1;

        String filename = "S.txt";
     //   System.out.println(filename);
        heroimg = (ImageView) scene.lookup("#heroimg");
        heart = (ImageView) scene.lookup("#heart");
        heartlabel = (ImageView) scene.lookup("#heartlabel");
        //heart.setVisible(true);
        //heartlabel.setVisible(true);
        ObjectInputStream in=new ObjectInputStream(new FileInputStream(filename));
        xb1=(Double) in.readObject();
        in.close();

        ObjectInputStream in2=new ObjectInputStream(new FileInputStream("bg2.txt"));
       double bgx=(Double) in2.readObject();
        in2.close();

        ObjectInputStream in1=new ObjectInputStream(new FileInputStream("camera.txt"));
        double temp_c =(Double) in1.readObject();
        in1.close();

        ObjectInputStream in3=new ObjectInputStream(new FileInputStream("cl2.txt"));
        double cl  =(Double) in3.readObject();
        in3.close();

        ObjectInputStream in4=new ObjectInputStream(new FileInputStream("cc2.txt"));
        double cc =(Double) in4.readObject();
        in4.close();

        ObjectInputStream in5=new ObjectInputStream(new FileInputStream("pause2.txt"));
        double p =(Double) in5.readObject();
        in5.close();

        ObjectInputStream in6=new ObjectInputStream(new FileInputStream("menu2.txt"));
        double m =(Double) in6.readObject();
        in6.close();

        ObjectInputStream in7=new ObjectInputStream(new FileInputStream("pl2.txt"));
        double pl =(Double) in7.readObject();
        in7.close();

        ObjectInputStream in23=new ObjectInputStream(new FileInputStream("weapon12.txt"));
        weaponGot=(boolean) in23.readObject();
        in23.close();
        ObjectInputStream in24=new ObjectInputStream(new FileInputStream("weapon22.txt"));
        weaponGot2=(boolean) in24.readObject();
        in24.close();

        ObjectInputStream in25=new ObjectInputStream(new FileInputStream("weapon32.txt"));
        weaponupg=(boolean) in25.readObject();
        in25.close();


        ObjectInputStream in11=new ObjectInputStream(new FileInputStream("progress.txt"));
        progress = (Double) in11.readObject();
        progbar.setProgress(progress/165);

        proglabel.setText(Integer.toString((int) Math.round(progress)));
        in11.close();
        ObjectInputStream in12=new ObjectInputStream(new FileInputStream("coin.txt"));
        coinCounter =(Integer) in12.readObject();
        cntrlabel.setText(Integer.toString(coinCounter));
        in12.close();
        //ObjectInputStream in2=new ObjectInputStream(new FileInputStream("f1.txt"));
       // xb2=(Double) in1.readObject();
       // in2.close();
        TranslateTransition tx = new TranslateTransition();
        tx.setNode(heroimg);
        tx.setToX(xb1);
        tx.setToY(-500);
        tx.setDuration(Duration.millis(1));
        TranslateTransition t1=new TranslateTransition();
        t1.setNode(camera);
        t1.setToX(temp_c);
        t1.setDuration(Duration.millis(1));
        t1.setInterpolator(Interpolator.LINEAR);

        TranslateTransition t2=new TranslateTransition();
        t2.setNode(bgnight);
        t2.setToX(temp_c);
        t2.setDuration(Duration.millis(1));
        t2.setInterpolator(Interpolator.LINEAR);

        TranslateTransition t3=new TranslateTransition();
        t3.setNode(cntrimg);
        t3.setToX(temp_c);
        t3.setDuration(Duration.millis(1));
        t3.setInterpolator(Interpolator.LINEAR);

        TranslateTransition t4=new TranslateTransition();
        t4.setNode(cntrlabel);
        t4.setToX(temp_c);
        t4.setDuration(Duration.millis(1));
        t4.setInterpolator(Interpolator.LINEAR);

        TranslateTransition t5=new TranslateTransition();
        t5.setNode(pauseimg);
        t5.setToX(temp_c);
        t5.setDuration(Duration.millis(1));
        t5.setInterpolator(Interpolator.LINEAR);

        TranslateTransition t6=new TranslateTransition();
        t6.setNode(menuimg);
        t6.setToX(temp_c);
        t6.setDuration(Duration.millis(1));
        t6.setInterpolator(Interpolator.LINEAR);

        TranslateTransition t7=new TranslateTransition();
        t7.setNode(proglabel);
        t7.setToX(temp_c);
        t7.setDuration(Duration.millis(1));
        t7.setInterpolator(Interpolator.LINEAR);

        TranslateTransition t77=new TranslateTransition();
        t77.setNode(respbox);
        t77.setToX(temp_c);
        t77.setDuration(Duration.millis(1));
        t77.setInterpolator(Interpolator.LINEAR);

        TranslateTransition t777=new TranslateTransition();
        t777.setNode(respvbox);
        t777.setToX(temp_c);
        t777.setDuration(Duration.millis(1));
        t777.setInterpolator(Interpolator.LINEAR);

        TranslateTransition t7771=new TranslateTransition();
        t7771.setNode(rect);
        t7771.setToX(temp_c);
        t7771.setDuration(Duration.millis(1));
        t7771.setInterpolator(Interpolator.LINEAR);

        ParallelTransition p1 = new ParallelTransition(tx,t1,t2,t3,t4,t5,t6,t7,t77,t777,t7771);
        p1.play();



        // heartlabel.setVisible(false);
        // heart.setVisible(false);
        p1.setOnFinished(event -> spawner.start());

        //tx.play();
    }
    public void deser1() throws IOException, ClassNotFoundException {

        // spawner.stop();
        double xb1;
        double xb2;
        String filename = "D.txt";
     //   System.out.println(filename);
        heroimg = (ImageView) scene.lookup("#heroimg");
        heart = (ImageView) scene.lookup("#heart");
        heartlabel = (ImageView) scene.lookup("#heartlabel");
//        heart.setVisible(true);
//        heartlabel.setVisible(true);
        ObjectInputStream in=new ObjectInputStream(new FileInputStream(filename));
        xb1=(Double) in.readObject();
        in.close();
        ObjectInputStream in1=new ObjectInputStream(new FileInputStream("camera_resume.txt"));
        double c =(Double) in1.readObject();
        in1.close();

        ObjectInputStream in2=new ObjectInputStream(new FileInputStream("bg_resume.txt"));
        double bgx =(Double) in2.readObject();
        in2.close();

        ObjectInputStream in23=new ObjectInputStream(new FileInputStream("weapon13.txt"));
        weaponGot=(boolean) in23.readObject();
        in23.close();
        ObjectInputStream in24=new ObjectInputStream(new FileInputStream("weapon23.txt"));
        weaponGot2=(boolean) in24.readObject();
        in24.close();

        ObjectInputStream in25=new ObjectInputStream(new FileInputStream("weapon33.txt"));
        weaponupg=(boolean) in25.readObject();
        in25.close();




        TranslateTransition tx = new TranslateTransition();
        tx.setNode(heroimg);
        tx.setToX(xb1);
        tx.setDuration(Duration.millis(1));
        tx.setToY(-500);

        TranslateTransition t1=new TranslateTransition();
        t1.setNode(camera);
        t1.setToX(c);
        t1.setDuration(Duration.millis(1));
       // t1.play();

        TranslateTransition t2=new TranslateTransition();
        t2.setNode(bgnight);
        t2.setToX(c);
        t2.setDuration(Duration.millis(1));

        TranslateTransition t77=new TranslateTransition();
        t77.setNode(respbox);
        t77.setToX(c);
        t77.setDuration(Duration.millis(1));
        t77.setInterpolator(Interpolator.LINEAR);

        TranslateTransition t777=new TranslateTransition();
        t777.setNode(respvbox);
        t777.setToX(c);
        t777.setDuration(Duration.millis(1));
        t777.setInterpolator(Interpolator.LINEAR);

        TranslateTransition t7771=new TranslateTransition();
        t7771.setNode(rect);
        t7771.setToX(c);
        t7771.setDuration(Duration.millis(1));
        t7771.setInterpolator(Interpolator.LINEAR);
       // t2.play();

        ParallelTransition p =  new ParallelTransition(tx,t1,t2,t77,t777,t7771);
        p.play();



        // heartlabel.setVisible(false);
        // heart.setVisible(false);
        p.setOnFinished(event -> spawner.start());

        //tx.play();
    }


    //public void checkcollisioncoin(ImageView o1) {

    //if (heroimg.getBoundsInParent().intersects(o1.getBoundsInParent())) {

    //  collisionTimercoin.stop();
    //  FadeTransition fadeout = new FadeTransition(Duration.seconds(3),chest1);
    //  fadeout.setFromValue(1.0);
    //  fadeout.setToValue(0.0);
    //   fadeout.play();
    // }


    //  }

    // public void checkcollisionexpl(ImageView o1) {

    //  if (heroimg.getBoundsInParent().intersects(o1.getBoundsInParent())) {

    //    collisionTimerexpl.stop();
    //    FadeTransition fadeout = new FadeTransition(Duration.seconds(3),tnt1);
    //   fadeout.setFromValue(1.0);
    //   fadeout.setToValue(0.0);
    //    fadeout.play();
    // }


    //  }
    public ImageView rethero(){
        return this.heroimg;
    }

    public void setXcoordinate(ImageView weapon){
        double x = heroimg.getBoundsInParent().getMaxX();
        TranslateTransition t = new TranslateTransition();
        t.setNode(weapon);
        t.setByX(x);

    }

public void checkCollisionHeroOrcBottom(ImageView orc){
    Lighting lighting = new Lighting();
    lighting.setDiffuseConstant(1.0);
    lighting.setSpecularConstant(0.0);
    lighting.setSpecularExponent(0.0);
    lighting.setSurfaceScale(0.0);
    lighting.setLight(new Light.Distant(45, 45, Color.DARKRED));


    if ( heroimg.getBoundsInParent().intersects(orc.getBoundsInParent())) {
        double herotop = heroimg.getBoundsInParent().getMinY();
        double herobot = heroimg.getBoundsInParent().getMaxY();
        double sizeH = herobot-herotop;
        double orcTop = orc.getBoundsInParent().getMinY();
        double orcBot = orc.getBoundsInParent().getMaxY();
        double sizeOrc = orcBot-orcTop;
        double boundary = herotop-orcTop;
        // System.out.println("I AM HERE"+herotop + " " + herobot +" " + sizeOrc + " " +orcTop + " " + orcBot +" "+ boundary );
        if (( orcBot-herotop<=1 ) && heroimg.getBoundsInParent().getMaxX()>=orc.getBoundsInParent().getMinX()){//heroimg.getBoundsInParent().getMaxY() <= o1.getBoundsInParent().getMaxY() ){// && heroimg.getBoundsInParent().getMinY()<(o1.getBoundsInParent().getMinY()) ) {
            herodead=true;
            TranslateTransition t02 = new TranslateTransition();
            TranslateTransition t03 = new TranslateTransition();
            ScaleTransition t01 = new ScaleTransition();


            t01.setToY(0.5);
            t01.setToX(0.5);
          //  t01.setCycleCount(1);
            t01.setInterpolator(Interpolator.LINEAR);
            t01.setDuration(Duration.millis(800));

            t01.setNode(heroimg);
//                    heroimg.setCache(true);
//                    heroimg.setCacheHint(CacheHint.SPEED);



            t01.setOnFinished(event -> heroimg.setEffect(lighting));
           // t01.setOnFinished(event ->);
            //t01.play();
            t03.setNode(heroimg);
            t03.setByY(80);
            t03.setDuration(Duration.millis(1000));

            SequentialTransition s = new SequentialTransition(t01,t03);
            s.play();
          //  ParallelTransition p = new ParallelTransition();

//            t02.setByY(-80);
//            t02.setDuration(Duration.millis(800));
//
//            t02.setInterpolator(Interpolator.LINEAR);

//                t02.setCycleCount(TranslateTransition.INDEFINITE);
//                t02.setAutoReverse(true);
            t02.setNode(orc);
            t02.setByY(-50);
            t02.setDuration(Duration.millis(500));
//                greenorc.setCache(true);
//                greenorc.setCacheHint(CacheHint.SPEED);
            t02.play();


        }
    }


}
public int checkCoincounter(){
        return coinCounter;
}
int checkchest1collision=0;
    int checkchest2collision=0;
    int checkchest3collision=0;
    public void checkcollisionchest(ImageView o1) {

        if (heroimg.getBoundsInParent().intersects(o1.getBoundsInParent())) {

       //     collisionTimerchest.stop();
            if(o1.getId().equals("chest1")){
                checkchest1collision++;
                layoutbox.setTranslateX(heroimg.getBoundsInParent().getMaxX());
               // layoutbox.
                weaponGot=true;
                weaponGot2=false;
                axetext.setVisible(true);
                layoutaxe.setVisible(true);
                if(checkchest1collision==1) {
                    coinCounter++;
                }
            }
            if(o1.getId().equals("chest12")){
                checkchest2collision++;
                layoutbox.setTranslateX(heroimg.getBoundsInParent().getMaxX());
                weaponGot2=true;
                firetext.setVisible(true);
                layoutfire.setVisible(true);
                if(checkchest2collision==1) {
                    coinCounter++;
                }
//                TranslateTransition tx = new TranslateTransition();
//                tx.setNode(layoutbox);
//                // layoutbox.setTranslateX(heroimg.getBoundsInParent().getCenterX());
//                tx.setToY(heroimg.getBoundsInParent().getCenterX());
            }
            if(o1.getId().equals("chest13")){
                checkchest3collision++;
                layoutbox.setTranslateX(heroimg.getBoundsInParent().getMaxX());
                if(checkchest2collision==1) {
                    coinCounter++;
                }
                if(weaponGot==true){

                   // System.out.println(weaponGot +"klllllllllllllllllll");



                    weaponGot=false;
                    weaponupg=true;
                    axetext.setVisible(true);
                    layoutasaxe.setVisible(true);
                    layoutaxe.setVisible(false);
//                    TranslateTransition tx = new TranslateTransition();
//                    tx.setNode(layoutbox);
//                    // layoutbox.setTranslateX(heroimg.getBoundsInParent().getCenterX());
//                    tx.setToX(heroimg.getBoundsInParent().getCenterX());

                }
            }
            ArrayList<ImageView> a = new ArrayList<>();
            a.add(chest1);
            a.add(chest2);
            a.add(chest3);
            a.add(chest4);
            a.add(chest5);
            a.add(chest6);
            a.add(chest7);
            a.add(chest8);
            a.add(chest9);
            a.add(chest10);
            a.add(chest11);
            a.add(coin);
            o1.setImage(a.get(0).getImage());

            Timeline timeLine = new Timeline();
            Collection<KeyFrame> frames = timeLine.getKeyFrames();
            Duration frameGap = Duration.millis(50);
            Duration frameTime = Duration.ZERO;
            for (ImageView img : a) {
                frameTime = frameTime.add(frameGap);
                frames.add(new KeyFrame(frameTime, e -> o1.setImage(img.getImage())));
            }
            timeLine.setCycleCount(1);

//            RotateTransition coin= new RotateTransition(Duration.millis(100), o1);
//            coin.setByAngle(180);
//            coin.setCycleCount(1);
//            //coin.setDuration(Duration.millis(100));
//            coin.setInterpolator(Interpolator.LINEAR);
           // coin.setAxis(Rotate._AXIS);


            TranslateTransition acoin = new TranslateTransition();
            acoin.setNode(o1);
            acoin.setByX(1000);
            acoin.setByY(1000);
            acoin.setDuration(Duration.millis(1));


            SequentialTransition st = new SequentialTransition(timeLine,acoin);
            st.play();
         //   coinCounter+=5;
          //  System.out.println("Coins collected, total coins = " + coinCounter);
        }}

boolean checker=false;
    boolean herodead = false;
public void checkcollisionherotntdeath(ImageView i){
    if (heroimg.getBoundsInParent().intersects(i.getBoundsInParent())){
        //System.out.println(i.getId() + "CHECKED");
      //  gameovertext.setTranslateX(i.getBoundsInParent().getMinX());
            herodead=true;
          //  gameovertext.setVisible(true);

            TranslateTransition t1 = new TranslateTransition();
            t1.setNode(heroimg);
            t1.setByY(-100);
            t1.setDuration(Duration.millis(3000));

            ColorAdjust blackout = new ColorAdjust();
            blackout.setBrightness(-0.8);

            heroimg.setEffect(blackout);
            t1.play();
            //gameovertext.setVisible(true);
//            if(gameovertext.isVisible())
//            {menu.fire();}

    }

}
    int fireballOrc=0;

int noOfTimesCoins=0;
public void checkcollisionweaponorc(ImageView orc, ImageView weapon){

    if(weapon.getBoundsInParent().getMaxX()>=orc.getBoundsInParent().getMinX()){

        if(weapon.getId().equals("thraxe1") || weapon.getId().equals("thraxe11") || weapon.getId().equals("thraxe12") ){

            ColorAdjust blackout = new ColorAdjust();
            blackout.setBrightness(-0.8);

              orc.setEffect(blackout);
              TranslateTransition tp = new TranslateTransition();
              tp.setDuration(Duration.millis(3000));
              tp.play();
//            tp.setNode(orc);

            fireballOrc++;
            if(fireballOrc>=3){
                TranslateTransition t1 = new TranslateTransition();
                t1.setNode(orc);
                t1.setByX(3);
                t1.setDuration(Duration.millis(400));
                TranslateTransition t = new TranslateTransition();
                t.setNode(orc);
                t.setByX(8000);
                t.setByY(8000);
                t.setInterpolator(Interpolator.LINEAR);
                t.setDuration(Duration.millis(1));
              //  System.out.println(orc.getId() + " orc killed");
                t.setOnFinished(e->coinCounter+=5);
                t.play();
fireballOrc=0;
            }

        }
        else {
            if(orc.getId().equals("boss")){
                health--;
                if(health==0) {

                    TranslateTransition t = new TranslateTransition();
                    t.setNode(orc);
                    t.setByX(1000);
                    t.setByY(2000);
                    t.setInterpolator(Interpolator.LINEAR);
                    t.setDuration(Duration.millis(1));
                    //  System.out.println(orc.getId() + " orc killed");
                    t.setOnFinished(e -> coinCounter += 100);
                    t.play();

                }
            }
            else {
                TranslateTransition t1 = new TranslateTransition();
                t1.setNode(orc);
                t1.setByX(3);
                t1.setDuration(Duration.millis(400));
                TranslateTransition t = new TranslateTransition();
                t.setNode(orc);
                t.setByX(8000);
                t.setByY(8000);
                t.setInterpolator(Interpolator.LINEAR);
                t.setDuration(Duration.millis(1));
                //  System.out.println(orc.getId() + " orc killed");

                t.play();
                noOfTimesCoins++;
                if(noOfTimesCoins==1){
                    coinCounter+=5;
                    noOfTimesCoins=0;
                }
            }
        }
    }

}




    int c=0;
    int ct1=0;
    int ct2=0;
    int ct3=0;
    public void checkcollisiontnt(ImageView o1) {

        if (heroimg.getBoundsInParent().intersects(o1.getBoundsInParent())) {

           // collisionTimertnt.stop();

            ArrayList<ImageView> a = new ArrayList<>();
            a.add(tnt1);
            a.add(tnt2);
            a.add(tnt3);
            a.add(tnt4);
            a.add(tnt5);
            a.add(tnt6);
            a.add(tnt7);
            a.add(tnt8);
            a.add(tnt9);
            a.add(tnt10);
           // a.add(tnt11);
            o1.setImage(a.get(0).getImage());
            Timeline timeLine = new Timeline();
            Collection<KeyFrame> frames = timeLine.getKeyFrames();
            Duration frameGap = Duration.millis(100);
            Duration frameTime = Duration.millis(10);

            for (ImageView img : a) {
                frameTime = frameTime.add(frameGap);
                frames.add(new KeyFrame(frameTime, e -> o1.setImage(img.getImage())));

               if(img.getId().equals("tnt10") ) {
                 //  System.out.println(" OUTSIDE Hero minx: " + heroimg.getBoundsInParent().getMinX() + "hero maxx:" + heroimg.getBoundsInParent().getMaxX() + " img minx: " + tnt1.getBoundsInParent().getMinY() + "img maxx; " + tnt1.getBoundsInParent().getMaxX());


               //    System.out.println(c+"C value");

                   //    System.out.println("Hero minx: " + heroimg.getBoundsInParent().getMinX() + "hero maxx:" + heroimg.getBoundsInParent().getMaxX() + " img minx: " + tnt1.getBoundsInParent().getMinY() + "img maxx; " + tnt1.getBoundsInParent().getMaxX());

                           if (o1.getId().equals("tnt1")) {
                               c++;
                               if(c>=180){
                                   if (heroimg.getBoundsInParent().intersects(o1.getBoundsInParent())){
                                      // System.out.println("CHEKING" + img.getId());
                                       checkcollisionherotntdeath(tnt1);}
                             //  c = 0;
                                       break;}
                           }


                           if (o1.getId().equals("tnt12")) {
                               ct1++;
                               if(ct1>=180){
                                   if (heroimg.getBoundsInParent().intersects(o1.getBoundsInParent())){
                                      // System.out.println("CHEKING" + img.getId());
                                       checkcollisionherotntdeath(tnt12);}
                               //c = 0;
                               break;}
                           }


                           if (o1.getId().equals("tnt13")) {
                               ct2++;
                               if(ct2>=180){
                                   if (heroimg.getBoundsInParent().intersects(o1.getBoundsInParent())){
                                     //  System.out.println("CHEKING" + img.getId());
                                       checkcollisionherotntdeath(tnt13);}
                             //  c = 0;
                               break;}
                           }


                           if (o1.getId().equals("tnt14")) {
                               ct3++;
                               if(ct3>=180){
                                   if (heroimg.getBoundsInParent().intersects(o1.getBoundsInParent())){
                                     //  System.out.println("CHEKING" + img.getId());
                                       checkcollisionherotntdeath(tnt14);}
                               //c = 0;
                               break;}
                           }




               }

            }
            timeLine.setCycleCount(1);

            ScaleTransition tnt = new ScaleTransition();
            tnt.setNode(o1);
            tnt.setByX(1.5);
            tnt.setByY(1.5);
            tnt.setDuration(Duration.millis(200));
            tnt.setCycleCount(1);


            TranslateTransition atnt = new TranslateTransition();
            atnt.setNode(o1);
            atnt.setByX(1000);
            atnt.setByY(1000);
            atnt.setDuration(Duration.millis(1));

//            AnimationTimer checker = new AnimationTimer() {
//                @Override
//                public void handle(long l) {
//                    checkcollisionherotntdeath(tnt1);
//                }
//            };
            SequentialTransition st = new SequentialTransition(timeLine,tnt, atnt);
          //  st.setOnFinished(e -> checkcollisionherotntdeath(tnt1));
         //   st.setOnFinished(e -> atnt.play());
            st.setOnFinished(e -> c=0);
            st.play();

            //atnt.play();
            //checker=true;

        }






    }

    public void checkCollisionHeroSide(ImageView o1) {
        if (heroimg.getBoundsInParent().intersects(o1.getBoundsInParent())){
            double herotop = heroimg.getBoundsInParent().getMinY();
            double herobot = heroimg.getBoundsInParent().getMaxY();
            double sizeH = herobot-herotop;
            double orcTop = o1.getBoundsInParent().getMinY();
            double orcbot = o1.getBoundsInParent().getMaxY();
            double orcS = orcbot-orcTop;
          //   System.out.println(herotop + " " + herobot +" " + sizeH + " " +orcTop + " " + orcbot + " " +orcS );
            if((heroimg.getBoundsInParent().getMaxX()>=o1.getBoundsInParent().getMinX()) ) {
                //        System.out.println("Check");
                if (!((herobot-orcTop<=1) || (orcbot-herotop<=1 ) ))
                    if (o1.getId().equals("bigorc1")) {

                        TranslateTransition t01 = new TranslateTransition();
                        TranslateTransition t02 = new TranslateTransition();
                        TranslateTransition t03 = new TranslateTransition();
                        //

//                        t01.setNode(heroimg);
//                        t01.setByX(-20);
//                        t01.setDuration(Duration.millis(300));
//                        //  t01.setOnFinished((e->camera.translateXProperty().set(heroimg.translateXProperty().getValue()-2)));
//
//                        t01.setInterpolator(Interpolator.LINEAR);
//                        t01.play();


                        t02.setNode(bigOrc1);
                        t02.setByX(80);
                        t02.setInterpolator(Interpolator.LINEAR);
                        t02.setDuration(Duration.millis(300));


                        t02.play();


                        t01.setDuration(Duration.millis(300));
                        //  t01.setOnFinished((e->camera.translateXProperty().set(heroimg.translateXProperty().getValue()-2)));

                        t01.setInterpolator(Interpolator.LINEAR);
                        t01.play();
                        //t03.setNode(camera);
                   //     t03.setByX(-20);
                      //  t03.setDuration(Duration.millis(300));
                        //  t01.setOnFinished((e->camera.translateXProperty().set(heroimg.translateXProperty().getValue()-2)));

                      //  t03.setInterpolator(Interpolator.LINEAR);
                      //  t03.play();

                    }
                if (o1.getId().equals("greenorc")) {
                    // if(heroimg.getBoundsInParent().getMaxX()>=greenorc.getBoundsInParent().getMinX() &&  (heroimg.getBoundsInParent().getMaxY()<=greenorc.getBoundsInParent().getMaxY()) ||heroimg.getBoundsInParent().getMaxY()>=greenorc.getBoundsInParent().getMinY() ){


                    TranslateTransition t01 = new TranslateTransition();
                    TranslateTransition t02 = new TranslateTransition();
                    //
//
//                    t01.setNode(heroimg);
//                    t01.setByX(-10);
//                    t01.setDuration(Duration.millis(300));
//                    t01.setInterpolator(Interpolator.LINEAR);
//                    t01.play();


                    t02.setNode(greenorc);
                    t02.setByX(300);
                    t02.setInterpolator(Interpolator.LINEAR);
                    t02.setDuration(Duration.millis(100));


                    t02.play();
//                    TranslateTransition t03 = new TranslateTransition();
//                    t03.setNode(camera);
//                    t03.setByX(-50);
//                    t03.setDuration(Duration.millis(30));
//                    //  t01.setOnFinished((e->camera.translateXProperty().set(heroimg.translateXProperty().getValue()-2)));
//
//                    t03.setInterpolator(Interpolator.LINEAR);
//                    t03.play();


                }
                if (o1.getId().equals("greenorc2")) {
                    //  if(heroimg.getBoundsInParent().getMaxX()>=greenorc2.getBoundsInParent().getMinX() ){


                    TranslateTransition t01 = new TranslateTransition();
                    TranslateTransition t02 = new TranslateTransition();


//                    t01.setNode(heroimg);
//                    t01.setByX(-10);
//                    t01.setDuration(Duration.millis(300));
//                    t01.setInterpolator(Interpolator.LINEAR);
//                    t01.play();


                    t02.setNode(greenorc2);
                    t02.setByX(300);
                    t02.setInterpolator(Interpolator.LINEAR);
                    t02.setDuration(Duration.millis(100));


                    t02.play();
//                    TranslateTransition t03 = new TranslateTransition();
//                    t03.setNode(camera);
//                    t03.setByX(-50);
//                    t03.setDuration(Duration.millis(30));
//                    //  t01.setOnFinished((e->camera.translateXProperty().set(heroimg.translateXProperty().getValue()-2)));
//
//                    t03.setInterpolator(Interpolator.LINEAR);
//                    t03.play();


                }
                if (o1.getId().equals("greenorc3")) {
                    //  if(heroimg.getBoundsInParent().getMaxX()>=greenorc3.getBoundsInParent().getMinX() ){


                    TranslateTransition t01 = new TranslateTransition();
                    TranslateTransition t02 = new TranslateTransition();
                    //
//
//                    t01.setNode(heroimg);
//                    t01.setByX(-10);
//                    t01.setDuration(Duration.millis(300));
//                    t01.setInterpolator(Interpolator.LINEAR);
//                    t01.play();


                    t02.setNode(greenorc3);
                    t02.setByX(300);
                    t02.setDuration(Duration.millis(100));
                    t02.setInterpolator(Interpolator.LINEAR);

                    t02.play();
//                    TranslateTransition t03 = new TranslateTransition();
//                    t03.setNode(camera);
//                    t03.setByX(-50);
//                    t03.setDuration(Duration.millis(30));
//                    //  t01.setOnFinished((e->camera.translateXProperty().set(heroimg.translateXProperty().getValue()-2)));
//
//                    t03.setInterpolator(Interpolator.LINEAR);
//                    t03.play();


                }
                if (o1.getId().equals("greenorc4")) {
                    // if(heroimg.getBoundsInParent().getMaxX()>=greenorc4.getBoundsInParent().getMinX() ){


                    TranslateTransition t01 = new TranslateTransition();
                    TranslateTransition t02 = new TranslateTransition();
                    //

//                    t01.setNode(heroimg);
//                    t01.setByX(-10);
//                    t01.setDuration(Duration.millis(300));
//                    t01.setInterpolator(Interpolator.LINEAR);
//                    t01.play();
                    //

                    t02.setNode(greenorc4);
                    t02.setByX(300);
                    t02.setDuration(Duration.millis(100));
                    t02.setInterpolator(Interpolator.LINEAR);

                    t02.play();
//                    TranslateTransition t03 = new TranslateTransition();
//                    t03.setNode(camera);
//                    t03.setByX(-50);
//                    t03.setDuration(Duration.millis(30));
//                    //  t01.setOnFinished((e->camera.translateXProperty().set(heroimg.translateXProperty().getValue()-2)));
//
//                    t03.setInterpolator(Interpolator.LINEAR);
//                    t03.play();


                }
                if (o1.getId().equals("boss")) {
                    // if(heroimg.getBoundsInParent().getMaxX()>=greenorc4.getBoundsInParent().getMinX() ){


                    TranslateTransition t01 = new TranslateTransition();
                    TranslateTransition t02 = new TranslateTransition();
                    //

//                    t01.setNode(heroimg);
//                    t01.setByX(-10);
//                    t01.setDuration(Duration.millis(300));
//                    t01.setInterpolator(Interpolator.LINEAR);
//                    t01.play();
                    //

                    t02.setNode(boss);
                    t02.setByX(150);
                    t02.setDuration(Duration.millis(100));
                    t02.setInterpolator(Interpolator.LINEAR);

                    t02.play();
//                    TranslateTransition t03 = new TranslateTransition();
//                    t03.setNode(camera);
//                    t03.setByX(-50);
//                    t03.setDuration(Duration.millis(30));
//                    //  t01.setOnFinished((e->camera.translateXProperty().set(heroimg.translateXProperty().getValue()-2)));
//
//                    t03.setInterpolator(Interpolator.LINEAR);
//                    t03.play();


                }
                if (o1.getId().equals("redorc")) {
                    //if(heroimg.getBoundsInParent().getMaxX()>=redorc.getBoundsInParent().getMinX() ){


                    TranslateTransition t01 = new TranslateTransition();
                    TranslateTransition t02 = new TranslateTransition();
                    //

//                    t01.setNode(heroimg);
//                    t01.setByX(-10);
//                    t01.setDuration(Duration.millis(300));
//                    t01.setInterpolator(Interpolator.LINEAR);
//                    t01.play();
                    //

                    t02.setNode(redorc);
                    t02.setByX(300);
                    t02.setDuration(Duration.millis(100));
                    t02.setInterpolator(Interpolator.LINEAR);

                    t02.play();
//                    TranslateTransition t03 = new TranslateTransition();
//                    t03.setNode(camera);
//                    t03.setByX(-50);
//                    t03.setDuration(Duration.millis(30));
//                    //  t01.setOnFinished((e->camera.translateXProperty().set(heroimg.translateXProperty().getValue()-2)));
//
//                    t03.setInterpolator(Interpolator.LINEAR);
//                    t03.play();


                }
                if (o1.getId().equals("redorc2")) {
                    //  if(heroimg.getBoundsInParent().getMaxX()>=redorc2.getBoundsInParent().getMinX() ){


                    TranslateTransition t01 = new TranslateTransition();
                    TranslateTransition t02 = new TranslateTransition();
                    //
//
//                    t01.setNode(heroimg);
//                    t01.setByX(-10);
//                    t01.setDuration(Duration.millis(300));
//                    t01.setInterpolator(Interpolator.LINEAR);
//                    t01.play();
                    //

                    t02.setNode(redorc2);
                    t02.setByX(300);
                    t02.setDuration(Duration.millis(100));

                    t02.setInterpolator(Interpolator.LINEAR);
                    t02.play();
//                    TranslateTransition t03 = new TranslateTransition();
//                    t03.setNode(camera);
//                    t03.setByX(-50);
//                    t03.setDuration(Duration.millis(30));
//                    //  t01.setOnFinished((e->camera.translateXProperty().set(heroimg.translateXProperty().getValue()-2)));
//
//                    t03.setInterpolator(Interpolator.LINEAR);
//                    t03.play();


                }
                if (o1.getId().equals("redorc3")) {
                    //if(heroimg.getBoundsInParent().getMaxX()>=redorc3.getBoundsInParent().getMinX() ){


                    TranslateTransition t01 = new TranslateTransition();
                    TranslateTransition t02 = new TranslateTransition();
                    //

//                    t01.setNode(heroimg);
//                    t01.setByX(-10);
//                    t01.setDuration(Duration.millis(300));
//                    t01.setInterpolator(Interpolator.LINEAR);
//                    t01.play();
                    //

                    t02.setNode(redorc3);
                    t02.setByX(300);
                    t02.setInterpolator(Interpolator.LINEAR);
                    t02.setDuration(Duration.millis(100));


                    t02.play();
//                    TranslateTransition t03 = new TranslateTransition();
//                    t03.setNode(camera);
//                    t03.setByX(-50);
//                    t03.setDuration(Duration.millis(30));
//                    //  t01.setOnFinished((e->camera.translateXProperty().set(heroimg.translateXProperty().getValue()-2)));
//
//                    t03.setInterpolator(Interpolator.LINEAR);
//                    t03.play();


                }
                if (o1.getId().equals("redorc4")) {


                    TranslateTransition t01 = new TranslateTransition();
                    TranslateTransition t02 = new TranslateTransition();
                    //

//                    t01.setNode(heroimg);
//                    t01.setByX(-10);
//                    t01.setDuration(Duration.millis(300));
//                    t01.setInterpolator(Interpolator.LINEAR);
//                    t01.play();
                    //

                    t02.setNode(redorc4);
                    t02.setByX(300);
                    t02.setDuration(Duration.millis(100));
                    t02.setInterpolator(Interpolator.LINEAR);

                    t02.play();
//                    TranslateTransition t03 = new TranslateTransition();
//                    t03.setNode(camera);
//                    t03.setByX(-50);
//                    t03.setDuration(Duration.millis(30));
//                    //  t01.setOnFinished((e->camera.translateXProperty().set(heroimg.translateXProperty().getValue()-2)));
//
//                    t03.setInterpolator(Interpolator.LINEAR);
//                    t03.play();

                }
                if (o1.getId().equals("redorc5")) {


                    TranslateTransition t01 = new TranslateTransition();
                    TranslateTransition t02 = new TranslateTransition();
                    //
//
//                    t01.setNode(heroimg);
//                    t01.setByX(-10);
//                    t01.setDuration(Duration.millis(300));
//                    t01.setInterpolator(Interpolator.LINEAR);
//                    t01.play();
                    //

                    t02.setNode(redorc5);
                    t02.setByX(300);
                    t02.setDuration(Duration.millis(100));
                    t02.setInterpolator(Interpolator.LINEAR);

                    t02.play();
//                    TranslateTransition t03 = new TranslateTransition();
//                    t03.setNode(camera);
//                    t03.setByX(-50);
//                    t03.setDuration(Duration.millis(30));
//                    //  t01.setOnFinished((e->camera.translateXProperty().set(heroimg.translateXProperty().getValue()-2)));
//
//                    t03.setInterpolator(Interpolator.LINEAR);
//                    t03.play();


                }
                if (o1.getId().equals("redorc1")) {


                    TranslateTransition t01 = new TranslateTransition();
                    TranslateTransition t02 = new TranslateTransition();
                    //

//                    t01.setNode(heroimg);
//                    t01.setByX(-10);
//                    t01.setDuration(Duration.millis(300));
//                    t01.setInterpolator(Interpolator.LINEAR);
//                    t01.play();
                    //

                    t02.setNode(redorc1);
                    t02.setByX(300);
                    t02.setDuration(Duration.millis(100));
                    t02.setInterpolator(Interpolator.LINEAR);

                    t02.play();
                    TranslateTransition t03 = new TranslateTransition();
//                    t03.setNode(camera);
//                    t03.setByX(-50);
//                    t03.setDuration(Duration.millis(30));
//                    //  t01.setOnFinished((e->camera.translateXProperty().set(heroimg.translateXProperty().getValue()-2)));
//
//                    t03.setInterpolator(Interpolator.LINEAR);
//                    t03.play();


                }

            }

        }

    }
    public void checkCollisionHerotop(ImageView o1){
        if ( heroimg.getBoundsInParent().intersects(o1.getBoundsInParent())) {
            double herotop = heroimg.getBoundsInParent().getMinY();
            double herobot = heroimg.getBoundsInParent().getMaxY();
            double sizeH = herobot-herotop;
            double orcTop = o1.getBoundsInParent().getMinY();
            double boundary = orcTop-herotop;
           //  System.out.println("IN HERO TOP "+herotop + " " + herobot +" " + sizeH + " " +orcTop + " " + boundary );
            if (herobot-orcTop<=5 ) {//{&& heroimg.getBoundsInParent().getMaxX() <= o1.getBoundsInParent().getMinX() ){// && heroimg.getBoundsInParent().getMinY()<(o1.getBoundsInParent().getMinY()) ) {
               //  System.out.println("CHECK2");
                TranslateTransition t02 = new TranslateTransition();
                TranslateTransition t01 = new TranslateTransition();


                t01.setByY(-100);
                t01.setInterpolator(Interpolator.LINEAR);
                t01.setDuration(Duration.millis(500));

                t01.setNode(heroimg);
//                    heroimg.setCache(true);
//                    heroimg.setCacheHint(CacheHint.SPEED);
                t01.setOnFinished(event -> fallbackHero());
                t01.play();
                t02.setByY(20);
                t02.setDuration(Duration.millis(100));
                t02.setInterpolator(Interpolator.LINEAR);

//                t02.setCycleCount(TranslateTransition.INDEFINITE);
//                t02.setAutoReverse(true);
                t02.setNode(o1);
//                greenorc.setCache(true);
//                greenorc.setCacheHint(CacheHint.SPEED);
                t02.play();


            }
        }
    }
    public void fallbackHero(){
        if(!herodead ) {
            TranslateTransition f = new TranslateTransition();

            f.setDuration(Duration.millis(5000));
            f.setToY(1000);
            f.setInterpolator(Interpolator.LINEAR);
            f.setNode(heroimg);
            f.play();
        }
    }
    public void fallbackOrc(ImageView i) {
if(0==0) {
    //System.out.println("CHECK2" + i.getId());
    if (i.getId().equals("greenorc")) {
        TranslateTransition f = new TranslateTransition();
        //System.out.println("CHECK1");
        f.setDuration(Duration.millis(8000));
        f.setToY(800);
        f.setInterpolator(Interpolator.LINEAR);
        f.setNode(greenorc);
        f.play();
    }

    if (i.getId().equals("greenorc2")) {
        TranslateTransition f = new TranslateTransition();

        f.setDuration(Duration.millis(3000));
        f.setToY(800);
        f.setInterpolator(Interpolator.LINEAR);
        f.setNode(greenorc2);
        f.play();
    }
    if (i.getId().equals("greenorc3")) {
        TranslateTransition f = new TranslateTransition();
        f.setDuration(Duration.millis(3000));
        f.setToY(8000);
        f.setInterpolator(Interpolator.LINEAR);
        f.setNode(greenorc3);
        f.play();
    }
    if (i.getId().equals("boss")) {
        TranslateTransition f = new TranslateTransition();
        f.setDuration(Duration.millis(3000));
        f.setToY(8000);
        f.setInterpolator(Interpolator.LINEAR);
        f.setNode(boss);
        f.play();
    }
    if (i.getId().equals("greenorc4")) {
        TranslateTransition f = new TranslateTransition();
        f.setDuration(Duration.millis(3000));
        f.setToY(800);
        f.setInterpolator(Interpolator.LINEAR);
        f.setNode(greenorc4);
        f.play();
    }
    if (i.getId().equals("redorc")) {
        TranslateTransition f = new TranslateTransition();
        f.setDuration(Duration.millis(3000));
        f.setToY(800);
        f.setInterpolator(Interpolator.LINEAR);
        f.setNode(redorc);
        f.play();
    }
    if (i.getId().equals("redorc2")) {
        TranslateTransition f = new TranslateTransition();
        f.setDuration(Duration.millis(3000));
        f.setToY(800);
        f.setInterpolator(Interpolator.LINEAR);
        f.setNode(redorc2);
        f.play();
    }
    if (i.getId().equals("redorc3")) {
        TranslateTransition f = new TranslateTransition();
        f.setDuration(Duration.millis(3000));
        f.setToY(800);
        f.setInterpolator(Interpolator.LINEAR);
        f.setNode(redorc3);
        f.play();
    }
    if (i.getId().equals("redorc4")) {
        TranslateTransition f = new TranslateTransition();
        f.setDuration(Duration.millis(3000));
        f.setToY(800);
        f.setInterpolator(Interpolator.LINEAR);
        f.setNode(redorc4);
        f.play();
    }
    if (i.getId().equals("redorc5")) {
        TranslateTransition f = new TranslateTransition();
        f.setDuration(Duration.millis(3000));
        f.setToY(800);
        f.setInterpolator(Interpolator.LINEAR);
        f.setNode(redorc5);
        f.play();
    }
    if (i.getId().equals("redorc1")) {
        TranslateTransition f = new TranslateTransition();
        f.setDuration(Duration.millis(3000));
        f.setToY(800);
        f.setInterpolator(Interpolator.LINEAR);
        f.setNode(redorc1);
        f.play();
    }
    if (i.getId().equals("bigorc1")) {
        TranslateTransition f = new TranslateTransition();
        f.setDuration(Duration.millis(3000));
        f.setToY(800);
        f.setInterpolator(Interpolator.LINEAR);
        f.setNode(bigOrc1);
        f.play();
    }

    if (i.getId().equals("boss")) {
        TranslateTransition f = new TranslateTransition();
        f.setDuration(Duration.millis(3000));
        f.setToY(800);
        f.setInterpolator(Interpolator.LINEAR);
        f.setNode(boss);
        f.play();
    }
}
    }

    public void fallIntospawn() throws IOException, ClassNotFoundException {
        heroimg = (ImageView)scene.lookup("#heroimg");
        if(heroimg.getBoundsInParent().intersects(spawnchk.getBoundsInParent())) {
            if (heroimg.getBoundsInParent().getMaxY() >= spawnchk.getBoundsInParent().getMinY()) {

                 spawner.stop();
                 deser();
                 //System.out.println("HEREALSO");
                // System.out.println(heroimg.getBoundsInParent());


            }
        }
    }
    int spawncounter=0;
    public void checkCollisionspwan() throws IOException, ClassNotFoundException {
        heroimg = (ImageView)scene.lookup("#heroimg");
        if(heroimg.getBoundsInParent().intersects(chkpnt1.getBoundsInParent())) {

        //    System.out.println("HERE");
           // System.out.println(heroimg.getBoundsInParent());
          ser(spawncounter);
        }
        if(heroimg.getBoundsInParent().intersects(chkpnt2.getBoundsInParent())) {
//            System.out.println("HERE");
//            System.out.println(heroimg.getBoundsInParent());
            spawncounter-=20;
            ser(spawncounter);
        }
        if(heroimg.getBoundsInParent().intersects(chkpnt3.getBoundsInParent())) {
//            System.out.println("HERE");
//            System.out.println(heroimg.getBoundsInParent());
            spawncounter-=20;
            ser(spawncounter);
        }
        if(heroimg.getBoundsInParent().intersects(chkpnt4.getBoundsInParent())) {
//            System.out.println("HERE");
//            System.out.println(heroimg.getBoundsInParent());
            spawncounter-=20;
            ser(spawncounter);
        }
    }
    int nooftimes=0;
    int fallchk=0;
    public void rspn()
    {
        if(herodead)
        {

             //   heroimg = (ImageView) scene.lookup("#heroimg");
//
                respbox.setVisible(true);
            respvbox.setVisible(true);


            if(coinCounter>=10) {


                        //System.out.println("CHECKINGGGGGG");
                    ryes.addEventHandler(MouseEvent.MOUSE_RELEASED, new EventHandler<MouseEvent>() {


                        @Override
                        public void handle(MouseEvent mouseEvent) {

                            //if(respawn_check==true){
                            //    System.exit(0);
                          //  }
                          //  else{
                          //  respawn_check=true;}
                                collisionTimer51.stop();
                                herodead=false;
                                //coinCounter-=10;
                                heroimg.setTranslateY(-200);
                                TranslateTransition t=new TranslateTransition();
                                t.setByY(1000);
                                t.setNode(heroimg);
                                t.setDuration(Duration.millis(5000));
                                t.play();
                                if(fallchk==0){
                                coinCounter-=10;
                                fallchk=1;}
                                System.out.println("CHECK FALL"+heroimg.getBoundsInParent().getMaxY());
                                respbox.setVisible(false);
                                respvbox.setVisible(false);
//                                TranslateTransition t1=new TranslateTransition();
//                                t1.setNode(heroimg);
//                                t1.setByY(-3000);
//                                t1.setDuration(Duration.millis(5));
//                                t1.play();

                                return;

                        }
                    });}
                    rno.addEventHandler(MouseEvent.MOUSE_CLICKED, new EventHandler<MouseEvent>() {
                        @Override
                        public void handle(MouseEvent mouseEvent) {

                            respbox.setVisible(false);
                            respvbox.setVisible(false);
                            System.exit(0);
                        }
                    });




        }
    }
    public boolean checkBossDead(){
        if(health==0){
            return true;
        }
        return false;
    }
boolean rspwn=false;
    public void fallIntoabyss(ImageView i) {
        if(i.getBoundsInParent().intersects(abyss.getBoundsInParent())) {
            if (i.getBoundsInParent().getMaxY() >= abyss.getBoundsInParent().getMinY()) {
                if (i.getId().equals("heroimg")) {

                    heart = (ImageView) scene.lookup("#heart");
                    heartlabel = (ImageView) scene.lookup("#heartlabel");
                    heart.setVisible(false);
                    heartlabel.setVisible(false);
                    TranslateTransition t1 = new TranslateTransition();
                    ScaleTransition s1 = new ScaleTransition();
                    t1.setNode(heroimg);
                    t1.setDuration(Duration.seconds(1000));
                   // t1.setOnFinished(e->menu.fire());
//                    gameovertext.setTranslateX(i.getBoundsInParent().getMinX());
//                    s1.setNode(gameovertext);
//                    s1.setByX(5);
//                    s1.setByY(5);
//                    s1.setDuration(Duration.seconds(5));
//                    s1.play();
                    herodead=true;
//                    gameovertext.setVisible(true);
                    t1.setDuration(Duration.seconds(5));

                    t1.play();

                    return;
                }
                if (i.getId().equals("boss")) {


                    TranslateTransition t1 = new TranslateTransition();
                    t1.setNode(boss);
                    t1.setDuration(Duration.seconds(1000));
                    // t1.setOnFinished(e->menu.fire());
//                    gameovertext.setTranslateX(i.getBoundsInParent().getMinX());
//                    s1.setNode(gameovertext);
//                    s1.setByX(5);
//                    s1.setByY(5);
//                    s1.setDuration(Duration.seconds(5));
//                    s1.play();
                    health=0;
//                    gameovertext.setVisible(true);
                    t1.setDuration(Duration.seconds(5));

                    t1.play();

                    return;
                }
                else{
                    coinCounter++;
                }

            }
        }
    }
    public void checkCollisionHeroIsland(ImageView i1) throws InterruptedException {
        double xMax = heroimg.getBoundsInParent().getMaxX();
        Path path = new Path();
        TranslateTransition t01 = new TranslateTransition();
        if ((i1.getBoundsInParent()).intersects(heroimg.getBoundsInParent())) {
            //  System.out.println("Check3");
//
            if(heroimg.getBoundsInParent().getMaxY()>=i1.getBoundsInParent().getMinY() && !(heroimg.getBoundsInParent().getMaxY()>i1.getBoundsInParent().getMinY()+10) ) {
                //   System.out.println("Check2");
                //t02.setNode(i1);
                //t01.wait(50);
                if (i1.getId().equals("isl1")) {

                    t01.setNode(heroimg);
                    t01.setInterpolator(Interpolator.LINEAR);
                    t01.setByY(-100);
                    t01.setDuration(Duration.millis(800));
                    t01.setOnFinished(event -> fallbackHero());
                    //t01.setCycleCount(TranslateTransition.INDEFINITE);
                    // t01.setAutoReverse(true);
//                heroimg.setCache(true);
//                heroimg.setCacheHint(CacheHint.SPEED);
                 //   t01.setInterpolator(Interpolator.LINEAR);
                    t01.play();
                }
                if (i1.getId().equals("isl2")) {
                    t01.setNode(heroimg);
                //    t01.setInterpolator(Interpolator.LINEAR);

                    t01.setByY(-100);
                    t01.setDuration(Duration.millis(800));
                    t01.setOnFinished(event -> fallbackHero());
                    //t01.setCycleCount(TranslateTransition.INDEFINITE);
                    // t01.setAutoReverse(true);
//                heroimg.setCache(true);
//                heroimg.setCacheHint(CacheHint.SPEED);
                    t01.setInterpolator(Interpolator.LINEAR);
                    t01.play();
                }
                if (i1.getId().equals("isl3")) {
                    t01.setNode(heroimg);
                   // t01.setInterpolator(Interpolator.LINEAR);

                    t01.setByY(-100);
                    t01.setDuration(Duration.millis(800));
                    t01.setOnFinished(event -> fallbackHero());
                    //t01.setCycleCount(TranslateTransition.INDEFINITE);
                    // t01.setAutoReverse(true);
//                    heroimg.setCache(true);
//                    heroimg.setCacheHint(CacheHint.SPEED);
                    t01.setInterpolator(Interpolator.LINEAR);
                    t01.play();
                }
                if (i1.getId().equals("isl4")) {
                    t01.setNode(heroimg);
                    t01.setInterpolator(Interpolator.LINEAR);

                    t01.setByY(-100);
                    t01.setDuration(Duration.millis(800));

                    t01.setOnFinished(event -> fallbackHero());
                    // t01.setAutoReverse(true);
//                    heroimg.setCache(true);
//                    heroimg.setCacheHint(CacheHint.SPEED);
                  //  t01.setInterpolator(Interpolator.LINEAR);
                    t01.play();
                }
                if (i1.getId().equals("isl5")) {
                    t01.setNode(heroimg);
                    t01.setInterpolator(Interpolator.LINEAR);

                    t01.setByY(-100);
                    t01.setDuration(Duration.millis(800));

                    t01.setOnFinished(event -> fallbackHero());
                    // t01.setAutoReverse(true);
//                    heroimg.setCache(true);
//                    heroimg.setCacheHint(CacheHint.SPEED);
                  //  t01.setInterpolator(Interpolator.LINEAR);
                    t01.play();
                }
                if (i1.getId().equals("isl53")) {
                    t01.setNode(heroimg);
                    t01.setInterpolator(Interpolator.LINEAR);

                    t01.setByY(-100);
                    t01.setDuration(Duration.millis(800));

                    t01.setOnFinished(event -> fallbackHero());
                    // t01.setAutoReverse(true);
//                    heroimg.setCache(true);
//                    heroimg.setCacheHint(CacheHint.SPEED);
                    //t01.setInterpolator(Interpolator.LINEAR);
                    t01.play();
                }
                if (i1.getId().equals("isl531")) {
                    t01.setNode(heroimg);
                    t01.setInterpolator(Interpolator.LINEAR);

                    t01.setByY(-100);
                    t01.setDuration(Duration.millis(800));

                    t01.setOnFinished(event -> fallbackHero());
                    // t01.setAutoReverse(true);
//                    heroimg.setCache(true);
//                    heroimg.setCacheHint(CacheHint.SPEED);
                  //  t01.setInterpolator(Interpolator.LINEAR);
                    t01.play();
                }
                if (i1.getId().equals("isl51")) {
                    t01.setNode(heroimg);
                    t01.setInterpolator(Interpolator.LINEAR);

                    t01.setByY(-100);
                    t01.setDuration(Duration.millis(800));

                    t01.setOnFinished(event -> fallbackHero());
                    // t01.setAutoReverse(true);
//                    heroimg.setCache(true);
//                    heroimg.setCacheHint(CacheHint.SPEED);
                   // t01.setInterpolator(Interpolator.LINEAR);
                    t01.play();
                }
                if (i1.getId().equals("isl52")) {
                    t01.setNode(heroimg);
                    t01.setInterpolator(Interpolator.LINEAR);

                    t01.setByY(-100);
                    t01.setDuration(Duration.millis(800));

                    t01.setOnFinished(event -> fallbackHero());
                    // t01.setAutoReverse(true);
//                    heroimg.setCache(true);
//                    heroimg.setCacheHint(CacheHint.SPEED);
                 //   t01.setInterpolator(Interpolator.LINEAR);
                    t01.play();
                }
                if (i1.getId().equals("isl55")) {
                    t01.setNode(heroimg);
                    t01.setInterpolator(Interpolator.LINEAR);

                    t01.setByY(-100);
                    t01.setDuration(Duration.millis(800));

                    t01.setOnFinished(event -> fallbackHero());
                    // t01.setAutoReverse(true);
//                    heroimg.setCache(true);
//                    heroimg.setCacheHint(CacheHint.SPEED);
                  //  t01.setInterpolator(Interpolator.LINEAR);
                    t01.play();
                }
                if (i1.getId().equals("isl54")) {
                    t01.setNode(heroimg);
                    t01.setInterpolator(Interpolator.LINEAR);

                    t01.setByY(-100);
                    t01.setDuration(Duration.millis(800));

                    t01.setOnFinished(event -> fallbackHero());
                    // t01.setAutoReverse(true);
//                    heroimg.setCache(true);
//                    heroimg.setCacheHint(CacheHint.SPEED);
                //    t01.setInterpolator(Interpolator.LINEAR);
                    t01.play();
                }
                if (i1.getId().equals("isl6")) {
                    t01.setNode(heroimg);
                    t01.setInterpolator(Interpolator.LINEAR);

                    t01.setByY(-100);
                    t01.setDuration(Duration.millis(800));

                    t01.setOnFinished(event -> fallbackHero());
                    // t01.setAutoReverse(true);
//                    heroimg.setCache(true);
//                    heroimg.setCacheHint(CacheHint.SPEED);
                 //   t01.setInterpolator(Interpolator.LINEAR);
                    t01.play();
                }
                if (i1.getId().equals("isl7")) {
                    t01.setNode(heroimg);
                    t01.setInterpolator(Interpolator.LINEAR);

                    t01.setByY(-100);
                    t01.setDuration(Duration.millis(800));

                    t01.setOnFinished(event -> fallbackHero());
                    // t01.setAutoReverse(true);
//                    heroimg.setCache(true);
//                    heroimg.setCacheHint(CacheHint.SPEED);
                  //  t01.setInterpolator(Interpolator.LINEAR);
                    t01.play();
                }
                if (i1.getId().equals("isl8")) {
                    t01.setNode(heroimg);
                    t01.setInterpolator(Interpolator.LINEAR);

                    t01.setByY(-100);
                    t01.setDuration(Duration.millis(800));

                    t01.setOnFinished(event -> fallbackHero());
                    // t01.setAutoReverse(true);
//                    heroimg.setCache(true);
//                    heroimg.setCacheHint(CacheHint.SPEED);
                 //   t01.setInterpolator(Interpolator.LINEAR);
                    t01.play();
                }
                if (i1.getId().equals("isl9")) {
                    t01.setNode(heroimg);
                    t01.setInterpolator(Interpolator.LINEAR);

                    t01.setByY(-100);
                    t01.setDuration(Duration.millis(800));

                    t01.setOnFinished(event -> fallbackHero());
                    // t01.setAutoReverse(true);
//                    heroimg.setCache(true);
//                    heroimg.setCacheHint(CacheHint.SPEED);
                //    t01.setInterpolator(Interpolator.LINEAR);
                    t01.play();
                }
                if (i1.getId().equals("isl91")) {
                    t01.setNode(heroimg);
                    t01.setInterpolator(Interpolator.LINEAR);

                    t01.setByY(-100);
                    t01.setDuration(Duration.millis(800));

                    t01.setOnFinished(event -> fallbackHero());
                    // t01.setAutoReverse(true);
//                    heroimg.setCache(true);
//                    heroimg.setCacheHint(CacheHint.SPEED);
                    //    t01.setInterpolator(Interpolator.LINEAR);
                    t01.play();
                }
                if (i1.getId().equals("isl911")) {
                    t01.setNode(heroimg);
                    t01.setInterpolator(Interpolator.LINEAR);

                    t01.setByY(-100);
                    t01.setDuration(Duration.millis(800));

                    t01.setOnFinished(event -> fallbackHero());
                    // t01.setAutoReverse(true);
//                    heroimg.setCache(true);
//                    heroimg.setCacheHint(CacheHint.SPEED);
                    //    t01.setInterpolator(Interpolator.LINEAR);
                    t01.play();
                }
                if (i1.getId().equals("isl71")) {
                    t01.setNode(heroimg);
                    t01.setInterpolator(Interpolator.LINEAR);

                    t01.setByY(-100);
                    t01.setDuration(Duration.millis(800));

                    t01.setOnFinished(event -> fallbackHero());
                    // t01.setAutoReverse(true);
//                    heroimg.setCache(true);
//                    heroimg.setCacheHint(CacheHint.SPEED);
                  //  t01.setInterpolator(Interpolator.LINEAR);
                    t01.play();
                }
                if (i1.getId().equals("isl72")) {
                    t01.setNode(heroimg);
                    t01.setInterpolator(Interpolator.LINEAR);

                    t01.setByY(-100);
                    t01.setDuration(Duration.millis(800));

                    t01.setOnFinished(event -> fallbackHero());
                    // t01.setAutoReverse(true);
//                    heroimg.setCache(true);
//                    heroimg.setCacheHint(CacheHint.SPEED);
                 //   t01.setInterpolator(Interpolator.LINEAR);
                    t01.play();
                }
                if (i1.getId().equals("isl73")) {
                    t01.setNode(heroimg);
                    t01.setInterpolator(Interpolator.LINEAR);

                    t01.setByY(-100);
                    t01.setDuration(Duration.millis(800));

                    t01.setOnFinished(event -> fallbackHero());
                    // t01.setAutoReverse(true);
//                    heroimg.setCache(true);
//                    heroimg.setCacheHint(CacheHint.SPEED);
                //    t01.setInterpolator(Interpolator.LINEAR);
                    t01.play();
                }
                if (i1.getId().equals("isl74")) {
                    t01.setNode(heroimg);
                    t01.setInterpolator(Interpolator.LINEAR);

                    t01.setByY(-100);
                    t01.setDuration(Duration.millis(800));

                    t01.setOnFinished(event -> fallbackHero());
                    // t01.setAutoReverse(true);
//                    heroimg.setCache(true);
//                    heroimg.setCacheHint(CacheHint.SPEED);
                 //   t01.setInterpolator(Interpolator.LINEAR);
                    t01.play();
                }
                if (i1.getId().equals("isl75")) {
                    t01.setNode(heroimg);
                    t01.setInterpolator(Interpolator.LINEAR);

                    t01.setByY(-100);
                    t01.setDuration(Duration.millis(800));

                    t01.setOnFinished(event -> fallbackHero());
                    // t01.setAutoReverse(true);
//                    heroimg.setCache(true);
//                    heroimg.setCacheHint(CacheHint.SPEED);
                  //  t01.setInterpolator(Interpolator.LINEAR);
                    t01.play();
                }
                if (i1.getId().equals("isl76")) {
                    t01.setNode(heroimg);
                    t01.setInterpolator(Interpolator.LINEAR);

                    t01.setByY(-100);
                    t01.setDuration(Duration.millis(800));

                    t01.setOnFinished(event -> fallbackHero());
//                    // t01.setAutoReverse(true);
//                    heroimg.setCache(true);
//                    heroimg.setCacheHint(CacheHint.SPEED);
                 //   t01.setInterpolator(Interpolator.LINEAR);
                    t01.play();
                }

                if (i1.getId().equals("marble1")) {

                    t01.setNode(heroimg);
                    t01.setInterpolator(Interpolator.LINEAR);
                    t01.setByY(-100);
                    t01.setDuration(Duration.millis(500));
                    t01.setOnFinished(event -> fallbackHero());
                    //t01.setCycleCount(TranslateTransition.INDEFINITE);
                    // t01.setAutoReverse(true);
//                heroimg.setCache(true);
//                heroimg.setCacheHint(CacheHint.SPEED);
                 //   t01.setInterpolator(Interpolator.LINEAR);
                    t01.play();
                }

                if (i1.getId().equals("marble2")) {

                    t01.setNode(heroimg);
                    t01.setInterpolator(Interpolator.LINEAR);
                    t01.setByY(-100);
                    t01.setDuration(Duration.millis(500));
                    t01.setOnFinished(event -> fallbackHero());
                    //t01.setCycleCount(TranslateTransition.INDEFINITE);
                    // t01.setAutoReverse(true);
//                heroimg.setCache(true);
//                heroimg.setCacheHint(CacheHint.SPEED);
                  //  t01.setInterpolator(Interpolator.LINEAR);
                    t01.play();
                }

                if (i1.getId().equals("marble3")) {

                    t01.setNode(heroimg);
                    t01.setInterpolator(Interpolator.LINEAR);
                    t01.setByY(-100);
                    t01.setDuration(Duration.millis(500));
                    t01.setOnFinished(event -> fallbackHero());
                    //t01.setCycleCount(TranslateTransition.INDEFINITE);
                    // t01.setAutoReverse(true);
//                heroimg.setCache(true);
//                heroimg.setCacheHint(CacheHint.SPEED);
                  //  t01.setInterpolator(Interpolator.LINEAR);
                    t01.play();
                }

            }
            else if(heroimg.getBoundsInParent().getMinY()>= i1.getBoundsInParent().getMinY()) {
                //System.out.println("Falling into abyss");
                //TranslateTransition t02 = new TranslateTransition();

            }
        }
    }

    public void checkCollisionOrcIsland(ImageView i1, ImageView i2) throws InterruptedException {
        //double xMax = heroimg.getBoundsInParent().getMaxX();
        //Path path = new Path();

        if ((i1.getBoundsInParent()).intersects(i2.getBoundsInParent())) {

            //TranslateTransition t02 = new TranslateTransition();


            //t02.setNode(i1);
            //t01.wait(50);
            if(i1.getBoundsInParent().getMaxY()>=i2.getBoundsInParent().getMinY() && !(i1.getBoundsInParent().getMaxY()>i2.getBoundsInParent().getMinY()+10)) {
                // System.out.println(i1.getBoundsInParent().getMaxY() + i1.getId() + i2.getBoundsInParent().getMaxY());
                if (i2.getId().equals("isl1")) {

                    TranslateTransition t01 = new TranslateTransition();
                    t01.setNode(i1);
                    t01.setInterpolator(Interpolator.LINEAR);
                    t01.setByY(-80);
                    t01.setDuration(Duration.millis(800));
                    t01.setOnFinished(event -> fallbackOrc(i1));
                    //t01.setCycleCount(TranslateTransition.INDEFINITE);
                    // t01.setAutoReverse(true);
//                heroimg.setCache(true);
//                heroimg.setCacheHint(CacheHint.SPEED);
                    t01.play();
                }
                if (i2.getId().equals("isl2")) {
                    TranslateTransition t01 = new TranslateTransition();
                    t01.setNode(i1);
                    t01.setInterpolator(Interpolator.LINEAR);

                    t01.setByY(-80);
                    t01.setDuration(Duration.millis(800));
                    t01.setOnFinished(event -> fallbackOrc(i1));
                    //t01.setCycleCount(TranslateTransition.INDEFINITE);
                    // t01.setAutoReverse(true);
//                heroimg.setCache(true);
//                heroimg.setCacheHint(CacheHint.SPEED);
                    t01.play();
                }
                if (i2.getId().equals("isl3")) {
                    TranslateTransition t01 = new TranslateTransition();
                    t01.setNode(i1);
                    t01.setInterpolator(Interpolator.LINEAR);

                    t01.setByY(-80);
                    t01.setDuration(Duration.millis(800));
                    t01.setOnFinished(event -> fallbackOrc(i1));
                    //t01.setCycleCount(TranslateTransition.INDEFINITE);
                    // t01.setAutoReverse(true);
//                    i1.setCache(true);
//                    i1.setCacheHint(CacheHint.SPEED);
                    t01.play();
                }
                if (i2.getId().equals("isl4")) {
                    TranslateTransition t01 = new TranslateTransition();
                    t01.setNode(i1);
                    t01.setInterpolator(Interpolator.LINEAR);

                    t01.setByY(-80);
                    t01.setDuration(Duration.millis(800));

                    t01.setOnFinished(event -> fallbackOrc(i1));
                    // t01.setAutoReverse(true);
//                    i1.setCache(true);
//                    i1.setCacheHint(CacheHint.SPEED);
                    t01.play();
                }
                if (i2.getId().equals("isl5")) {
                    TranslateTransition t01 = new TranslateTransition();
                    t01.setNode(i1);
                    t01.setInterpolator(Interpolator.LINEAR);

                    t01.setByY(-80);
                    t01.setDuration(Duration.millis(800));

                    t01.setOnFinished(event -> fallbackOrc(i1));
                    // t01.setAutoReverse(true);
//                    i1.setCache(true);
//                    i1.setCacheHint(CacheHint.SPEED);
                    t01.play();
                }
                if (i2.getId().equals("isl53")) {
                    TranslateTransition t01 = new TranslateTransition();
                    t01.setNode(i1);
                    t01.setInterpolator(Interpolator.LINEAR);

                    t01.setByY(-80);
                    t01.setDuration(Duration.millis(800));

                    t01.setOnFinished(event -> fallbackOrc(i1));
                    // t01.setAutoReverse(true);
//                    i1.setCache(true);
//                    i1.setCacheHint(CacheHint.SPEED);
                    t01.play();
                }
                if (i2.getId().equals("isl531")) {
                    TranslateTransition t01 = new TranslateTransition();
                    t01.setNode(i1);
                    t01.setInterpolator(Interpolator.LINEAR);

                    t01.setByY(-80);
                    t01.setDuration(Duration.millis(800));

                    t01.setOnFinished(event -> fallbackOrc(i1));
                    // t01.setAutoReverse(true);
//                    i1.setCache(true);
//                    i1.setCacheHint(CacheHint.SPEED);
                    t01.play();
                }
                if (i2.getId().equals("isl51")) {
                    TranslateTransition t01 = new TranslateTransition();
                    t01.setNode(i1);
                    t01.setInterpolator(Interpolator.LINEAR);

                    t01.setByY(-80);
                    t01.setDuration(Duration.millis(800));

                    t01.setOnFinished(event -> fallbackOrc(i1));
                    // t01.setAutoReverse(true);
//                    i1.setCache(true);
//                    i1.setCacheHint(CacheHint.SPEED);
                    t01.play();
                }
                if (i2.getId().equals("isl52")) {
                    TranslateTransition t01 = new TranslateTransition();
                    t01.setNode(i1);
                    t01.setInterpolator(Interpolator.LINEAR);

                    t01.setByY(-80);
                    t01.setDuration(Duration.millis(800));

                    t01.setOnFinished(event -> fallbackOrc(i1));
                    // t01.setAutoReverse(true);
//                    i1.setCache(true);
//                    i1.setCacheHint(CacheHint.SPEED);
                    t01.play();
                }
                if (i2.getId().equals("isl55")) {
                    TranslateTransition t01 = new TranslateTransition();
                    t01.setNode(i1);
                    t01.setInterpolator(Interpolator.LINEAR);

                    t01.setByY(-80);
                    t01.setDuration(Duration.millis(800));

                    t01.setOnFinished(event -> fallbackOrc(i1));
                    // t01.setAutoReverse(true);
//                    i1.setCache(true);
//                    i1.setCacheHint(CacheHint.SPEED);
                    t01.play();
                }
                if (i2.getId().equals("isl54")) {
                    TranslateTransition t01 = new TranslateTransition();
                    t01.setNode(i1);
                    t01.setInterpolator(Interpolator.LINEAR);

                    t01.setByY(-80);
                    t01.setDuration(Duration.millis(800));

                    t01.setOnFinished(event -> fallbackOrc(i1));
                    // t01.setAutoReverse(true);
//                    i1.setCache(true);
//                    i1.setCacheHint(CacheHint.SPEED);
                    t01.play();
                }
                if (i2.getId().equals("isl6")) {
                    TranslateTransition t01 = new TranslateTransition();
                    t01.setNode(i1);
                    t01.setInterpolator(Interpolator.LINEAR);

                    t01.setByY(-80);
                    t01.setDuration(Duration.millis(800));

                    t01.setOnFinished(event -> fallbackOrc(i1));
                    // t01.setAutoReverse(true);
//                    i1.setCache(true);
//                    i1.setCacheHint(CacheHint.SPEED);
                    t01.play();
                }
                if (i2.getId().equals("isl7")) {
                    TranslateTransition t01 = new TranslateTransition();
                    t01.setNode(i1);
                    t01.setInterpolator(Interpolator.LINEAR);

                    t01.setByY(-80);
                    t01.setDuration(Duration.millis(800));

                    t01.setOnFinished(event -> fallbackOrc(i1));
                    // t01.setAutoReverse(true);
//                    i1.setCache(true);
//                    i1.setCacheHint(CacheHint.SPEED);
                    t01.play();
                }
                if (i2.getId().equals("isl8")) {
                    TranslateTransition t01 = new TranslateTransition();
                    t01.setNode(i1);
                    t01.setInterpolator(Interpolator.LINEAR);

                    t01.setByY(-80);
                    t01.setDuration(Duration.millis(800));

                    t01.setOnFinished(event -> fallbackOrc(i1));
                    // t01.setAutoReverse(true);
//                    i1.setCache(true);
//                    i1.setCacheHint(CacheHint.SPEED);
                    t01.play();
                }
                if (i2.getId().equals("isl9")) {
                    TranslateTransition t01 = new TranslateTransition();
                    t01.setNode(i1);
                    t01.setInterpolator(Interpolator.LINEAR);

                    t01.setByY(-80);
                    t01.setDuration(Duration.millis(800));

                    t01.setOnFinished(event -> fallbackOrc(i1));
                    // t01.setAutoReverse(true);
//                    i1.setCache(true);
//                    i1.setCacheHint(CacheHint.SPEED);
                    t01.play();
                }
                if (i2.getId().equals("isl91")) {
                    TranslateTransition t01 = new TranslateTransition();
                    t01.setNode(i1);
                    t01.setInterpolator(Interpolator.LINEAR);

                    t01.setByY(-80);
                    t01.setDuration(Duration.millis(800));

                    t01.setOnFinished(event -> fallbackOrc(i1));
                    // t01.setAutoReverse(true);
//                    i1.setCache(true);
//                    i1.setCacheHint(CacheHint.SPEED);
                    t01.play();
                }
                if (i2.getId().equals("isl911")) {
                    TranslateTransition t01 = new TranslateTransition();
                    t01.setNode(i1);
                    t01.setInterpolator(Interpolator.LINEAR);

                    t01.setByY(-80);
                    t01.setDuration(Duration.millis(800));

                    t01.setOnFinished(event -> fallbackOrc(i1));
                    // t01.setAutoReverse(true);
//                    i1.setCache(true);
//                    i1.setCacheHint(CacheHint.SPEED);
                    t01.play();
                }

                if (i2.getId().equals("marble1")) {

                    TranslateTransition t01 = new TranslateTransition();
                    t01.setNode(i1);
                    t01.setInterpolator(Interpolator.LINEAR);
                    t01.setByY(-80);
                    t01.setDuration(Duration.millis(800));
                    t01.setOnFinished(event -> fallbackOrc(i1));
                    //t01.setCycleCount(TranslateTransition.INDEFINITE);
                    // t01.setAutoReverse(true);
//                heroimg.setCache(true);
//                heroimg.setCacheHint(CacheHint.SPEED);
                    t01.play();
                }

                if (i2.getId().equals("marble2")) {

                    TranslateTransition t01 = new TranslateTransition();
                    t01.setNode(i1);
                    t01.setInterpolator(Interpolator.LINEAR);
                    t01.setByY(-80);
                    t01.setDuration(Duration.millis(800));
                    t01.setOnFinished(event -> fallbackOrc(i1));
                    //t01.setCycleCount(TranslateTransition.INDEFINITE);
                    // t01.setAutoReverse(true);
//                heroimg.setCache(true);
//                heroimg.setCacheHint(CacheHint.SPEED);
                    t01.play();
                }

                if (i2.getId().equals("marble3")) {

                    TranslateTransition t01 = new TranslateTransition();
                    t01.setNode(i1);
                    t01.setInterpolator(Interpolator.LINEAR);
                    t01.setByY(-80);
                    t01.setDuration(Duration.millis(800));
                    t01.setOnFinished(event -> fallbackOrc(i1));
                    //t01.setCycleCount(TranslateTransition.INDEFINITE);
                    // t01.setAutoReverse(true);
//                heroimg.setCache(true);
//                heroimg.setCacheHint(CacheHint.SPEED);
                    t01.play();
                }

            }
        }
    }

    public void checkCollisionOrcOrc(ImageView i1, ImageView i2){

        if ((i1.getBoundsInParent()).intersects(i2.getBoundsInParent())) {
            // System.out.println("CEHCK1" + i1.getId() + i2.getId());
            //  camera.translateXProperty().set(heroimg.translateXProperty().getValue())
            if(i1.getBoundsInParent().getMaxX()>=i2.getBoundsInParent().getMinX()) {
                TranslateTransition t1 = new TranslateTransition();
                TranslateTransition t2 = new TranslateTransition();
                t1.setByX(-40);
                t1.setDuration(Duration.millis(300));
                t1.setNode(i1);
                t1.play();
                t2.setNode(i2);
                t2.setDuration(Duration.millis(300));
                t2.setByX(40);
                t2.play();
            }
            if(i2.getBoundsInParent().getMaxX()>=i1.getBoundsInParent().getMinX()) {
                TranslateTransition t1 = new TranslateTransition();
                TranslateTransition t2 = new TranslateTransition();
                t1.setByX(40);
                t1.setDuration(Duration.millis(300));
                t1.setNode(i1);
                t1.play();
                t2.setNode(i2);
                t2.setDuration(Duration.millis(300));
                t2.setByX(-40);
                t2.play();
            }

        }

    }

    public void checkCollisionBridge(ImageView i1, ImageView i2){
        //i2 : bridge bricks
        //i1: hero or orcs
        int delay= 300;
        TranslateTransition t01 = new TranslateTransition();
        TranslateTransition b01 = new TranslateTransition();
        TranslateTransition b02 = new TranslateTransition();
        TranslateTransition b03 = new TranslateTransition();
        TranslateTransition b04 = new TranslateTransition();
        TranslateTransition b05 = new TranslateTransition();
        TranslateTransition b06 = new TranslateTransition();
        TranslateTransition b07 = new TranslateTransition();
        b01.setNode(brick1);
        b01.setByY(500);
        b01.setDuration(Duration.millis(delay));
        b02.setNode(brick2);
        b02.setByY(500);
        b02.setDuration(Duration.millis(delay));
        b03.setNode(brick3);
        b03.setByY(500);
        b03.setDuration(Duration.millis(delay));
        b04.setNode(brick4);
        b04.setByY(500);
        b04.setDuration(Duration.millis(delay));
        b05.setNode(brick5);
        b05.setByY(500);
        b05.setDuration(Duration.millis(delay));
        b06.setNode(brick6);
        b06.setByY(500);
        b06.setDuration(Duration.millis(delay));
        b07.setNode(brick7);
        b07.setByY(500);
        b07.setDuration(Duration.millis(delay));

       // TranslateTransition t01 = new TranslateTransition();
        TranslateTransition b011 = new TranslateTransition();
        TranslateTransition b021 = new TranslateTransition();
        TranslateTransition b031 = new TranslateTransition();
        TranslateTransition b041 = new TranslateTransition();
        TranslateTransition b051 = new TranslateTransition();
        TranslateTransition b061 = new TranslateTransition();
        TranslateTransition b071 = new TranslateTransition();
        b011.setNode(brick11);
        b011.setByY(500);
        b011.setDuration(Duration.millis(delay));
        b021.setNode(brick21);
        b021.setByY(500);
        b021.setDuration(Duration.millis(delay));
        b031.setNode(brick31);
        b031.setByY(500);
        b031.setDuration(Duration.millis(delay));
        b041.setNode(brick41);
        b041.setByY(500);
        b041.setDuration(Duration.millis(delay));
        b051.setNode(brick51);
        b051.setByY(500);
        b051.setDuration(Duration.millis(delay));
        b061.setNode(brick61);
        b061.setByY(500);
        b061.setDuration(Duration.millis(delay));
        b071.setNode(brick71);
        b071.setByY(500);
        b071.setDuration(Duration.millis(delay));

        TranslateTransition b0111 = new TranslateTransition();
        TranslateTransition b0211 = new TranslateTransition();
        TranslateTransition b0311 = new TranslateTransition();
        TranslateTransition b0411 = new TranslateTransition();
        TranslateTransition b0511 = new TranslateTransition();
        TranslateTransition b0611 = new TranslateTransition();
        TranslateTransition b0711 = new TranslateTransition();
        b0111.setNode(brick111);
        b0111.setByY(500);
        b0111.setDuration(Duration.millis(delay));
        b0211.setNode(brick211);
        b0211.setByY(500);
        b0211.setDuration(Duration.millis(delay));
        b0311.setNode(brick311);
        b0311.setByY(500);
        b0311.setDuration(Duration.millis(delay));
        b0411.setNode(brick411);
        b0411.setByY(500);
        b0411.setDuration(Duration.millis(delay));
        b0511.setNode(brick511);
        b0511.setByY(500);
        b0511.setDuration(Duration.millis(delay));
        b0611.setNode(brick611);
        b0611.setByY(500);
        b0611.setDuration(Duration.millis(delay));
        b0711.setNode(brick711);
        b0711.setByY(500);
        b0711.setDuration(Duration.millis(delay));

        TranslateTransition b0112 = new TranslateTransition();
        TranslateTransition b0212 = new TranslateTransition();
        TranslateTransition b0312 = new TranslateTransition();
        TranslateTransition b0412 = new TranslateTransition();
        TranslateTransition b0512 = new TranslateTransition();
        TranslateTransition b0612 = new TranslateTransition();
        TranslateTransition b0712 = new TranslateTransition();
        b0112.setNode(brick112);
        b0112.setByY(500);
        b0112.setDuration(Duration.millis(delay));
        b0212.setNode(brick212);
        b0212.setByY(500);
        b0212.setDuration(Duration.millis(delay));
        b0312.setNode(brick312);
        b0312.setByY(500);
        b0312.setDuration(Duration.millis(delay));
        b0412.setNode(brick412);
        b0412.setByY(500);
        b0412.setDuration(Duration.millis(delay));
        b0512.setNode(brick512);
        b0512.setByY(500);
        b0512.setDuration(Duration.millis(delay));
        b0612.setNode(brick612);
        b0612.setByY(500);
        b0612.setDuration(Duration.millis(delay));
        b0712.setNode(brick712);
        b0712.setByY(500);
        b0712.setDuration(Duration.millis(delay));
        if ((i1.getBoundsInParent()).intersects(i2.getBoundsInParent())) {
            //System.out.println("Check3");
//
            if(i1.getBoundsInParent().getMaxY()>=i2.getBoundsInParent().getMinY() && !(i1.getBoundsInParent().getMaxY()>i2.getBoundsInParent().getMinY()+10)) {
                // System.out.println("Check2");
                //t02.setNode(i1);
                //t01.wait(50);
                if(i1.getId().equals("heroimg")) {
                    //System.out.println("Check1");
                    if (i2.getId().equals("brick1")) {

                        t01.setNode(heroimg);
                        t01.setInterpolator(Interpolator.LINEAR);
                        t01.setByY(-100);
                        t01.setDuration(Duration.millis(500));
                        t01.setOnFinished(event -> fallbackHero());
                        //t01.setCycleCount(TranslateTransition.INDEFINITE);
                        // t01.setAutoReverse(true);
//                heroimg.setCache(true);
//                heroimg.setCacheHint(CacheHint.SPEED);
                        t01.play();
                        SequentialTransition seqT = new SequentialTransition (b01,b02,b03,b04,b05,b06,b07);
                        seqT.play();

                    }
                    if (i2.getId().equals("brick2")) {
                        t01.setNode(heroimg);
                        t01.setInterpolator(Interpolator.LINEAR);

                        t01.setByY(-100);
                        t01.setDuration(Duration.millis(500));
                        t01.setOnFinished(event -> fallbackHero());
                        //t01.setCycleCount(TranslateTransition.INDEFINITE);
                        // t01.setAutoReverse(true);
//                heroimg.setCache(true);
//                heroimg.setCacheHint(CacheHint.SPEED);
                        t01.play();
                        SequentialTransition seqT = new SequentialTransition (b01,b02,b03,b04,b05,b06,b07);
                        seqT.play();

                    }
                    if (i2.getId().equals("brick3")) {
                        t01.setNode(heroimg);
                        t01.setInterpolator(Interpolator.LINEAR);

                        t01.setByY(-100);
                        t01.setDuration(Duration.millis(500));
                        t01.setOnFinished(event -> fallbackHero());
                        //t01.setCycleCount(TranslateTransition.INDEFINITE);
                        // t01.setAutoReverse(true);
                        heroimg.setCache(true);
                        heroimg.setCacheHint(CacheHint.SPEED);
                        t01.play();
                        SequentialTransition seqT = new SequentialTransition (b01,b02,b03,b04,b05,b06,b07);
                        seqT.play();
                    }
                    if (i2.getId().equals("brick4")) {
                        t01.setNode(heroimg);
                        t01.setInterpolator(Interpolator.LINEAR);

                        t01.setByY(-100);
                        t01.setDuration(Duration.millis(800));

                        t01.setOnFinished(event -> fallbackHero());
                        // t01.setAutoReverse(true);
                        heroimg.setCache(true);
                        heroimg.setCacheHint(CacheHint.SPEED);
                        t01.play();
                        SequentialTransition seqT = new SequentialTransition (b01,b02,b03,b04,b05,b06,b07);
                        seqT.play();
                    }
                    if (i2.getId().equals("brick5")) {
                        t01.setNode(heroimg);
                        t01.setInterpolator(Interpolator.LINEAR);

                        t01.setByY(-100);
                        t01.setDuration(Duration.millis(800));

                        t01.setOnFinished(event -> fallbackHero());
                        // t01.setAutoReverse(true);
                        heroimg.setCache(true);
                        heroimg.setCacheHint(CacheHint.SPEED);
                        t01.play();
                        SequentialTransition seqT = new SequentialTransition (b01,b02,b03,b04,b05,b06,b07);
                        seqT.play();
                    }
                    if (i2.getId().equals("brick6")) {
                        t01.setNode(heroimg);
                        t01.setInterpolator(Interpolator.LINEAR);

                        t01.setByY(-100);
                        t01.setDuration(Duration.millis(800));

                        t01.setOnFinished(event -> fallbackHero());
                        // t01.setAutoReverse(true);
                        heroimg.setCache(true);
                        heroimg.setCacheHint(CacheHint.SPEED);
                        t01.play();
                        SequentialTransition seqT = new SequentialTransition (b01,b02,b03,b04,b05,b06,b07);
                        seqT.play();
                    }
                    if (i2.getId().equals("brick7")) {
                        t01.setNode(heroimg);
                        t01.setInterpolator(Interpolator.LINEAR);

                        t01.setByY(-100);
                        t01.setDuration(Duration.millis(800));

                        t01.setOnFinished(event -> fallbackHero());
                        // t01.setAutoReverse(true);
//                        heroimg.setCache(true);
//                        heroimg.setCacheHint(CacheHint.SPEED);
                        t01.play();
                        SequentialTransition seqT = new SequentialTransition (b01,b02,b03,b04,b05,b06,b07);
                        seqT.play();
                    }

                    if (i2.getId().equals("brick11")) {

                        t01.setNode(heroimg);
                        t01.setInterpolator(Interpolator.LINEAR);
                        t01.setByY(-100);
                        t01.setDuration(Duration.millis(500));
                        t01.setOnFinished(event -> fallbackHero());
                        //t01.setCycleCount(TranslateTransition.INDEFINITE);
                        // t01.setAutoReverse(true);
//                heroimg.setCache(true);
//                heroimg.setCacheHint(CacheHint.SPEED);
                        t01.play();
                        SequentialTransition seqT = new SequentialTransition (b011,b021,b031,b041,b051,b061,b071);
                        seqT.play();

                    }
                    if (i2.getId().equals("brick21")) {
                        t01.setNode(heroimg);
                        t01.setInterpolator(Interpolator.LINEAR);

                        t01.setByY(-100);
                        t01.setDuration(Duration.millis(500));
                        t01.setOnFinished(event -> fallbackHero());
                        //t01.setCycleCount(TranslateTransition.INDEFINITE);
                        // t01.setAutoReverse(true);
//                heroimg.setCache(true);
//                heroimg.setCacheHint(CacheHint.SPEED);
                        t01.play();
                        SequentialTransition seqT = new SequentialTransition (b011,b021,b031,b041,b051,b061,b071);
                        seqT.play();

                    }
                    if (i2.getId().equals("brick31")) {
                        t01.setNode(heroimg);
                        t01.setInterpolator(Interpolator.LINEAR);

                        t01.setByY(-100);
                        t01.setDuration(Duration.millis(500));
                        t01.setOnFinished(event -> fallbackHero());
                        //t01.setCycleCount(TranslateTransition.INDEFINITE);
                        // t01.setAutoReverse(true);
                        heroimg.setCache(true);
                        heroimg.setCacheHint(CacheHint.SPEED);
                        t01.play();
                        SequentialTransition seqT = new SequentialTransition (b011,b021,b031,b041,b051,b061,b071);
                        seqT.play();
                    }
                    if (i2.getId().equals("brick41")) {
                        t01.setNode(heroimg);
                        t01.setInterpolator(Interpolator.LINEAR);

                        t01.setByY(-100);
                        t01.setDuration(Duration.millis(800));

                        t01.setOnFinished(event -> fallbackHero());
                        // t01.setAutoReverse(true);
                        heroimg.setCache(true);
                        heroimg.setCacheHint(CacheHint.SPEED);
                        t01.play();
                        SequentialTransition seqT = new SequentialTransition (b011,b021,b031,b041,b051,b061,b071);
                        seqT.play();
                    }
                    if (i2.getId().equals("brick51")) {
                        t01.setNode(heroimg);
                        t01.setInterpolator(Interpolator.LINEAR);

                        t01.setByY(-100);
                        t01.setDuration(Duration.millis(800));

                        t01.setOnFinished(event -> fallbackHero());
                        // t01.setAutoReverse(true);
                        heroimg.setCache(true);
                        heroimg.setCacheHint(CacheHint.SPEED);
                        t01.play();
                        SequentialTransition seqT = new SequentialTransition (b011,b021,b031,b041,b051,b061,b071);
                        seqT.play();
                    }

                    if (i2.getId().equals("brick61")) {
                        t01.setNode(heroimg);
                        t01.setInterpolator(Interpolator.LINEAR);

                        t01.setByY(-100);
                        t01.setDuration(Duration.millis(800));

                        t01.setOnFinished(event -> fallbackHero());
                        // t01.setAutoReverse(true);
                        heroimg.setCache(true);
                        heroimg.setCacheHint(CacheHint.SPEED);
                        t01.play();
                        SequentialTransition seqT = new SequentialTransition (b011,b021,b031,b041,b051,b061,b071);
                        seqT.play();
                    }
                    if (i2.getId().equals("brick71")) {
                        t01.setNode(heroimg);
                        t01.setInterpolator(Interpolator.LINEAR);

                        t01.setByY(-100);
                        t01.setDuration(Duration.millis(800));

                        t01.setOnFinished(event -> fallbackHero());
                        // t01.setAutoReverse(true);
//                        heroimg.setCache(true);
//                        heroimg.setCacheHint(CacheHint.SPEED);
                        t01.play();
                        SequentialTransition seqT = new SequentialTransition (b011,b021,b031,b041,b051,b061,b071);
                        seqT.play();
                    }

                    if (i2.getId().equals("brick112")) {

                        t01.setNode(heroimg);
                        t01.setInterpolator(Interpolator.LINEAR);
                        t01.setByY(-100);
                        t01.setDuration(Duration.millis(500));
                        t01.setOnFinished(event -> fallbackHero());
                        //t01.setCycleCount(TranslateTransition.INDEFINITE);
                        // t01.setAutoReverse(true);
//                heroimg.setCache(true);
//                heroimg.setCacheHint(CacheHint.SPEED);
                        t01.play();
                        SequentialTransition seqT = new SequentialTransition (b0112,b0212,b0312,b0412,b0512,b0612,b0712);
                        seqT.play();

                    }
                    if (i2.getId().equals("brick212")) {
                        t01.setNode(heroimg);
                        t01.setInterpolator(Interpolator.LINEAR);

                        t01.setByY(-100);
                        t01.setDuration(Duration.millis(500));
                        t01.setOnFinished(event -> fallbackHero());
                        //t01.setCycleCount(TranslateTransition.INDEFINITE);
                        // t01.setAutoReverse(true);
//                heroimg.setCache(true);
//                heroimg.setCacheHint(CacheHint.SPEED);
                        t01.play();
                        SequentialTransition seqT = new SequentialTransition (b0112,b0212,b0312,b0412,b0512,b0612,b0712);
                        seqT.play();

                    }
                    if (i2.getId().equals("brick312")) {
                        t01.setNode(heroimg);
                        t01.setInterpolator(Interpolator.LINEAR);

                        t01.setByY(-100);
                        t01.setDuration(Duration.millis(500));
                        t01.setOnFinished(event -> fallbackHero());
                        //t01.setCycleCount(TranslateTransition.INDEFINITE);
                        // t01.setAutoReverse(true);
                        heroimg.setCache(true);
                        heroimg.setCacheHint(CacheHint.SPEED);
                        t01.play();
                        SequentialTransition seqT = new SequentialTransition (b0112,b0212,b0312,b0412,b0512,b0612,b0712);
                        seqT.play();
                    }
                    if (i2.getId().equals("brick412")) {
                        t01.setNode(heroimg);
                        t01.setInterpolator(Interpolator.LINEAR);

                        t01.setByY(-100);
                        t01.setDuration(Duration.millis(800));

                        t01.setOnFinished(event -> fallbackHero());
                        // t01.setAutoReverse(true);
                        heroimg.setCache(true);
                        heroimg.setCacheHint(CacheHint.SPEED);
                        t01.play();
                        SequentialTransition seqT = new SequentialTransition (b0112,b0212,b0312,b0412,b0512,b0612,b0712);
                        seqT.play();
                    }
                    if (i2.getId().equals("brick512")) {
                        t01.setNode(heroimg);
                        t01.setInterpolator(Interpolator.LINEAR);

                        t01.setByY(-100);
                        t01.setDuration(Duration.millis(800));

                        t01.setOnFinished(event -> fallbackHero());
                        // t01.setAutoReverse(true);
                        heroimg.setCache(true);
                        heroimg.setCacheHint(CacheHint.SPEED);
                        t01.play();
                        SequentialTransition seqT = new SequentialTransition (b0112,b0212,b0312,b0412,b0512,b0612,b0712);
                        seqT.play();
                    }

                    if (i2.getId().equals("brick612")) {
                        t01.setNode(heroimg);
                        t01.setInterpolator(Interpolator.LINEAR);

                        t01.setByY(-100);
                        t01.setDuration(Duration.millis(800));

                        t01.setOnFinished(event -> fallbackHero());
                        // t01.setAutoReverse(true);
                        heroimg.setCache(true);
                        heroimg.setCacheHint(CacheHint.SPEED);
                        t01.play();
                        SequentialTransition seqT = new SequentialTransition (b0112,b0212,b0312,b0412,b0512,b0612,b0712);
                        seqT.play();
                    }
                    if (i2.getId().equals("brick712")) {
                        t01.setNode(heroimg);
                        t01.setInterpolator(Interpolator.LINEAR);

                        t01.setByY(-100);
                        t01.setDuration(Duration.millis(800));

                        t01.setOnFinished(event -> fallbackHero());
                        // t01.setAutoReverse(true);
//                        heroimg.setCache(true);
//                        heroimg.setCacheHint(CacheHint.SPEED);
                        t01.play();
                        SequentialTransition seqT = new SequentialTransition (b0112,b0212,b0312,b0412,b0512,b0612,b0712);
                        seqT.play();
                    }

                    if (i2.getId().equals("brick111")) {

                        t01.setNode(heroimg);
                        t01.setInterpolator(Interpolator.LINEAR);
                        t01.setByY(-100);
                        t01.setDuration(Duration.millis(500));
                        t01.setOnFinished(event -> fallbackHero());
                        //t01.setCycleCount(TranslateTransition.INDEFINITE);
                        // t01.setAutoReverse(true);
//                heroimg.setCache(true);
//                heroimg.setCacheHint(CacheHint.SPEED);
                        t01.play();
                        SequentialTransition seqT = new SequentialTransition (b0111,b0211,b0311,b0411,b0511,b0611,b0711);
                        seqT.play();

                    }
                    if (i2.getId().equals("brick211")) {
                        t01.setNode(heroimg);
                        t01.setInterpolator(Interpolator.LINEAR);

                        t01.setByY(-100);
                        t01.setDuration(Duration.millis(500));
                        t01.setOnFinished(event -> fallbackHero());
                        //t01.setCycleCount(TranslateTransition.INDEFINITE);
                        // t01.setAutoReverse(true);
//                heroimg.setCache(true);
//                heroimg.setCacheHint(CacheHint.SPEED);
                        t01.play();
                        SequentialTransition seqT = new SequentialTransition (b0111,b0211,b0311,b0411,b0511,b0611,b0711);
                        seqT.play();

                    }
                    if (i2.getId().equals("brick311")) {
                        t01.setNode(heroimg);
                        t01.setInterpolator(Interpolator.LINEAR);

                        t01.setByY(-100);
                        t01.setDuration(Duration.millis(500));
                        t01.setOnFinished(event -> fallbackHero());
                        //t01.setCycleCount(TranslateTransition.INDEFINITE);
                        // t01.setAutoReverse(true);
                        heroimg.setCache(true);
                        heroimg.setCacheHint(CacheHint.SPEED);
                        t01.play();
                        SequentialTransition seqT = new SequentialTransition (b0111,b0211,b0311,b0411,b0511,b0611,b0711);
                        seqT.play();
                    }
                    if (i2.getId().equals("brick411")) {
                        t01.setNode(heroimg);
                        t01.setInterpolator(Interpolator.LINEAR);

                        t01.setByY(-100);
                        t01.setDuration(Duration.millis(800));

                        t01.setOnFinished(event -> fallbackHero());
                        // t01.setAutoReverse(true);
                        heroimg.setCache(true);
                        heroimg.setCacheHint(CacheHint.SPEED);
                        t01.play();
                        SequentialTransition seqT = new SequentialTransition (b0111,b0211,b0311,b0411,b0511,b0611,b0711);
                        seqT.play();
                    }
                    if (i2.getId().equals("brick511")) {
                        t01.setNode(heroimg);
                        t01.setInterpolator(Interpolator.LINEAR);

                        t01.setByY(-100);
                        t01.setDuration(Duration.millis(800));

                        t01.setOnFinished(event -> fallbackHero());
                        // t01.setAutoReverse(true);
                        heroimg.setCache(true);
                        heroimg.setCacheHint(CacheHint.SPEED);
                        t01.play();
                        SequentialTransition seqT = new SequentialTransition (b0111,b0211,b0311,b0411,b0511,b0611,b0711);
                        seqT.play();
                    }

                    if (i2.getId().equals("brick611")) {
                        t01.setNode(heroimg);
                        t01.setInterpolator(Interpolator.LINEAR);

                        t01.setByY(-100);
                        t01.setDuration(Duration.millis(800));

                        t01.setOnFinished(event -> fallbackHero());
                        // t01.setAutoReverse(true);
                        heroimg.setCache(true);
                        heroimg.setCacheHint(CacheHint.SPEED);
                        t01.play();
                        SequentialTransition seqT = new SequentialTransition (b0111,b0211,b0311,b0411,b0511,b0611,b0711);
                        seqT.play();
                    }
                    if (i2.getId().equals("brick711")) {
                        t01.setNode(heroimg);
                        t01.setInterpolator(Interpolator.LINEAR);

                        t01.setByY(-100);
                        t01.setDuration(Duration.millis(800));

                        t01.setOnFinished(event -> fallbackHero());
                        // t01.setAutoReverse(true);
//                        heroimg.setCache(true);
//                        heroimg.setCacheHint(CacheHint.SPEED);
                        t01.play();
                        SequentialTransition seqT = new SequentialTransition (b0111,b0211,b0311,b0411,b0511,b0611,b0711);
                        seqT.play();
                    }


                }
                else if(i1.getId().equals("greenorc") ||i1.getId().equals("greenorc2")|| i1.getId().equals("greenorc3") || i1.getId().equals("greenorc4") || i1.getId().equals("boss") || i1.getId().equals("redorc1") || i1.getId().equals("redorc2") || i1.getId().equals("redorc3") || i1.getId().equals("redorc4") || i1.getId().equals("redorc5") || i1.getId().equals("bigorc1") || i1.getId().equals("redorc")) {
                    TranslateTransition t0 = new TranslateTransition();
                    t0.setNode(i1);
                    t0.setInterpolator(Interpolator.LINEAR);
                    t0.setByY(-100);
                    t0.setDuration(Duration.millis(500));
                    t0.setOnFinished(event -> fallbackOrc(i1));
                    //t01.setCycleCount(TranslateTransition.INDEFINITE);
                    // t01.setAutoReverse(true);
//                heroimg.setCache(true);
//                heroimg.setCacheHint(CacheHint.SPEED);
                    t0.play();
                }
            }
        }
        else if(heroimg.getBoundsInParent().getMinY()< i1.getBoundsInParent().getMinY()) {
            //System.out.println("Check1");
            //TranslateTransition t02 = new TranslateTransition();

        }
    }

    int coinCounter=0;
    int checkcoin4=0;
    int checkcoin1=0;
    int checkcoin2=0;
    int checkcoin3=0;
    int checkcoin6=0;
    int checkcoin5=0;
    int checkcoin7=0;
    int checkcoin8=0;
    int checkcoin9=0;

    boolean weaponGot=false;
    boolean weaponGot2=false;
    boolean weaponupg=false;
    boolean equip1=false;
    boolean equip2=false;
    boolean equipupg=false;
    public void checkCollisionHeroCoin(ImageView i){
        if (heroimg.getBoundsInParent().intersects(i.getBoundsInParent())){
            double herotop = heroimg.getBoundsInParent().getMinY();
            double herobot = heroimg.getBoundsInParent().getMaxY();
            double sizeH = herobot-herotop;
            double orcTop = i.getBoundsInParent().getMinY();
            double orcbot = i.getBoundsInParent().getMaxY();
            //  System.out.println(herotop + " " + herobot +" " + sizeH + " " +orcTop + " " + orcbot );
            if((heroimg.getBoundsInParent().getMaxX()>=i.getBoundsInParent().getMinX())  ){
                //    System.out.println("Check");
                if (i.getId().equals("coin1")) {
                    checkcoin1++;
                    if(checkcoin1==1){
                        coinCounter++;}
                    //TranslateTransition t01 = new TranslateTransition();
                    TranslateTransition t02 = new TranslateTransition();

                    cntrlabel.setText(Integer.toString(coinCounter));
                    t02.setNode(coin1);
                    t02.setByX(1000);
                    t02.setByY(1000);
                    t02.setInterpolator(Interpolator.LINEAR);
                    t02.setDuration(Duration.millis(1));
                    System.out.println(i.getId() + " Collected, coins= "+ coinCounter);

                    t02.play();

                }
                if (i.getId().equals("coin2")) {
                    // if(heroimg.getBoundsInParent().getMaxX()>=greenorc.getBoundsInParent().getMinX() &&  (heroimg.getBoundsInParent().getMaxY()<=greenorc.getBoundsInParent().getMaxY()) ||heroimg.getBoundsInParent().getMaxY()>=greenorc.getBoundsInParent().getMinY() ){


                    //TranslateTransition t01 = new TranslateTransition();
                    checkcoin2++;
                    if(checkcoin2==1){
                        coinCounter++;}
                    TranslateTransition t02 = new TranslateTransition();

                    cntrlabel.setText(Integer.toString(coinCounter));
                    t02.setNode(coin2);
                    t02.setByX(1000);
                    t02.setByY(1000);
                    t02.setInterpolator(Interpolator.LINEAR);
                    t02.setDuration(Duration.millis(1));
                    System.out.println(i.getId() + " Collected, coins= "+ coinCounter);

                    t02.play();



                }
                if (i.getId().equals("coin3")) {
                    //  if(heroimg.getBoundsInParent().getMaxX()>=greenorc2.getBoundsInParent().getMinX() ){


                    //TranslateTransition t01 = new TranslateTransition();
                    checkcoin3++;
                    if(checkcoin3==1){
                        coinCounter++;}
                    TranslateTransition t02 = new TranslateTransition();
                    coinCounter++;
                    cntrlabel.setText(Integer.toString(coinCounter));
                    t02.setNode(coin3);
                    t02.setByX(1000);
                    t02.setByY(1000);
                    t02.setInterpolator(Interpolator.LINEAR);
                    t02.setDuration(Duration.millis(1));
                    System.out.println(i.getId() + " Collected, coins= "+ coinCounter);

                    t02.play();



                }
                if (i.getId().equals("coin4")) {
                    //  if(heroimg.getBoundsInParent().getMaxX()>=greenorc3.getBoundsInParent().getMinX() ){


                    //TranslateTransition t01 = new TranslateTransition();
                    checkcoin4++;
                    if(checkcoin4==1){
                        coinCounter++;}
                    TranslateTransition t02 = new TranslateTransition();
                    //coinCounter++;
                    cntrlabel.setText(Integer.toString(coinCounter));
                    t02.setNode(coin4);
                    t02.setByX(1000);
                    t02.setByY(1000);
                    t02.setInterpolator(Interpolator.LINEAR);
                    t02.setDuration(Duration.millis(1));
                    System.out.println(i.getId() + " Collected, coins= "+ coinCounter);

                    t02.play();



                }
                if (i.getId().equals("coin5")) {
                    // if(heroimg.getBoundsInParent().getMaxX()>=greenorc4.getBoundsInParent().getMinX() ){


                    //TranslateTransition t01 = new TranslateTransition();
                    checkcoin5++;
                    if(checkcoin5==1){
                        coinCounter++;}
                    TranslateTransition t02 = new TranslateTransition();
                    //coinCounter++;
                    cntrlabel.setText(Integer.toString(coinCounter));
                    t02.setNode(coin5);
                    t02.setByX(1000);
                    t02.setByY(1000);
                    t02.setInterpolator(Interpolator.LINEAR);
                    t02.setDuration(Duration.millis(1));
                    System.out.println(i.getId() + " Collected, coins= "+ coinCounter);

                    t02.play();



                }
                if (i.getId().equals("coin6")) {
                    //if(heroimg.getBoundsInParent().getMaxX()>=redorc.getBoundsInParent().getMinX() ){

                    checkcoin6++;
                    if(checkcoin6==1){
                        coinCounter++;}
                    //TranslateTransition t01 = new TranslateTransition();
                    TranslateTransition t02 = new TranslateTransition();
                    //coinCounter++;
                    cntrlabel.setText(Integer.toString(coinCounter));
                    t02.setNode(coin6);
                    t02.setByX(1000);
                    t02.setByY(1000);
                    t02.setInterpolator(Interpolator.LINEAR);
                    t02.setDuration(Duration.millis(1));
                    System.out.println(i.getId() + " Collected, coins= "+ coinCounter);

                    t02.play();



                }
                if (i.getId().equals("coin7")) {
                    //  if(heroimg.getBoundsInParent().getMaxX()>=redorc2.getBoundsInParent().getMinX() ){

                    checkcoin7++;
                    if(checkcoin7==1){
                        coinCounter++;}
                    //TranslateTransition t01 = new TranslateTransition();
                    TranslateTransition t02 = new TranslateTransition();
                  //  coinCounter++;
                    cntrlabel.setText(Integer.toString(coinCounter));
                    t02.setNode(coin7);
                    t02.setByX(1000);
                    t02.setByY(1000);
                    t02.setInterpolator(Interpolator.LINEAR);
                    t02.setDuration(Duration.millis(1));
                    System.out.println(i.getId() + " Collected, coins= "+ coinCounter);

                    t02.play();



                }
                if (i.getId().equals("coin8")) {
                    //if(heroimg.getBoundsInParent().getMaxX()>=redorc3.getBoundsInParent().getMinX() ){

                    checkcoin8++;
                    if(checkcoin8==1){
                        coinCounter++;}
                    //TranslateTransition t01 = new TranslateTransition();
                    TranslateTransition t02 = new TranslateTransition();
                    //coinCounter++;
                    cntrlabel.setText(Integer.toString(coinCounter));
                    t02.setNode(coin8);
                    t02.setByX(1000);
                    t02.setByY(1000);
                    t02.setInterpolator(Interpolator.LINEAR);
                    t02.setDuration(Duration.millis(1));
                    System.out.println(i.getId() + " Collected, coins= "+ coinCounter);

                    t02.play();



                }
                if (i.getId().equals("coin9")) {


                    checkcoin9++;
                    if(checkcoin9==1){
                        coinCounter++;}
                    //TranslateTransition t01 = new TranslateTransition();
                    TranslateTransition t02 = new TranslateTransition();
                    //coinCounter++;
                    cntrlabel.setText(Integer.toString(coinCounter));
                    t02.setNode(coin9);
                    t02.setByX(1000);
                    t02.setByY(1000);
                    t02.setInterpolator(Interpolator.LINEAR);
                    t02.setDuration(Duration.millis(1));
                    System.out.println(i.getId() + " Collected, coins= "+ coinCounter);

                    t02.play();

                }
               /* if (i.getId().equals("redorc5")) {



                    //TranslateTransition t01 = new TranslateTransition();
                    TranslateTransition t02 = new TranslateTransition();
                    coinCounter++;
                    t02.setNode(coin1);
                    t02.setByX(1000);
                    t02.setByY(1000);
                    t02.setInterpolator(Interpolator.EASE_BOTH);
                    t02.setDuration(Duration.millis(1));
                    System.out.println(i.getId() + " Collected, coins= "+ coinCounter);

                    t02.play();



                }
                if (i.getId().equals("redorc1")) {



                    //TranslateTransition t01 = new TranslateTransition();
                    TranslateTransition t02 = new TranslateTransition();
                    coinCounter++;
                    t02.setNode(coin1);
                    t02.setByX(1000);
                    t02.setByY(1000);
                    t02.setInterpolator(Interpolator.EASE_BOTH);
                    t02.setDuration(Duration.millis(1));
                    System.out.println(i.getId() + " Collected, coins= "+ coinCounter);

                    t02.play();



                }*/
            }

        }


    }


    AnimationTimer collisionTimer;
    AnimationTimer collisionTimer1;
    AnimationTimer collisionTimer2;
    AnimationTimer collisionTimer3;
    AnimationTimer collisionTimer4;
    AnimationTimer collisionTimer5;
    AnimationTimer collisionTimer51;
    AnimationTimer collisionTimer6;
    AnimationTimer collisionTimerchest;
    AnimationTimer collisionTimertnt;
    AnimationTimer spawner;

    double maxscore;

    public void switchtomax(ActionEvent event) throws IOException {

        URL url = new File("src/main/resources/com/example/willherofxfinal/max.fxml").toURI().toURL();
        root = FXMLLoader.load(url);
        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
        maxscore_label = (Label)scene.lookup("#maxscore_label");
        deser_score();
        System.out.println("IN MAX:"+Integer.toString((int)maxscore));
        maxscore_label.setText(Integer.toString((int)maxscore));
    }

    public void switchtoMenu(ActionEvent event) throws IOException {

        URL url = new File("src/main/resources/com/example/willherofxfinal/gameUI.fxml").toURI().toURL();
        root = FXMLLoader.load(url);
        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);

        stage.show();
    }

    public void switchtoWinDisplay(ActionEvent event) throws IOException {

        URL url = new File("src/main/resources/com/example/willherofxfinal/winner.fxml").toURI().toURL();
        root = FXMLLoader.load(url);
        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);

        stage.show();
    }


    public void switchtoins(ActionEvent event) throws IOException {

        URL url = new File("src/main/resources/com/example/willherofxfinal/instructions.fxml").toURI().toURL();
        root = FXMLLoader.load(url);
        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    public void switchtocredits(ActionEvent event) throws IOException {

        URL url = new File("src/main/resources/com/example/willherofxfinal/credits.fxml").toURI().toURL();
        root = FXMLLoader.load(url);
        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    Camera camera = new PerspectiveCamera();
    Boolean heropause=false;

int checkbossdead=0;
    public void switchtoLevel(ActionEvent event) throws IOException, InterruptedException, ClassNotFoundException  {




        Lighting lighting = new Lighting();
        lighting.setDiffuseConstant(1.0);
        lighting.setSpecularConstant(0.0);
        lighting.setSpecularExponent(0.0);
        lighting.setSurfaceScale(0.0);
        lighting.setLight(new Light.Distant(45, 45, Color.GREEN));

//        Image image = new Image("clouds-in-the-sky.png");
//        ImageView bg = new ImageView(image);


        URL url = new File("src/main/resources/com/example/willherofxfinal/level1.fxml").toURI().toURL();
        root = FXMLLoader.load(url);

        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene = new Scene(root,1000,1000);
       // Camera camera = new PerspectiveCamera();
        scene.setCamera(camera);
        stage.setScene(scene);
        winner = (Button)scene.lookup("#winner");
        progbar = (ProgressBar) scene.lookup("#progbar");
        proglabel = (Label) scene.lookup("#proglabel");
        bgnight = (ImageView) scene.lookup("#bgnight");
        progbar.setStyle("-fx-accent: green;");
        cntrlabel = (Label) scene.lookup("#cntrlabel");
        cntrimg = (ImageView) scene.lookup("#cntrimg");
        heart = (ImageView) scene.lookup("#heart");
        heartlabel = (ImageView) scene.lookup("#heartlabel");
        heart.setVisible(false);
        heartlabel.setVisible(false);
        dead = (Button)scene.lookup("#dead");
        test = (Button)scene.lookup("#test");
        test1 = (Button)scene.lookup("#test1");
        right = (Button)scene.lookup("#right");
       // pause = (Button)scene.lookup("#pause");
        deser = (Button)scene.lookup("#deser");
        menu = (Button)scene.lookup("#menu");
        buttonpane = (Pane)scene.lookup("#buttonpane");
  pausemenu = (Pane)scene.lookup("#pausemenu");
       // gameovertext = (Text)scene.lookup("#gameovertext");
        //pausepane = (AnchorPane)scene.lookup("pausepane") ;
       // pausepane.setVisible(false);
        abyss = (ImageView)scene.lookup(("#abyss"));
        abyss.setEffect(lighting);
        menuimg = (ImageView)scene.lookup("#menuimg");
        pauseimg = (ImageView)scene.lookup("#pauseimg");
        menuimg.setPickOnBounds(true);
        pauseimg.setPickOnBounds(true);
        temp1 = (ImageView)scene.lookup("#temp1");
        temp2 = (ImageView)scene.lookup("#temp2");
        obs1 = (ImageView)scene.lookup("#obs1");
        obs2 = (ImageView)scene.lookup("#obs2");
        redorc = (ImageView)scene.lookup("#redorc");
        redorc1 = (ImageView)scene.lookup("#redorc1");
        redorc2 = (ImageView)scene.lookup("#redorc2");
        redorc3 = (ImageView)scene.lookup("#redorc3");
        redorc4 = (ImageView)scene.lookup("#redorc4");
        redorc5 = (ImageView)scene.lookup("#redorc5");
        greenorc = (ImageView)scene.lookup("#greenorc");
        greenorc2 = (ImageView)scene.lookup("#greenorc2");
        greenorc3 = (ImageView)scene.lookup("#greenorc3");
        greenorc4 = (ImageView)scene.lookup("#greenorc4");
        boss = (ImageView)scene.lookup("#boss");
        bigOrc1 = (ImageView)scene.lookup("#bigorc1");
        asgaxe = (ImageView)scene.lookup("#asgaxe");
        chkpnt1 = (ImageView)scene.lookup("#chkpnt1");
        chkpnt2 = (ImageView)scene.lookup("#chkpnt2");
        chkpnt3 = (ImageView)scene.lookup("#chkpnt3");
        chkpnt4 = (ImageView)scene.lookup("#chkpnt4");
        isl1 = (ImageView)scene.lookup("#isl1");
        isl2 = (ImageView)scene.lookup("#isl2");
        isl3 = (ImageView)scene.lookup("#isl3");
        isl4 = (ImageView)scene.lookup("#isl4");
        isl5 = (ImageView)scene.lookup("#isl5");
        isl53 = (ImageView)scene.lookup("#isl53");
        isl531 = (ImageView)scene.lookup("#isl531");
        isl51 = (ImageView)scene.lookup("#isl51");
        isl52 = (ImageView)scene.lookup("#isl52");
        isl55 = (ImageView)scene.lookup("#isl55");
        isl54 = (ImageView)scene.lookup("#isl54");
        isl6 = (ImageView)scene.lookup("#isl6");
        isl7 = (ImageView)scene.lookup("#isl7");
        isl71 = (ImageView)scene.lookup("#isl71");
        isl72 = (ImageView)scene.lookup("#isl72");
        isl73 = (ImageView)scene.lookup("#isl73");
        isl74 = (ImageView)scene.lookup("#isl74");
        isl75 = (ImageView)scene.lookup("#isl75");
        isl76 = (ImageView)scene.lookup("#isl76");
        isl8 = (ImageView)scene.lookup("#isl8");
        isl9 = (ImageView)scene.lookup("#isl9");
        isl911 = (ImageView)scene.lookup("#isl91");
        isl91 = (ImageView)scene.lookup("#isl911");

        marble1 = (ImageView)scene.lookup("#marble1");

        marble2 = (ImageView)scene.lookup("#marble2");
        rect = (VBox) scene.lookup("#rect");
        rect.setVisible(false);
        respbox = (HBox) scene.lookup("#respbox");
        respbox.setVisible(false);
        respvbox = (VBox) scene.lookup("#respvbox");
        respvbox.setVisible(false);
        inrect = (HBox) scene.lookup("#inrect");
        inrect.setVisible(false);
        rspn1 = (ImageView)scene.lookup("#rspn1");
        marble3 = (ImageView)scene.lookup("#marble3");
        chest1 = (ImageView)scene.lookup("#chest1");
        chest12 = (ImageView)scene.lookup("#chest12");
        chest13 = (ImageView)scene.lookup("#chest13");
        chest2= (ImageView)scene.lookup("#chest2");
        chest3= (ImageView)scene.lookup("#chest3");
        chest4= (ImageView)scene.lookup("#chest4");
        chest5= (ImageView)scene.lookup("#chest5");
        chest6= (ImageView)scene.lookup("#chest6");
        chest7 = (ImageView)scene.lookup("#chest7");
        chest8= (ImageView)scene.lookup("#chest8");
        chest9= (ImageView)scene.lookup("#chest9");
        chest10= (ImageView)scene.lookup("#chest10");
        chest11= (ImageView)scene.lookup("#chest11");
        spawnchk= (ImageView)scene.lookup("#spawnchk");
        ryes= (ImageView)scene.lookup("#ryes");
        rno= (ImageView)scene.lookup("#rno");
        ryes.setPickOnBounds(true);
      //  ryes.setVisible(false);
        rno.setPickOnBounds(true);
        //rno.setVisible(false);
        save= (ImageView)scene.lookup("#save");
        load= (ImageView)scene.lookup("#load");
        resume1= (ImageView)scene.lookup("#resume1");
        save.setPickOnBounds(true);
        resume1.setPickOnBounds(true);
        load.setPickOnBounds(true);
        save.setVisible(false);
        resume1.setVisible(false);
        load.setVisible(false);
        one_save= (ImageView)scene.lookup("#one_save");
        one_save.setPickOnBounds(true);
        one_save.setVisible(false);
        two_save= (ImageView)scene.lookup("#two_save");
        two_save.setPickOnBounds(true);
        two_save.setVisible(false);
        one_load= (ImageView)scene.lookup("#one_load");
        one_load.setPickOnBounds(true);
        one_load.setVisible(false);
        two_load= (ImageView)scene.lookup("#two_load");
        two_load.setPickOnBounds(true);
        two_load.setVisible(false);
        tnt1 = (ImageView)scene.lookup("#tnt1");
        tnt12 = (ImageView)scene.lookup("#tnt12");
        tnt13 = (ImageView)scene.lookup("#tnt13");
        tnt14 = (ImageView)scene.lookup("#tnt14");
      //  tnt1 = (ImageView)scene.lookup("#tnt1");
        tnt2= (ImageView)scene.lookup("#tnt2");
        tnt3= (ImageView)scene.lookup("#tnt3");
        tnt4= (ImageView)scene.lookup("#tnt4");
        tnt5= (ImageView)scene.lookup("#tnt5");
        tnt6= (ImageView)scene.lookup("#tnt6");
        tnt7 = (ImageView)scene.lookup("#tnt7");
        tnt8= (ImageView)scene.lookup("#tnt8");
        tnt9= (ImageView)scene.lookup("#tnt9");
        tnt10= (ImageView)scene.lookup("#tnt10");
        tnt11= (ImageView)scene.lookup("#tnt11");

        coin= (ImageView)scene.lookup("#coin");
        coin1 = (ImageView)scene.lookup("#coin1");
        coin2 = (ImageView)scene.lookup("#coin2");
        coin3 = (ImageView)scene.lookup("#coin3");
        coin4 = (ImageView)scene.lookup("#coin4");
        coin5 = (ImageView)scene.lookup("#coin5");
        coin6 = (ImageView)scene.lookup("#coin6");
        coin7 = (ImageView)scene.lookup("#coin7");
        coin8 = (ImageView)scene.lookup("#coin8");
        coin9 = (ImageView)scene.lookup("#coin9");
        brick1=(ImageView)scene.lookup("#brick1");
        brick2=(ImageView)scene.lookup("#brick2");
        brick3=(ImageView)scene.lookup("#brick3");
        brick4=(ImageView)scene.lookup("#brick4");
        brick5=(ImageView)scene.lookup("#brick5");
        brick6=(ImageView)scene.lookup("#brick6");
        brick7=(ImageView)scene.lookup("#brick7");

        brick11=(ImageView)scene.lookup("#brick11");
        brick21=(ImageView)scene.lookup("#brick21");
        brick31=(ImageView)scene.lookup("#brick31");
        brick41=(ImageView)scene.lookup("#brick41");
        brick51=(ImageView)scene.lookup("#brick51");
        brick61=(ImageView)scene.lookup("#brick61");
        brick71=(ImageView)scene.lookup("#brick71");

        brick111=(ImageView)scene.lookup("#brick111");
        brick211=(ImageView)scene.lookup("#brick211");
        brick311=(ImageView)scene.lookup("#brick311");
        brick411=(ImageView)scene.lookup("#brick411");
        brick511=(ImageView)scene.lookup("#brick511");
        brick611=(ImageView)scene.lookup("#brick611");
        brick711=(ImageView)scene.lookup("#brick711");

        brick112=(ImageView)scene.lookup("#brick112");
        brick212=(ImageView)scene.lookup("#brick212");
        brick312=(ImageView)scene.lookup("#brick312");
        brick412=(ImageView)scene.lookup("#brick412");
        brick512=(ImageView)scene.lookup("#brick512");
        brick612=(ImageView)scene.lookup("#brick612");
        brick712=(ImageView)scene.lookup("#brick712");
        tnt1=(ImageView)scene.lookup("#tnt1");
        tnt2=(ImageView)scene.lookup("#tnt2");
        axe=(ImageView)scene.lookup("#weapon1");
        thraxe = (ImageView)scene.lookup("#thraxe");
        chest2.setVisible(false);
        chest3.setVisible(false);
        chest4.setVisible(false);
        chest5.setVisible(false);
        chest6.setVisible(false);
        chest7.setVisible(false);
        chest8.setVisible(false);chest11.setVisible(false);
        chest9.setVisible(false);
        chest10.setVisible(false);
        tnt2.setVisible(false);
        tnt3.setVisible(false);
        tnt4.setVisible(false);tnt9.setVisible(false);
        tnt5.setVisible(false);
        tnt6.setVisible(false);
        tnt7.setVisible(false);
        tnt8.setVisible(false);
        tnt10.setVisible(false);
        tnt11.setVisible(false);
        thraxe.setVisible(false);
        asgaxe.setVisible(false);
        thraxe1 = (ImageView)scene.lookup("#thraxe1");
        thraxe1.setVisible(false);
        thraxe11 = (ImageView)scene.lookup("#thraxe11");
        thraxe11.setVisible(false);
        thraxe12 = (ImageView)scene.lookup("#thraxe12");
        thraxe12.setVisible(false);
        layoutbox= (HBox)scene.lookup("#layoutbox");
        layoutaxe = (ImageView)scene.lookup("#layoutaxe");
        layoutaxe.setVisible(false);
        layoutfire = (ImageView)scene.lookup("#layoutfire");
        layoutfire.setVisible(false);
        layoutasaxe = (ImageView)scene.lookup("#layoutasaxe");
        layoutasaxe.setVisible(false);
        axetext = (Text)scene.lookup("#axetext");
        axetext.setVisible(false);
        firetext = (Text)scene.lookup("#firetext");
        firetext.setVisible(false);
        helmet=(ImageView)scene.lookup("#helmet1");
        //orckilled = (Text)scene.lookup("#orckilled");
        islands.add(temp1);
        islands.add(temp2);
        orcs.add(obs1);
        orcs.add(obs2);
        isl.add(isl1);
        isl.add(isl2);
        isl.add(isl3);
       // gameovertext.setVisible(false);
//        orctoimg.put(obs1,greenorc);
//        orctoimg.put(obs2,redorc);
        pausemenu.setVisible(false);
        stage.show();
        deser_score();

        // orckilled.setVisible(false);
        //IntStream.range(0, 1).forEach(
                //i ->
        test.fire();
        //test.setDisable(true);
        menuimg.addEventHandler(MouseEvent.MOUSE_PRESSED, new EventHandler<MouseEvent>(){
            @Override
            public void handle(MouseEvent mouseEvent) {
                menu.fire();
            }
        });

        pauseimg.addEventHandler(MouseEvent.MOUSE_RELEASED, new EventHandler<MouseEvent>(){
            @Override
            public void handle(MouseEvent mouseEvent) {


                rect.setVisible(true);
                inrect.setVisible(true);
                heropause=true;
                save.setVisible(true);
                resume1.setVisible(true);
                load.setVisible(true);
            }
        });

        resume1.addEventHandler(MouseEvent.MOUSE_RELEASED, new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                try {
                    System.out.println("RESUME");
                    deser1();
                    rect.setVisible(false);
//                    inrect.setVisible(false);
                    heropause=false;
//                    resume1.setVisible(false);
//                    load.setVisible(false);
//                    save.setVisible(false);
//                    one_load.setVisible(false);
//                    two_load.setVisible(false);
//                    one_save.setVisible(false);
//                    two_save.setVisible(false);
                } catch (IOException e) {
                    e.printStackTrace();
                } catch (ClassNotFoundException e) {
                    e.printStackTrace();
                }
            }
        });

        two_save.addEventHandler(MouseEvent.MOUSE_RELEASED, new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                ser_save1(spawncounter,coinCounter,progress);
                rect.setVisible(false);
//                inrect.setVisible(false);
                heropause=false;
//                resume1.setVisible(false);
//                load.setVisible(false);
//                save.setVisible(false);
//                one_save.setVisible(false);
//                two_save.setVisible(false);
            }
        });

        one_save.addEventHandler(MouseEvent.MOUSE_RELEASED, new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                ser_save(spawncounter,coinCounter,progress);
                rect.setVisible(false);
//                inrect.setVisible(false);
                heropause=false;
//                resume1.setVisible(false);
//                load.setVisible(false);
//                save.setVisible(false);
//                one_save.setVisible(false);
//                two_save.setVisible(false);
            }
        });

        save.addEventHandler(MouseEvent.MOUSE_RELEASED, new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                //ser_save(spawncounter,coinCounter,progress);
                one_save.setVisible(true);
                two_save.setVisible(true);
            }
        });

        load.addEventHandler(MouseEvent.MOUSE_RELEASED, new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {

                one_load.setVisible(true);
                two_load.setVisible(true);
            }
        });

        one_load.addEventHandler(MouseEvent.MOUSE_CLICKED, new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                try {
                    System.out.println("RESUME");
                    deser_save();
                    heropause=false;
                    rect.setVisible(false);
//                    inrect.setVisible(false);
//                    resume1.setVisible(false);
//                    load.setVisible(false);
//                    save.setVisible(false);
//                    one_load.setVisible(false);
//                    two_load.setVisible(false);
                } catch (IOException e) {
                    e.printStackTrace();
                } catch (ClassNotFoundException e) {
                    e.printStackTrace();
                }
            }
        });

        two_load.addEventHandler(MouseEvent.MOUSE_CLICKED, new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                try {
                    System.out.println("RESUME");
                    deser_save1();
                    heropause=false;
                    rect.setVisible(false);

                } catch (IOException e) {
                    e.printStackTrace();
                } catch (ClassNotFoundException e) {
                    e.printStackTrace();
                }
            }
        });


         spawner = new AnimationTimer() {
             @Override
             public void handle(long now) {

                 checkHero();
             }

         };
        spawner.start();
        collisionTimer=new AnimationTimer() {
            @Override
            public void handle(long l) {
                heroimg = (ImageView)scene.lookup("#heroimg");

                    try {
                        if (!herodead) {
                            try{
                            checkCollisionspwan();}
                            catch(IOException e1){}
                            catch( ClassNotFoundException e2){};
                            checkCollisionHeroIsland(isl1);
                            checkCollisionHeroIsland(isl2);
                            checkCollisionHeroIsland(isl3);
                            checkCollisionHeroIsland(isl4);
                            checkCollisionHeroIsland(isl5);
                            checkCollisionHeroIsland(isl51);
                            checkCollisionHeroIsland(isl52);
                            checkCollisionHeroIsland(isl53);
                            checkCollisionHeroIsland(isl531);
                            checkCollisionHeroIsland(isl55);
                            checkCollisionHeroIsland(isl54);
                            checkCollisionHeroIsland(isl6);
                            checkCollisionHeroIsland(isl7);
                            checkCollisionHeroIsland(isl71);
                            checkCollisionHeroIsland(isl72);
                            checkCollisionHeroIsland(isl73);
                            checkCollisionHeroIsland(isl74);
                            checkCollisionHeroIsland(isl75);
                            checkCollisionHeroIsland(isl76);
                            checkCollisionHeroIsland(isl8);
                            checkCollisionHeroIsland(isl9);
                            checkCollisionHeroIsland(isl91);
                            checkCollisionHeroIsland(isl911);
                            checkCollisionHeroIsland(marble3);
                            checkCollisionHeroIsland(marble1);
                            checkCollisionHeroIsland(marble2);

                            if(checkBossDead()){
                                checkbossdead++;
                                if(checkbossdead==1) {
                                    winner.fire();
                                }
                            }

                        }
                        //orc1











                        checkCollisionOrcOrc(redorc5, bigOrc1);


//                    checkCollisionHeroCoin(coin1);
//                    checkCollisionHeroCoin(coin2);
//                    checkCollisionHeroCoin(coin3);
                        //checkCollisionHeroCoin(coin4);
                        if (!herodead) {
                            checkCollisionHeroCoin(coin5);
                            checkCollisionHeroCoin(coin6);
                            checkCollisionHeroCoin(coin7);
                            checkCollisionHeroCoin(coin8);
                        }



                        setXcoordinate(thraxe);
                        setXcoordinate(thraxe1);
                        setXcoordinate(thraxe11);
                        setXcoordinate(thraxe12);
                        setXcoordinate(asgaxe);
                        setXcoordinate(menuimg);
                       // setXcoordinate(layoutbox);
                        //checkCollisionHeroCoin(coin9);
                    }
                    catch(InterruptedException e){

                    }



                //checkCollisionHeroIsland(isl1);
            }
        };
        collisionTimer1 = new AnimationTimer() {
            @Override
            public void handle(long l) {
                try {
                    checkCollisionOrcIsland(greenorc, isl1);
                    checkCollisionOrcIsland(greenorc, isl2);
                    checkCollisionOrcIsland(greenorc, isl3);
                    checkCollisionOrcIsland(greenorc, isl4);
                    checkCollisionOrcIsland(greenorc, isl5);
                    checkCollisionOrcIsland(greenorc, isl6);
                    checkCollisionOrcIsland(greenorc, isl7);
                    checkCollisionOrcIsland(greenorc, isl8);
                    checkCollisionOrcIsland(greenorc, isl9);
                    checkCollisionOrcIsland(greenorc, isl91);
                    checkCollisionOrcIsland(greenorc, isl911);

                    checkCollisionOrcIsland(boss,marble1);
                    checkCollisionOrcIsland(boss, marble2);
                    checkCollisionOrcIsland(boss, marble3);

                    //orc2
                    checkCollisionOrcIsland(greenorc2, isl1);
                    checkCollisionOrcIsland(greenorc2, isl2);
                    checkCollisionOrcIsland(greenorc2, isl3);
                    checkCollisionOrcIsland(greenorc2, isl4);
                    checkCollisionOrcIsland(greenorc2, isl5);
                    checkCollisionOrcIsland(greenorc2, isl6);
                    checkCollisionOrcIsland(greenorc2, isl7);
                    checkCollisionOrcIsland(greenorc2, isl8);
                    checkCollisionOrcIsland(greenorc2, isl9);
                    //orc3
                    checkCollisionOrcIsland(greenorc3, isl1);
                    checkCollisionOrcIsland(greenorc3, isl2);
                    checkCollisionOrcIsland(greenorc3, isl3);
                    checkCollisionOrcIsland(greenorc3, isl4);
                    checkCollisionOrcIsland(greenorc3, isl5);
                    checkCollisionOrcIsland(greenorc3, isl6);
                    checkCollisionOrcIsland(greenorc3, isl7);
                    checkCollisionOrcIsland(greenorc3, isl8);
                    checkCollisionOrcIsland(greenorc3, isl9);
                    //orc4
                    checkCollisionOrcIsland(redorc1, isl1);
                    checkCollisionOrcIsland(redorc1, isl2);
                    checkCollisionOrcIsland(redorc1, isl3);
                    checkCollisionOrcIsland(redorc1, isl4);
                    checkCollisionOrcIsland(redorc1, isl5);
                    checkCollisionOrcIsland(redorc1, isl6);
                    checkCollisionOrcIsland(redorc1, isl7);
                    checkCollisionOrcIsland(redorc1, isl8);
                    checkCollisionOrcIsland(redorc1, isl9);
                    //orc5
                    checkCollisionOrcIsland(redorc2, isl1);
                    checkCollisionOrcIsland(redorc2, isl2);
                    checkCollisionOrcIsland(redorc2, isl3);
                    checkCollisionOrcIsland(redorc2, isl4);
                    checkCollisionOrcIsland(redorc2, isl5);
                    checkCollisionOrcIsland(redorc2, isl6);
                    checkCollisionOrcIsland(redorc2, isl7);
                    checkCollisionOrcIsland(redorc2, isl8);
                    checkCollisionOrcIsland(redorc2, isl9);
                    //orc6
                    checkCollisionOrcIsland(redorc3, isl1);
                    checkCollisionOrcIsland(redorc3, isl2);
                    checkCollisionOrcIsland(redorc3, isl3);
                    checkCollisionOrcIsland(redorc3, isl4);
                    checkCollisionOrcIsland(redorc3, isl5);
                    checkCollisionOrcIsland(redorc3, isl6);
                    checkCollisionOrcIsland(redorc3, isl7);
                    checkCollisionOrcIsland(redorc3, isl8);
                    checkCollisionOrcIsland(redorc3, isl9);

                    //orc7
                    checkCollisionOrcIsland(redorc4, isl1);
                    checkCollisionOrcIsland(redorc4, isl2);
                    checkCollisionOrcIsland(redorc4, isl3);
                    checkCollisionOrcIsland(redorc4, isl4);
                    checkCollisionOrcIsland(redorc4, isl5);
                    checkCollisionOrcIsland(redorc4, isl6);
                    checkCollisionOrcIsland(redorc4, isl7);
                    checkCollisionOrcIsland(redorc4, isl8);
                    checkCollisionOrcIsland(redorc4, isl9);

                    //orc8
                    checkCollisionOrcIsland(redorc, isl1);
                    checkCollisionOrcIsland(redorc, isl2);
                    checkCollisionOrcIsland(redorc, isl3);
                    checkCollisionOrcIsland(redorc, isl4);
                    checkCollisionOrcIsland(redorc, isl5);
                    checkCollisionOrcIsland(redorc, isl6);
                    checkCollisionOrcIsland(redorc, isl7);
                    checkCollisionOrcIsland(redorc, isl8);
                    checkCollisionOrcIsland(redorc, isl9);
                    checkCollisionOrcIsland(redorc, isl51);
                    checkCollisionOrcIsland(redorc, isl52);
                    checkCollisionOrcIsland(redorc, isl53);
                    checkCollisionOrcIsland(redorc, isl54);
                    checkCollisionOrcIsland(redorc, isl55);
                    checkCollisionOrcIsland(redorc, isl531);

                    checkCollisionOrcIsland(redorc5, isl1);
                    checkCollisionOrcIsland(redorc5, isl2);
                    checkCollisionOrcIsland(redorc5, isl3);
                    checkCollisionOrcIsland(redorc5, isl4);
                    checkCollisionOrcIsland(redorc5, isl5);
                    checkCollisionOrcIsland(redorc5, isl6);
                    checkCollisionOrcIsland(redorc5, isl7);
                    checkCollisionOrcIsland(redorc5, isl8);
                    checkCollisionOrcIsland(redorc5, isl9);
                    checkCollisionOrcIsland(redorc5, isl51);
                    checkCollisionOrcIsland(redorc5, isl52);
                    checkCollisionOrcIsland(redorc5, isl53);
                    checkCollisionOrcIsland(redorc5, isl54);
                    checkCollisionOrcIsland(redorc5, isl55);
                    checkCollisionOrcIsland(redorc5, isl531);

                    //orc9
                    checkCollisionOrcIsland(bigOrc1, isl1);
                    checkCollisionOrcIsland(bigOrc1, isl2);
                    checkCollisionOrcIsland(bigOrc1, isl3);
                    checkCollisionOrcIsland(bigOrc1, isl4);
                    checkCollisionOrcIsland(bigOrc1, isl5);
                    checkCollisionOrcIsland(bigOrc1, isl6);
                    checkCollisionOrcIsland(bigOrc1, isl7);
                    checkCollisionOrcIsland(bigOrc1, isl8);
                    checkCollisionOrcIsland(bigOrc1, isl9);
                    checkCollisionOrcIsland(bigOrc1, isl51);
                    checkCollisionOrcIsland(bigOrc1, isl52);
                    checkCollisionOrcIsland(bigOrc1, isl53);
                    checkCollisionOrcIsland(bigOrc1, isl54);
                    checkCollisionOrcIsland(bigOrc1, isl55);
                    checkCollisionOrcIsland(bigOrc1, isl531);
                }
                catch(InterruptedException e){

                }
            }
        };
        collisionTimer2 = new AnimationTimer() {
            @Override
            public void handle(long l) {
                    checkCollisionHeroSide(greenorc);
                    checkCollisionHeroSide(greenorc2);
                    checkCollisionHeroSide(greenorc3);
                    checkCollisionHeroSide(greenorc4);
                    checkCollisionHeroSide(boss);
                    checkCollisionHeroSide(redorc);
                    checkCollisionHeroSide(redorc1);
                    checkCollisionHeroSide(redorc2);
                    checkCollisionHeroSide(redorc3);
                    checkCollisionHeroSide(redorc4);
                    checkCollisionHeroSide(redorc5);
                    checkCollisionHeroSide(bigOrc1);

                    checkCollisionHerotop(greenorc);
                    checkCollisionHerotop(greenorc2);
                    checkCollisionHerotop(greenorc3);
                    checkCollisionHerotop(greenorc4);
                checkCollisionHerotop(boss);
                    checkCollisionHerotop(redorc);
                    checkCollisionHerotop(redorc1);
                    checkCollisionHerotop(redorc2);
                    checkCollisionHerotop(redorc3);
                    checkCollisionHerotop(redorc4);
                    checkCollisionHerotop(redorc5);
                    checkCollisionHerotop(bigOrc1);

            }
        };
        collisionTimer3 = new AnimationTimer() {
            @Override
            public void handle(long l) {
                checkCollisionBridge(heroimg, brick1);
                checkCollisionBridge(heroimg, brick2);
                checkCollisionBridge(heroimg, brick3);
                checkCollisionBridge(heroimg, brick4);
                checkCollisionBridge(heroimg, brick5);
                checkCollisionBridge(heroimg, brick6);
                checkCollisionBridge(heroimg, brick7);

                checkCollisionBridge(redorc, brick1);
                checkCollisionBridge(redorc, brick2);
                checkCollisionBridge(redorc, brick3);
                checkCollisionBridge(redorc, brick4);
                checkCollisionBridge(redorc, brick5);
                checkCollisionBridge(redorc, brick6);
                checkCollisionBridge(redorc, brick7);

                checkCollisionBridge(redorc2, brick1);
                checkCollisionBridge(redorc2, brick2);
                checkCollisionBridge(redorc2, brick3);
                checkCollisionBridge(redorc2, brick4);
                checkCollisionBridge(redorc2, brick5);
                checkCollisionBridge(redorc2, brick6);
                checkCollisionBridge(redorc2, brick7);

                checkCollisionBridge(redorc1, brick1);
                checkCollisionBridge(redorc1, brick2);
                checkCollisionBridge(redorc1, brick3);
                checkCollisionBridge(redorc1, brick4);
                checkCollisionBridge(redorc1, brick5);
                checkCollisionBridge(redorc1, brick6);
                checkCollisionBridge(redorc1, brick7);

                checkCollisionBridge(redorc3, brick1);
                checkCollisionBridge(redorc3, brick2);
                checkCollisionBridge(redorc3, brick3);
                checkCollisionBridge(redorc3, brick4);
                checkCollisionBridge(redorc3, brick5);
                checkCollisionBridge(redorc3, brick6);
                checkCollisionBridge(redorc3, brick7);

                checkCollisionBridge(redorc4, brick1);
                checkCollisionBridge(redorc4, brick2);
                checkCollisionBridge(redorc4, brick3);
                checkCollisionBridge(redorc4, brick4);
                checkCollisionBridge(redorc4, brick5);
                checkCollisionBridge(redorc4, brick6);
                checkCollisionBridge(redorc4, brick7);

                checkCollisionBridge(redorc5, brick1);
                checkCollisionBridge(redorc5, brick2);
                checkCollisionBridge(redorc5, brick3);
                checkCollisionBridge(redorc5, brick4);
                checkCollisionBridge(redorc5, brick5);
                checkCollisionBridge(redorc5, brick6);
                checkCollisionBridge(redorc5, brick7);

                checkCollisionBridge(heroimg, brick11);
                checkCollisionBridge(heroimg, brick21);
                checkCollisionBridge(heroimg, brick31);
                checkCollisionBridge(heroimg, brick41);
                checkCollisionBridge(heroimg, brick51);
                checkCollisionBridge(heroimg, brick61);
                checkCollisionBridge(heroimg, brick71);

                checkCollisionBridge(redorc, brick11);
                checkCollisionBridge(redorc, brick21);
                checkCollisionBridge(redorc, brick31);
                checkCollisionBridge(redorc, brick41);
                checkCollisionBridge(redorc, brick51);
                checkCollisionBridge(redorc, brick61);
                checkCollisionBridge(redorc, brick71);

                checkCollisionBridge(redorc2, brick11);
                checkCollisionBridge(redorc2, brick21);
                checkCollisionBridge(redorc2, brick31);
                checkCollisionBridge(redorc2, brick41);
                checkCollisionBridge(redorc2, brick51);
                checkCollisionBridge(redorc2, brick61);
                checkCollisionBridge(redorc2, brick71);

                checkCollisionBridge(heroimg, brick111);
                checkCollisionBridge(heroimg, brick211);
                checkCollisionBridge(heroimg, brick311);
                checkCollisionBridge(heroimg, brick411);
                checkCollisionBridge(heroimg, brick511);
                checkCollisionBridge(heroimg, brick611);
                checkCollisionBridge(heroimg, brick711);

                checkCollisionBridge(heroimg, brick112);
                checkCollisionBridge(heroimg, brick212);
                checkCollisionBridge(heroimg, brick312);
                checkCollisionBridge(heroimg, brick412);
                checkCollisionBridge(heroimg, brick512);
                checkCollisionBridge(heroimg, brick612);
                checkCollisionBridge(heroimg, brick712);

                checkCollisionBridge(redorc1, brick11);
                checkCollisionBridge(redorc1, brick21);
                checkCollisionBridge(redorc1, brick31);
                checkCollisionBridge(redorc1, brick41);
                checkCollisionBridge(redorc1, brick51);
                checkCollisionBridge(redorc1, brick61);
                checkCollisionBridge(redorc1, brick71);

                checkCollisionBridge(redorc3, brick11);
                checkCollisionBridge(redorc3, brick21);
                checkCollisionBridge(redorc3, brick31);
                checkCollisionBridge(redorc3, brick41);
                checkCollisionBridge(redorc3, brick51);
                checkCollisionBridge(redorc3, brick61);
                checkCollisionBridge(redorc3, brick71);

                checkCollisionBridge(redorc4, brick11);
                checkCollisionBridge(redorc4, brick21);
                checkCollisionBridge(redorc4, brick31);
                checkCollisionBridge(redorc4, brick41);
                checkCollisionBridge(redorc4, brick51);
                checkCollisionBridge(redorc4, brick61);
                checkCollisionBridge(redorc4, brick71);

                checkCollisionBridge(redorc5, brick11);
                checkCollisionBridge(redorc5, brick21);
                checkCollisionBridge(redorc5, brick31);
                checkCollisionBridge(redorc5, brick41);
                checkCollisionBridge(redorc5, brick51);
                checkCollisionBridge(redorc5, brick61);
                checkCollisionBridge(redorc5, brick71);

                checkCollisionBridge(greenorc4, brick11);
                checkCollisionBridge(greenorc4, brick21);
                checkCollisionBridge(greenorc4, brick31);
                checkCollisionBridge(greenorc4, brick41);
                checkCollisionBridge(greenorc4, brick51);
                checkCollisionBridge(greenorc4, brick61);
                checkCollisionBridge(greenorc4, brick71);

                checkCollisionBridge(greenorc3, brick11);
                checkCollisionBridge(greenorc3, brick21);
                checkCollisionBridge(greenorc3, brick31);
                checkCollisionBridge(greenorc3, brick41);
                checkCollisionBridge(greenorc3, brick51);
                checkCollisionBridge(greenorc3, brick61);
                checkCollisionBridge(greenorc3, brick71);

                checkCollisionBridge(greenorc2, brick11);
                checkCollisionBridge(greenorc2, brick21);
                checkCollisionBridge(greenorc2, brick31);
                checkCollisionBridge(greenorc2, brick41);
                checkCollisionBridge(greenorc2, brick51);
                checkCollisionBridge(greenorc2, brick61);
                checkCollisionBridge(greenorc2, brick71);

            }
        };
        collisionTimer4 = new AnimationTimer() {
            @Override
            public void handle(long l) {
                checkCollisionOrcOrc(greenorc, greenorc2);
                checkCollisionOrcOrc(greenorc, greenorc3);
                checkCollisionOrcOrc(greenorc, greenorc4);
                checkCollisionOrcOrc(greenorc, redorc1);
                checkCollisionOrcOrc(greenorc, redorc);
                checkCollisionOrcOrc(greenorc, redorc2);
                checkCollisionOrcOrc(greenorc, redorc3);
                checkCollisionOrcOrc(greenorc, redorc4);
                checkCollisionOrcOrc(greenorc, redorc5);
                checkCollisionOrcOrc(greenorc, bigOrc1);
                checkCollisionOrcOrc(greenorc, boss);

                checkCollisionOrcOrc(greenorc2, greenorc3);
                checkCollisionOrcOrc(greenorc2, greenorc4);
                checkCollisionOrcOrc(greenorc2, redorc1);
                checkCollisionOrcOrc(greenorc2, redorc);
                checkCollisionOrcOrc(greenorc2, redorc2);
                checkCollisionOrcOrc(greenorc2, redorc3);
                checkCollisionOrcOrc(greenorc2, redorc4);
                checkCollisionOrcOrc(greenorc2, redorc5);
                checkCollisionOrcOrc(greenorc2, bigOrc1);
                checkCollisionOrcOrc(greenorc2, boss);

                checkCollisionOrcOrc(greenorc3, greenorc4);
                checkCollisionOrcOrc(greenorc3, redorc1);
                checkCollisionOrcOrc(greenorc3, redorc);
                checkCollisionOrcOrc(greenorc3, redorc2);
                checkCollisionOrcOrc(greenorc3, redorc3);
                checkCollisionOrcOrc(greenorc3, redorc4);
                checkCollisionOrcOrc(greenorc3, redorc5);
                checkCollisionOrcOrc(greenorc3, bigOrc1);
                checkCollisionOrcOrc(greenorc3, boss);


                checkCollisionOrcOrc(greenorc4, redorc1);
                checkCollisionOrcOrc(greenorc4, redorc);
                checkCollisionOrcOrc(greenorc4, redorc2);
                checkCollisionOrcOrc(greenorc4, redorc3);
                checkCollisionOrcOrc(greenorc4, redorc4);
                checkCollisionOrcOrc(greenorc4, redorc5);
                checkCollisionOrcOrc(greenorc4, bigOrc1);
                checkCollisionOrcOrc(greenorc4, boss);

                checkCollisionOrcOrc(redorc1, redorc);
                checkCollisionOrcOrc(redorc1, redorc2);
                checkCollisionOrcOrc(redorc1, redorc3);
                checkCollisionOrcOrc(redorc1, redorc4);
                checkCollisionOrcOrc(redorc1, redorc5);
                checkCollisionOrcOrc(redorc1, bigOrc1);

                checkCollisionOrcOrc(redorc, redorc2);
                checkCollisionOrcOrc(redorc, redorc3);
                checkCollisionOrcOrc(redorc, redorc4);
                checkCollisionOrcOrc(redorc, redorc5);
                checkCollisionOrcOrc(redorc, bigOrc1);

                checkCollisionOrcOrc(redorc2, redorc3);
                checkCollisionOrcOrc(redorc2, redorc4);
                checkCollisionOrcOrc(redorc2, redorc5);
                checkCollisionOrcOrc(redorc2, bigOrc1);

                checkCollisionOrcOrc(redorc3, redorc4);
                checkCollisionOrcOrc(redorc3, redorc5);
                checkCollisionOrcOrc(redorc3, bigOrc1);

                checkCollisionOrcOrc(redorc4, redorc5);
                checkCollisionOrcOrc(redorc4, bigOrc1);

            }
        };
        collisionTimer5 = new AnimationTimer() {
            @Override
            public void handle(long l) {
               // rspn();
                if(!rspwn){
                fallIntoabyss(heroimg);
                }
                fallIntoabyss(boss);

            }
        };

        collisionTimer51 = new AnimationTimer() {
            public void handle(long l) {

                rspn();

            }
        };
        collisionTimer51.start();
        collisionTimer6 = new AnimationTimer() {
            @Override
            public void handle(long l) {
                checkcollisionweaponorc(greenorc, thraxe);
                checkcollisionweaponorc(greenorc2, thraxe);
                checkcollisionweaponorc(greenorc3, thraxe);
                checkcollisionweaponorc(greenorc4, thraxe);
                checkcollisionweaponorc(boss, thraxe);
                checkcollisionweaponorc(redorc, thraxe);
                checkcollisionweaponorc(redorc1, thraxe);
                checkcollisionweaponorc(redorc2, thraxe);
                checkcollisionweaponorc(redorc3, thraxe);
                checkcollisionweaponorc(redorc4, thraxe);
                checkcollisionweaponorc(redorc5, thraxe);
                checkcollisionweaponorc(bigOrc1, thraxe);

                checkcollisionweaponorc(greenorc, thraxe1);
                checkcollisionweaponorc(greenorc2, thraxe1);
                checkcollisionweaponorc(greenorc3, thraxe1);
                checkcollisionweaponorc(greenorc4, thraxe1);
                checkcollisionweaponorc(boss, thraxe1);
                checkcollisionweaponorc(redorc, thraxe1);
                checkcollisionweaponorc(redorc1, thraxe1);
                checkcollisionweaponorc(redorc2, thraxe1);
                checkcollisionweaponorc(redorc3, thraxe1);
                checkcollisionweaponorc(redorc4, thraxe1);
                checkcollisionweaponorc(redorc5, thraxe1);
                checkcollisionweaponorc(bigOrc1, thraxe1);

                checkcollisionweaponorc(greenorc, thraxe11);
                checkcollisionweaponorc(greenorc2, thraxe11);
                checkcollisionweaponorc(greenorc3, thraxe11);
                checkcollisionweaponorc(greenorc4, thraxe11);
                checkcollisionweaponorc(boss, thraxe11);
                checkcollisionweaponorc(redorc, thraxe11);
                checkcollisionweaponorc(redorc1, thraxe11);
                checkcollisionweaponorc(redorc2, thraxe11);
                checkcollisionweaponorc(redorc3, thraxe11);
                checkcollisionweaponorc(redorc4, thraxe11);
                checkcollisionweaponorc(redorc5, thraxe11);
                checkcollisionweaponorc(bigOrc1, thraxe11);

                checkcollisionweaponorc(greenorc, thraxe12);
                checkcollisionweaponorc(greenorc2, thraxe12);
                checkcollisionweaponorc(greenorc3, thraxe12);
                checkcollisionweaponorc(greenorc4, thraxe12);
                checkcollisionweaponorc(boss, thraxe12);
                checkcollisionweaponorc(redorc, thraxe12);
                checkcollisionweaponorc(redorc1, thraxe12);
                checkcollisionweaponorc(redorc2, thraxe12);
                checkcollisionweaponorc(redorc3, thraxe12);
                checkcollisionweaponorc(redorc4, thraxe12);
                checkcollisionweaponorc(redorc5, thraxe12);
                checkcollisionweaponorc(bigOrc1, thraxe12);

                checkcollisionweaponorc(greenorc, asgaxe);
                checkcollisionweaponorc(greenorc2, asgaxe);
                checkcollisionweaponorc(greenorc3, asgaxe);
                checkcollisionweaponorc(greenorc4, asgaxe);
                checkcollisionweaponorc(boss, asgaxe);
                checkcollisionweaponorc(redorc, asgaxe);
                checkcollisionweaponorc(redorc1, asgaxe);
                checkcollisionweaponorc(redorc2, asgaxe);
                checkcollisionweaponorc(redorc3, asgaxe);
                checkcollisionweaponorc(redorc4, asgaxe);
                checkcollisionweaponorc(redorc5, asgaxe);
                checkcollisionweaponorc(bigOrc1, asgaxe);

            }
        };
        collisionTimerchest=new AnimationTimer() {
            @Override
            public void handle(long l) {
                heroimg = (ImageView)scene.lookup("#heroimg");
                if (!herodead){
                    cntrlabel.setText(Integer.toString(coinCounter));
                    checkcollisionchest(chest1);
                    checkcollisionchest(chest12);
                    checkcollisionchest(chest13);
                    //checkcollisioncoin(chest1);
                    checkcollisiontnt(tnt1);
                    checkcollisiontnt(tnt12);
                    checkcollisiontnt(tnt13);
                    checkcollisiontnt(tnt14);

                    checkCollisionHeroOrcBottom(greenorc);
                    checkCollisionHeroOrcBottom(greenorc2);
                    checkCollisionHeroOrcBottom(greenorc3);
                    checkCollisionHeroOrcBottom(greenorc4);
                    checkCollisionHeroOrcBottom(boss);
                    checkCollisionHeroOrcBottom(redorc);
                    checkCollisionHeroOrcBottom(redorc2);
                    checkCollisionHeroOrcBottom(redorc3);
                    checkCollisionHeroOrcBottom(redorc4);
                    checkCollisionHeroOrcBottom(redorc5);
                    checkCollisionHeroOrcBottom(redorc1);
                    checkCollisionHeroOrcBottom(bigOrc1);
                }



                //checkCollisionHeroIsland(isl1);
            }
        };
        //collisionTimercoin=new AnimationTimer() {
        //    @Override
        //    public void handle(long l) {
        //       heroimg = (ImageView)scene.lookup("#heroimg");

        //checkcollisioncoin(chest1);
        //   }
        // };

        collisionTimertnt=new AnimationTimer() {

            private long latestupd=0;
            @Override
            public void handle(long l) {
                heroimg = (ImageView)scene.lookup("#heroimg");

                if((l - latestupd >= 2_80_00_00_00)){
                    checkcollisiontnt(tnt1);
                    latestupd=l;
                }
                //checkCollisionHeroIsland(isl1);
            }
        };
        //collisionTimerexpl=new AnimationTimer() {
        //  @Override
        //  public void handle(long l) {
        //     heroimg = (ImageView)scene.lookup("#heroimg");

        //     //checkcollisionexpl(tnt1);
        //   }
        // };



        scene.setOnKeyPressed(new EventHandler<KeyEvent>() {
            @Override
            public void handle(KeyEvent keyEvent) {

                if(keyEvent.getCode()==KeyCode.S)
                {
                    heroimg = (ImageView) scene.lookup("#heroimg");
                    double xb = heroimg.getBoundsInParent().getCenterX();
                    double yb = heroimg.getBoundsInParent().getCenterY();
                    System.out.println("X:"+heroimg.getBoundsInParent());
                    try{
                        FileOutputStream fout=new FileOutputStream("f.txt");
                        ObjectOutputStream out=new ObjectOutputStream(fout);
                        out.writeObject(xb);
                        out.flush();
                        out.close();
                        System.out.println("success");
                        FileOutputStream fout1=new FileOutputStream("f1.txt");
                        ObjectOutputStream out1=new ObjectOutputStream(fout1);
                        out1.writeObject(yb);
                        out1.flush();
                        out1.close();
                        System.out.println("success");
                    }catch(Exception e){System.out.println(e);}

                }

                if(keyEvent.getCode()==KeyCode.L)
                {
                    try{
                        double xb1;
                        double xb2;

                        heroimg = (ImageView) scene.lookup("#heroimg");
                        ObjectInputStream in=new ObjectInputStream(new FileInputStream("f.txt"));
                        xb1=(Double) in.readObject();
                        in.close();
                        ObjectInputStream in1=new ObjectInputStream(new FileInputStream("f1.txt"));
                        xb2=(Double) in1.readObject();
                        in.close();
                        double temp =heroimg.getBoundsInParent().getMaxY();
                        xb1=xb1-temp;
                        System.out.println("XB1:"+xb1);
                        heroimg.setX(xb1);
                        heroimg.setY(-300);
                        TranslateTransition t1=new TranslateTransition();
                        t1.setNode(camera);
                        t1.setToX(xb1-30);
                        camera.setCache(true);
                        camera.setCacheHint(CacheHint.SPEED);
                        t1.setDuration(Duration.millis(1));
                        t1.play();

                    }catch(Exception e){System.out.println(e);}

                }
if(!heropause) {
    if (keyEvent.getCode() == KeyCode.DIGIT1) {

        if (weaponGot) {
            equip1 = true;

            equip2 = false;
            equipupg = false;
        }
        if (weaponupg) {
            equip2 = false;
            equip1 = false;
            equipupg = true;
        }


    }

    if (keyEvent.getCode() == KeyCode.DIGIT2) {

        if (weaponGot2) {
            equip2 = true;
            equip1 = false;
            equipupg = false;
        }

    }

    if (keyEvent.getCode() == KeyCode.D) {


        if(progress>=maxscore){
            System.out.println("SAVING");
        ser_score();}

        ser1(spawncounter);
//camera.translateXProperty().getValue()
        if (!herodead) {
            heart = (ImageView) scene.lookup("#heart");
            heartlabel = (ImageView) scene.lookup("#heartlabel");
            heart.setVisible(false);
            heartlabel.setVisible(false);
            double prev = heroimg.getBoundsInParent().getMaxX();
            // System.out.println("Hero x:" + prev);
//                        camera.setNearClip(0);
//                        camera.setFarClip(7000);
            TranslateTransition t11 = new TranslateTransition();
            t11.setNode(heroimg);
            t11.setByX(120);
            t11.setDuration(Duration.millis(400));
            // heroimg.setCache(true);
            // heroimg.setCacheHint(CacheHint.SPEED);
            t11.setInterpolator(Interpolator.LINEAR);
            t11.play();

            // camera.translateXProperty().set(85);
            TranslateTransition t1 = new TranslateTransition();
            t1.setNode(camera);
            t1.setByX(120);
            // camera.setCache(true);
            // camera.setCacheHint(CacheHint.SPEED);
            t1.setInterpolator(Interpolator.LINEAR);
            t1.setDuration(Duration.millis(400));
            t1.play();


            //   camera.setTranslateX(camera.getTranslateX()+35);
            //       System.out.println("Hero x after translation:" + heroimg.getBoundsInParent().getMinX() + "Camera: " + camera.getBoundsInParent().getMaxX());
//                        if(heroimg.translateXProperty().getValue()>prev) {
//                            camera.translateXProperty().set(heroimg.translateXProperty().getValue()+2);
//
//                        }


            test1.fire();
            progress++;
            progbar.setProgress(progress / 165);
            proglabel.setText(Integer.toString((int) Math.round(progress)));
        }

        if (equipupg) {
//                        layoutbox.setTranslateX(heroimg.getBoundsInParent().getMaxX());


            //    asgaxe.setImage(asgaxe.getImage());

            // thraxe.setY(heroimg.getBoundsInLocal().getCenterY());


            TranslateTransition tx = new TranslateTransition();

            tx.setNode(asgaxe);
            //      System.out.println(thraxe.getBoundsInParent().getCenterX() + "beforeAXEx" + thraxe.getBoundsInParent().getCenterY() + "beforeAXEy");
//                        tx.setFromX(0);
//                        tx.setFromY(0);

            //   System.out.println(heroimg.getBoundsInParent().getCenterX() + "x" + heroimg.getBoundsInParent().getCenterY() + "y");
           // tx.setFromX(asgaxe.getX());
            //      tx.setFromY(thraxe.getY());
            //   System.out.println(heroimg.getBoundsInParent().getCenterX() + "x" + heroimg.getBoundsInParent().getCenterY() + "y");
            tx.setToX(heroimg.getBoundsInParent().getCenterX());

            tx.setByY(-asgaxe.getBoundsInParent().getMaxY() + heroimg.getBoundsInParent().getCenterY());

            //     System.out.println(thraxe.getBoundsInParent().getCenterX() + "AXEx" + thraxe.getBoundsInParent().getCenterY() + "AXEy");

            tx.setDuration(Duration.millis(1));
            tx.setOnFinished(e -> asgaxe.setVisible(true));
            tx.play();

            TranslateTransition tx1 = new TranslateTransition();
            tx1.setNode(asgaxe);
            tx1.setByX(200);
            tx1.setDuration(Duration.millis(100));
            tx1.setInterpolator(Interpolator.LINEAR);

            TranslateTransition tx11 = new TranslateTransition();
            tx11.setNode(asgaxe);
            tx11.setToX(heroimg.getBoundsInParent().getCenterX()+120);
            tx11.setDuration(Duration.millis(100));
            tx11.setInterpolator(Interpolator.LINEAR);

            // tx1.play();

//SequentialTransition s = new SequentialTransition(tx1,tx2);
//s.play();
            RotateTransition rx = new RotateTransition(Duration.millis(200), asgaxe);
            rx.setByAngle(360);
            rx.setCycleCount(3);
            rx.setInterpolator(Interpolator.LINEAR);
            //  rx.setDuration(Duration.millis(500));

            ParallelTransition p1 = new ParallelTransition(tx1, rx);

            ParallelTransition p2 = new ParallelTransition(tx11, rx);
///
            SequentialTransition sq = new SequentialTransition(p1, p2);
            sq.setOnFinished(e -> asgaxe.setTranslateY(1000));
            sq.play();
        }

        if (equip1) {
//                        TranslateTransition t = new TranslateTransition();
//                        t.setNode(layoutbox);
//                        t.setFromX(layoutbox.getBoundsInParent().getMaxX());
//                        //      tx.setFromY(thraxe.getY());
//                        //   System.out.println(heroimg.getBoundsInParent().getCenterX() + "x" + heroimg.getBoundsInParent().getCenterY() + "y");
//                        t.setToX(heroimg.getBoundsInParent().getCenterX());
//
//                        t.setByY(-layoutbox.getBoundsInParent().getMaxY()+heroimg.getBoundsInParent().getCenterY()-200);
//
//                        //     System.out.println(thraxe.getBoundsInParent().getCenterX() + "AXEx" + thraxe.getBoundsInParent().getCenterY() + "AXEy");
//
//                        t.setDuration(Duration.millis(1));
            //       layoutbox.setTranslateX(heroimg.getBoundsInParent().getMaxX());
            //     thraxe.setImage(thraxe.getImage());

            // thraxe.setY(heroimg.getBoundsInLocal().getCenterY());


            TranslateTransition tx = new TranslateTransition();

            tx.setNode(thraxe);
            //        System.out.println(thraxe.getBoundsInParent().getCenterX() + "beforeAXEx" + thraxe.getBoundsInParent().getCenterY() + "beforeAXEy");
           // tx.setFromX(thraxe.getX());
            //      tx.setFromY(thraxe.getY());
            //   System.out.println(heroimg.getBoundsInParent().getCenterX() + "x" + heroimg.getBoundsInParent().getCenterY() + "y");
            tx.setToX(heroimg.getBoundsInParent().getCenterX());

            tx.setByY(-thraxe.getBoundsInParent().getMaxY() + heroimg.getBoundsInParent().getCenterY());

            //     System.out.println(thraxe.getBoundsInParent().getCenterX() + "AXEx" + thraxe.getBoundsInParent().getCenterY() + "AXEy");

            tx.setDuration(Duration.millis(1));
            tx.setOnFinished(e -> thraxe.setVisible(true));

            tx.play();
//                            thraxe.setTranslateX(heroimg.getBoundsInParent().getCenterX()-thraxe.getBoundsInParent().getMaxX());
//                        thraxe.setTranslateY(thraxe.getBoundsInParent().getMaxY()-heroimg.getBoundsInParent().getCenterY());

            TranslateTransition tx1 = new TranslateTransition();
            tx1.setNode(thraxe);
            tx1.setByX(500);
            tx1.setDuration(Duration.millis(100));
            tx1.setInterpolator(Interpolator.LINEAR);

            TranslateTransition tx11 = new TranslateTransition();
            tx11.setNode(thraxe);
            tx11.setToX(heroimg.getBoundsInParent().getCenterX()+120);
            tx11.setDuration(Duration.millis(100));
            tx11.setInterpolator(Interpolator.LINEAR);
//                    tx1.play();
//                        TranslateTransition tx2 = new TranslateTransition();
//                        tx2.setNode(thraxe);
//                        tx2.setByX(-500);
//                        tx2.setDuration(Duration.seconds(1));
//                        tx2.setInterpolator(Interpolator.LINEAR);
//SequentialTransition s = new SequentialTransition(tx1,tx2);
//s.play();
            RotateTransition rx = new RotateTransition(Duration.millis(150), thraxe);
            rx.setByAngle(360);
            rx.setCycleCount(4);
            rx.setInterpolator(Interpolator.LINEAR);
            //  rx.setDuration(Duration.millis(500));

            ParallelTransition p1 = new ParallelTransition(tx1, rx);
//            TranslateTransition waste = new TranslateTransition();
//            waste.setNode(thraxe);
//            waste.setDuration(Duration.millis(200));
            //  ParallelTransition p2 = new ParallelTransition(tx2, rx);
////
            SequentialTransition sq = new SequentialTransition(p1,tx11);
            sq.setOnFinished(e -> thraxe.setTranslateY(1000));
            //      sq.setDelay(Duration.millis(5));
            sq.play();
        }

        if (equip2) {
            //camera
            // layoutbox.setTranslateX(heroimg.getBoundsInParent().getMaxX());
            // TranslateTransition tx = new TranslateTransition();

            //    thraxe1.setImage(thraxe1.getImage());

            // thraxe.setY(heroimg.getBoundsInLocal().getCenterY());
            TranslateTransition txx = new TranslateTransition();

            txx.setNode(thraxe11);
            //      System.out.println(thraxe.getBoundsInParent().getCenterX() + "beforeAXEx" + thraxe.getBoundsInParent().getCenterY() + "beforeAXEy");
            //txx.setFromX(thraxe11.getX());
            //      tx.setFromY(thraxe.getY());
            //   System.out.println(heroimg.getBoundsInParent().getCenterX() + "x" + heroimg.getBoundsInParent().getCenterY() + "y");
            txx.setToX(heroimg.getBoundsInParent().getCenterX());

            txx.setByY(-thraxe11.getBoundsInParent().getMaxY() + heroimg.getBoundsInParent().getCenterY());

            //     System.out.println(thraxe.getBoundsInParent().getCenterX() + "AXEx" + thraxe.getBoundsInParent().getCenterY() + "AXEy");

            txx.setDuration(Duration.millis(1));
            //     tx.play();

            //     System.out.println(thraxe.getBoundsInParent().getCenterX() + "AXEx" + thraxe.getBoundsInParent().getCenterY() + "AXEy");

            txx.setDuration(Duration.millis(1));
            // tx.play();


            TranslateTransition ty = new TranslateTransition();

            ty.setNode(thraxe12);
            //      System.out.println(thraxe.getBoundsInParent().getCenterX() + "beforeAXEx" + thraxe.getBoundsInParent().getCenterY() + "beforeAXEy");
            ty.setFromX(thraxe12.getX());
            //      tx.setFromY(thraxe.getY());
            //   System.out.println(heroimg.getBoundsInParent().getCenterX() + "x" + heroimg.getBoundsInParent().getCenterY() + "y");
            ty.setToX(heroimg.getBoundsInParent().getCenterX());

            ty.setByY(-thraxe12.getBoundsInParent().getMaxY() + heroimg.getBoundsInParent().getCenterY());

            //     System.out.println(thraxe.getBoundsInParent().getCenterX() + "AXEx" + thraxe.getBoundsInParent().getCenterY() + "AXEy");

            ty.setDuration(Duration.millis(1));
            //tx.play();

            //     System.out.println(thraxe.getBoundsInParent().getCenterX() + "AXEx" + thraxe.getBoundsInParent().getCenterY() + "AXEy");

            ty.setDuration(Duration.millis(1));

            //   tx.play();
            TranslateTransition tx = new TranslateTransition();

            tx.setNode(thraxe1);
            //      System.out.println(thraxe.getBoundsInParent().getCenterX() + "beforeAXEx" + thraxe.getBoundsInParent().getCenterY() + "beforeAXEy");
            tx.setFromX(thraxe1.getX());
            //      tx.setFromY(thraxe.getY());
            //   System.out.println(heroimg.getBoundsInParent().getCenterX() + "x" + heroimg.getBoundsInParent().getCenterY() + "y");
            tx.setToX(heroimg.getBoundsInParent().getCenterX());

            tx.setByY(-thraxe1.getBoundsInParent().getMaxY() + heroimg.getBoundsInParent().getCenterY());

            //     System.out.println(thraxe.getBoundsInParent().getCenterX() + "AXEx" + thraxe.getBoundsInParent().getCenterY() + "AXEy");

            tx.setDuration(Duration.millis(1));
            tx.setOnFinished(e -> thraxe1.setVisible(true));
            TranslateTransition delay = new TranslateTransition();
            delay.setDuration(Duration.millis(100));

            //tx.setOnFinished(e-> delay.play());
//                        tx.setOnFinished(e-> txx.play());
//                        tx.setOnFinished(e-> ty.play());
            tx.play();
            txx.play();
            ty.play();
            //     System.out.println(thraxe.getBoundsInParent().getCenterX() + "AXEx" + thraxe.getBoundsInParent().getCenterY() + "AXEy");

            txx.setOnFinished(e -> thraxe11.setVisible(true));

            ty.setOnFinished(e -> thraxe12.setVisible(true));

            TranslateTransition tx1 = new TranslateTransition();
            tx1.setNode(thraxe1);
            tx1.setByX(300);
            tx1.setDuration(Duration.seconds(0.5));
            tx1.setInterpolator(Interpolator.LINEAR);
            tx1.setOnFinished(e -> thraxe1.setTranslateY(1000));


//                        tx1.setOnFinished(e->thraxe11.setVisible(true));
//                        tx1.setOnFinished(e->thraxe12.setVisible(true));

            TranslateTransition txx1 = new TranslateTransition();
            txx1.setNode(thraxe11);
            txx1.setByX(300);
            txx1.setDuration(Duration.seconds(0.5));
            txx1.setInterpolator(Interpolator.LINEAR);

            TranslateTransition ty1 = new TranslateTransition();
            ty1.setNode(thraxe12);
            ty1.setByX(300);
            ty1.setDuration(Duration.seconds(0.5));
            ty1.setInterpolator(Interpolator.LINEAR);
//                    tx1.play();

            txx1.setOnFinished(e -> thraxe11.setTranslateY(1000));
            ty1.setOnFinished(e -> thraxe12.setTranslateY(1000));
//                        TranslateTransition tx2 = new TranslateTransition();
//                        tx2.setNode(thraxe1);
//                        tx2.setByX(-500);
//                        tx2.setDuration(Duration.seconds(1));
//                        tx2.setInterpolator(Interpolator.LINEAR);
//SequentialTransition s = new SequentialTransition(tx1,tx2);
//s.play();
//                        ScaleTransition rx = new ScaleTransition(Duration.millis(300), thraxe1);
//                        rx.setToX(-1);
//                        rx.setCycleCount(1);
//                        rx.setInterpolator(Interpolator.LINEAR);
//                        rx.setDuration(Duration.millis(500));

            //  ParallelTransition p1 = new ParallelTransition(tx1);

            //          ParallelTransition p2 = new ParallelTransition(tx2, rx);
////
            SequentialTransition sq = new SequentialTransition(tx1, txx1, ty1);
            sq.setOnFinished(e -> thraxe1.setTranslateY(1000));
            sq.play();
        }


    }
}
                /*if(keyEvent.getCode()==KeyCode.F){
                    thraxe.setVisible(true);
                    thraxe.setImage(thraxe.getImage());

                    // thraxe.setY(heroimg.getBoundsInLocal().getCenterY());


                    TranslateTransition tx = new TranslateTransition();

                    tx.setNode(thraxe);
                    System.out.println(thraxe.getBoundsInParent().getCenterX() + "beforeAXEx" + thraxe.getBoundsInParent().getCenterY()+ "beforeAXEy");                    tx.setFromX(0);
                    tx.setFromY(0);
                    System.out.println(heroimg.getBoundsInParent().getCenterX() + "x" + heroimg.getBoundsInParent().getCenterY()+ "y");
                    tx.setByX(heroimg.getBoundsInParent().getCenterX());

                    tx.setByY(-(681.3024-heroimg.getBoundsInParent().getCenterY()));

                    System.out.println(thraxe.getBoundsInParent().getCenterX() + "AXEx" + thraxe.getBoundsInParent().getCenterY()+ "AXEy");

                    tx.setDuration(Duration.millis(1));
                    tx.play();

                    TranslateTransition tx1 = new TranslateTransition();
                    tx1.setNode(thraxe);
                    tx1.setByX(500);
                    tx1.setDuration(Duration.seconds(0.2));
                    tx1.setInterpolator(Interpolator.LINEAR);
//                    tx1.play();
                    TranslateTransition tx2 = new TranslateTransition();
                    tx2.setNode(thraxe);
                    tx2.setByX(-500);
                    tx2.setDuration(Duration.seconds(0.2));
                    tx2.setInterpolator(Interpolator.LINEAR);
//SequentialTransition s = new SequentialTransition(tx1,tx2);
//s.play();
                    RotateTransition rx = new RotateTransition(Duration.millis(300), thraxe);
                    rx.setByAngle(360);
                    rx.setCycleCount(1);
                    rx.setInterpolator(Interpolator.LINEAR);
                  //  rx.setDuration(Duration.millis(500));

                    ParallelTransition p1 = new ParallelTransition(tx1,rx);

                    ParallelTransition p2 = new ParallelTransition(tx2,rx);
////
                   SequentialTransition sq= new SequentialTransition(p1,p2);
                  sq.play();


                }*/
            }
        });


        collisionTimer.start();
        collisionTimer1.start();
        collisionTimer2.start();
        collisionTimer3.start();
        collisionTimer4.start();
        collisionTimer5.start();
        collisionTimer6.start();

        collisionTimerchest.start();
        collisionTimertnt.start();

       /* try{
            deser_save();}
        catch(FileNotFoundException e){
            System.out.println("HERE");
        }*/

        //collisionTimercoin.start();
        // collisionTimerexpl.start();

    }


    public void  jump1() throws InterruptedException, IOException {

        TranslateTransition t01 = new TranslateTransition();
        t01.setNode(heroimg);
        t01.setByY(100);
        t01.setDuration(Duration.millis(500));
        // t01.setOnFinished(event -> fallback());
        //t01.setCycleCount(TranslateTransition.INDEFINITE);
        // t01.setAutoReverse(true);
        heroimg.setCache(true);
        heroimg.setCacheHint(CacheHint.SPEED);
        t01.play();


        c1= new RotateTransition(Duration.millis(3000), coin1);
        c1.setByAngle(180);
        c1.setCycleCount(Animation.INDEFINITE);
        c1.setInterpolator(Interpolator.LINEAR);
       // c1.setAxis(Rotate.Y_AXIS);
        c1.play();

        c2= new RotateTransition(Duration.millis(3000), coin2);
        c2.setByAngle(180);
        c2.setCycleCount(Animation.INDEFINITE);
        c2.setInterpolator(Interpolator.LINEAR);
      //  c2.setAxis(Rotate.Y_AXIS);
        c2.play();

        c3= new RotateTransition(Duration.millis(3000), coin3);
        c3.setByAngle(180);
        c3.setCycleCount(Animation.INDEFINITE);
        c3.setInterpolator(Interpolator.LINEAR);
     //   c3.setAxis(Rotate.Y_AXIS);
        c3.play();

        c4= new RotateTransition(Duration.millis(3000), coin4);
        c4.setByAngle(180);
        c4.setCycleCount(Animation.INDEFINITE);
        c4.setInterpolator(Interpolator.LINEAR);
     //   c4.setAxis(Rotate.Y_AXIS);
        c4.play();

        c5= new RotateTransition(Duration.millis(3000), coin5);
        c5.setByAngle(180);
        c5.setCycleCount(Animation.INDEFINITE);
        c5.setInterpolator(Interpolator.LINEAR);
   //     c5.setAxis(Rotate.Y_AXIS);
        c5.play();

        c6= new RotateTransition(Duration.millis(3000), coin6);
        c6.setByAngle(180);
        c6.setCycleCount(Animation.INDEFINITE);
        c6.setInterpolator(Interpolator.LINEAR);
    //    c6.setAxis(Rotate.Y_AXIS);
        c6.play();

        c7= new RotateTransition(Duration.millis(3000), coin7);
        c7.setByAngle(180);
        c7.setCycleCount(Animation.INDEFINITE);
        c7.setInterpolator(Interpolator.LINEAR);
    //    c7.setAxis(Rotate.Y_AXIS);
        c7.play();

        c8= new RotateTransition(Duration.millis(3000), coin8);
        c8.setByAngle(180);
        c8.setCycleCount(Animation.INDEFINITE);
        c8.setInterpolator(Interpolator.LINEAR);
    //    c8.setAxis(Rotate.Y_AXIS);
        c8.play();

        c9= new RotateTransition(Duration.millis(3000), coin9);
        c9.setByAngle(180);
        c9.setCycleCount(Animation.INDEFINITE);
        c9.setInterpolator(Interpolator.LINEAR);
    //    c9.setAxis(Rotate.Y_AXIS);
        c9.play();
//        t1test.setNode(heroimg);
//        t1test.setByY(500);
//        t1test.setCycleCount(1);
//        t1test.setDuration(Duration.millis(700));
//        t1test.setAutoReverse(true);
//        heroimg.setCache(true);
//        heroimg.setCacheHint(CacheHint.SPEED);
//        t1.play();

        //SequentialTransition sequentialTransition = new SequentialTransition(t1,t1test );
        //sequentialTransition.play();
        TranslateTransition floatisl1 = new TranslateTransition();
        floatisl1.setNode(isl7);
        floatisl1.setByY(300);
        floatisl1.setCycleCount(TranslateTransition.INDEFINITE);
        floatisl1.setDuration(Duration.millis(5000));
        floatisl1.setAutoReverse(true);
        floatisl1.play();

        TranslateTransition floatisl2 = new TranslateTransition();
        floatisl2.setNode(isl71);
        floatisl2.setByY(100);
        floatisl2.setCycleCount(TranslateTransition.INDEFINITE);
        floatisl2.setDuration(Duration.millis(2500));
        floatisl2.setAutoReverse(true);
        floatisl2.play();

        TranslateTransition floatisl3 = new TranslateTransition();
        floatisl3.setNode(isl72);
        floatisl3.setByY(-200);
        floatisl3.setCycleCount(TranslateTransition.INDEFINITE);
        floatisl3.setDuration(Duration.millis(3000));
        floatisl3.setAutoReverse(true);
        floatisl3.play();
        TranslateTransition floatisl4 = new TranslateTransition();
        floatisl4.setNode(isl73);
        floatisl4.setByY(-100);
        floatisl4.setCycleCount(TranslateTransition.INDEFINITE);
        floatisl4.setDuration(Duration.millis(2500));
        floatisl4.setAutoReverse(true);
        floatisl4.play();
        TranslateTransition floatisl5 = new TranslateTransition();
        floatisl5.setNode(isl74);
        floatisl5.setByY(100);
        floatisl5.setCycleCount(TranslateTransition.INDEFINITE);
        floatisl5.setDuration(Duration.millis(2500));
        floatisl5.setAutoReverse(true);
        floatisl5.play();
        TranslateTransition floatisl6 = new TranslateTransition();
        floatisl6.setNode(isl75);
        floatisl6.setByY(-100);
        floatisl6.setCycleCount(TranslateTransition.INDEFINITE);
        floatisl6.setDuration(Duration.millis(2500));
        floatisl6.setAutoReverse(true);
        floatisl6.play();

        TranslateTransition floatisl7 = new TranslateTransition();
        floatisl7.setNode(isl76);
        floatisl7.setByY(200);
        floatisl7.setCycleCount(TranslateTransition.INDEFINITE);
        floatisl7.setDuration(Duration.millis(2000));
        floatisl7.setAutoReverse(true);
        floatisl7.play();

        t2 = new TranslateTransition();
        t2.setNode(redorc);
        t2.setByY(20);
//        t2.setCycleCount(TranslateTransition.INDEFINITE);
        t2.setDuration(Duration.millis(100));
        t2.setInterpolator(Interpolator.LINEAR);
//        t2.setAutoReverse(true);
//        redorc.setCache(true);
//        redorc.setCacheHint(CacheHint.SPEED);
        t2.play();



        t3 = new TranslateTransition();
        t3.setNode(greenorc);
        t3.setByY(20);
        t3.setDuration(Duration.millis(100));
//        t3.setCycleCount(TranslateTransition.INDEFINITE);
        t3.setInterpolator(Interpolator.LINEAR);
//       t3.setAutoReverse(true);
//        greenorc.setCache(true);
//        greenorc.setCacheHint(CacheHint.SPEED);
        t3.play();

        TranslateTransition t4 = new TranslateTransition();
        t4.setNode(greenorc2);
        t4.setByY(20);
        t4.setInterpolator(Interpolator.LINEAR);
//        t4.setCycleCount(TranslateTransition.INDEFINITE);
        //  t4.setAutoReverse(true);
        t4.play();

        TranslateTransition t5 = new TranslateTransition();
        t5.setNode(greenorc3);
        t5.setByY(20);
        t5.setInterpolator(Interpolator.LINEAR);
//        t5.setCycleCount(TranslateTransition.INDEFINITE);
        // t5.setAutoReverse(true);
        t5.play();

        TranslateTransition t6 = new TranslateTransition();
        t6.setNode(redorc1);
        t6.setByY(20);
        t6.setInterpolator(Interpolator.LINEAR);
//        t6.setCycleCount(TranslateTransition.INDEFINITE);
        // t6.setAutoReverse(true);
        t6.play();

        TranslateTransition t7 = new TranslateTransition();
        t7.setNode(redorc2);
        t7.setByY(20);
        t7.setInterpolator(Interpolator.LINEAR);
//        t7.setCycleCount(TranslateTransition.INDEFINITE);
        //  t7.setAutoReverse(true);
        t7.play();

        TranslateTransition t8 = new TranslateTransition();
        t8.setNode(redorc3);
        t8.setByY(20);
        t8.setInterpolator(Interpolator.LINEAR);
//        t8.setCycleCount(TranslateTransition.INDEFINITE);
        //   t8.setAutoReverse(true);
        t8.play();

        TranslateTransition t9 = new TranslateTransition();
        t9.setNode(redorc4);
        t9.setByY(20);
        t9.setInterpolator(Interpolator.LINEAR);
//        t9.setCycleCount(TranslateTransition.INDEFINITE);
        // t9.setAutoReverse(true);
        t9.play();

        TranslateTransition t10 = new TranslateTransition();
        t10.setNode(redorc5);
        t10.setByY(20);
        t10.setInterpolator(Interpolator.LINEAR);
//        t10.setCycleCount(TranslateTransition.INDEFINITE);
        //   t10.setAutoReverse(true);
        t10.play();

        TranslateTransition t11 = new TranslateTransition();
        t11.setNode(greenorc3);
        t11.setByY(20);
        t11.setInterpolator(Interpolator.LINEAR);
//        t11.setCycleCount(TranslateTransition.INDEFINITE);
        // t11.setAutoReverse(true);
        t11.play();

        TranslateTransition t12 = new TranslateTransition();
        t12.setNode(bigOrc1);
        t12.setByY(20);
        t12.setInterpolator(Interpolator.LINEAR);
//        t12.setCycleCount(TranslateTransition.INDEFINITE);
        //  t12.setAutoReverse(true);
        t12.play();

        TranslateTransition t13 = new TranslateTransition();
        t13.setNode(greenorc4);
        t13.setByY(20);
        t13.setInterpolator(Interpolator.LINEAR);
        t13.setDuration(Duration.millis(40));

//        t13.setCycleCount(TranslateTransition.INDEFINITE);
        // t13.setAutoReverse(true);
        t13.play();

        TranslateTransition t14 = new TranslateTransition();
        t14.setNode(boss);
        t14.setByY(20);
        t14.setInterpolator(Interpolator.LINEAR);
        t14.setDuration(Duration.millis(40));

//        t13.setCycleCount(TranslateTransition.INDEFINITE);
        // t13.setAutoReverse(true);
        t14.play();






    }

    public void exitfromGame(ActionEvent event) throws IOException {

        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("EXIT");
        alert.setHeaderText("You are about to exit from the game.");
        alert.setContentText("If you still wish to exit the game click the OK button.");

        if (alert.showAndWait().get() == ButtonType.OK) {
            URL url = new File("src/main/resources/com/example/willherofxfinal/level1.fxml").toURI().toURL();
            root = FXMLLoader.load(url);
            stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.close();
        }
    }

    public void exitfromGameingame(ActionEvent event) throws IOException {

        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("EXIT");
        alert.setHeaderText("You are about to exit from the game.");
        alert.setContentText("If you still wish to exit the game click the OK button.");

        if (alert.showAndWait().get() == ButtonType.OK) {
            URL url = new File("src/main/resources/com/example/willherofxfinal/level1.fxml").toURI().toURL();
            root = FXMLLoader.load(url);
            stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.close();
        }
    }

    public void pauseMenu(ActionEvent event) throws IOException {
        t1.pause();
        t2.pause();
        t3.pause();
        if(t11.getStatus()== Animation.Status.RUNNING)
        {
            t11.pause();
        }
        pausemenu.setVisible(true);

    }

    public void resume(ActionEvent event) throws IOException {

        if(t11.getStatus()== Animation.Status.PAUSED)
        {
            t11.play();
        }
        t1.play();
        t2.play();
        t3.play();

//        pausemenu.setVisible(false);
    }


    public void move() throws IOException {

        URL url = new File("src/main/resources/com/example/willherofxfinal/level1.fxml").toURI().toURL();
        root = FXMLLoader.load(url);
        scene = new Scene(root);
        test1 = (Button)scene.lookup("#test1");
        test1.setOnKeyPressed(e -> {
            if(e.getCode()==KeyCode.A) {
             //   System.out.println("HELLO");


                try {
                    moveForward();
                } catch (MalformedURLException ex) {
                    ex.printStackTrace();
                }

            }
        });
    }



    public void moveForward() throws MalformedURLException {



      //  orckilled.setVisible(false);

//        this.tbutton =  new TranslateTransition();
//        tbutton.setNode(pause);
//        tbutton.setByX(20);
//        pause.setCache(true);
//        pause.setCacheHint(CacheHint.SPEED);
//        tbutton.play();

        this.tbutton1 =  new TranslateTransition();
        tbutton1.setNode(menu);
        tbutton1.setByX(20);
        menu.setCache(true);
        menu.setCacheHint(CacheHint.SPEED);
        tbutton1.play();

        TranslateTransition tprogbar =  new TranslateTransition();
       tprogbar.setNode(progbar);
       tprogbar.setDuration(Duration.millis(400));
       tprogbar.setByX(120);
       tprogbar.setInterpolator(Interpolator.LINEAR);
       tprogbar.play();

//        TranslateTransition rect1 =  new TranslateTransition();
//        rect1.setNode(rect);
//        rect1.setDuration(Duration.millis(400));
//        rect1.setByX(50);
//        rect1.setInterpolator(Interpolator.LINEAR);
//        rect1.play();
//
//        TranslateTransition inrect1 =  new TranslateTransition();
//        inrect1.setNode(inrect);
//        inrect1.setDuration(Duration.millis(400));
//        inrect1.setByX(50);
//        inrect1.setInterpolator(Interpolator.LINEAR);
//        inrect1.play();

//        TranslateTransition resume11 =  new TranslateTransition();
//        resume11.setNode(resume1);
//        resume11.setDuration(Duration.millis(400));
//        resume11.setByX(50);
//        resume11.setInterpolator(Interpolator.LINEAR);
//        resume11.play();

//        TranslateTransition resume111 =  new TranslateTransition();
//        resume111.setNode(load);
//        resume111.setDuration(Duration.millis(400));
//        resume111.setByX(50);
//        resume111.setInterpolator(Interpolator.LINEAR);
//        resume111.play();

//        TranslateTransition resume1111 =  new TranslateTransition();
//        resume1111.setNode(save);
//        resume1111.setDuration(Duration.millis(400));
//        resume1111.setByX(50);
//        resume1111.setInterpolator(Interpolator.LINEAR);
//        resume1111.play();

        TranslateTransition tproglabel =  new TranslateTransition();
        tproglabel.setNode(proglabel);
        tproglabel.setDuration(Duration.millis(400));
        tproglabel.setByX(120);
        tproglabel.setInterpolator(Interpolator.LINEAR);
        tproglabel.play();

//        TranslateTransition save1 =  new TranslateTransition();
//        save1.setNode(one_save);
//        save1.setDuration(Duration.millis(400));
//        save1.setByX(120);
//        save1.setInterpolator(Interpolator.LINEAR);
//        save1.play();
//
//        TranslateTransition yes1 =  new TranslateTransition();
//        yes1.setNode(one_save);
//        yes1.setDuration(Duration.millis(400));
//        yes1.setByX(120);
//        yes1.setInterpolator(Interpolator.LINEAR);
//        yes1.play();
//
//        TranslateTransition no1 =  new TranslateTransition();
//        no1.setNode(one_save);
//        no1.setDuration(Duration.millis(400));
//        no1.setByX(120);
//        no1.setInterpolator(Interpolator.LINEAR);
//        no1.play();
//
//        TranslateTransition save2 =  new TranslateTransition();
//        save2.setNode(two_save);
//        save2.setDuration(Duration.millis(400));
//        save2.setByX(100);
//        save2.setInterpolator(Interpolator.LINEAR);
//        save2.play();
//
//        TranslateTransition load1 =  new TranslateTransition();
//        load1.setNode(one_load);
//        load1.setDuration(Duration.millis(400));
//        load1.setByX(100);
//        load1.setInterpolator(Interpolator.LINEAR);
//        load1.play();
//
//        TranslateTransition load2 =  new TranslateTransition();
//        load2.setNode(two_load);
//        load2.setDuration(Duration.millis(400));
//        load2.setByX(100);
//        load2.setInterpolator(Interpolator.LINEAR);
//        load2.play();

//        TranslateTransition ryes1 =  new TranslateTransition();
//        ryes1.setNode(ryes);
//        ryes1.setDuration(Duration.millis(400));
//        ryes1.setByX(100);
//        ryes1.setInterpolator(Interpolator.LINEAR);
//        ryes1.play();
//
//        TranslateTransition rno1 =  new TranslateTransition();
//        rno1.setNode(rno);
//        rno1.setDuration(Duration.millis(400));
//        rno1.setByX(100);
//        rno1.setInterpolator(Interpolator.LINEAR);
//        rno1.play();


        TranslateTransition tcoinbar =  new TranslateTransition();
        tcoinbar.setNode(cntrimg);
        tcoinbar.setDuration(Duration.millis(400));
        tcoinbar.setByX(120);
        tcoinbar.setInterpolator(Interpolator.LINEAR);
        tcoinbar.play();

        TranslateTransition tcoinlabel =  new TranslateTransition();
        tcoinlabel.setNode(cntrlabel);
        tcoinlabel.setDuration(Duration.millis(400));
        tcoinlabel.setByX(120);
        tcoinlabel.setInterpolator(Interpolator.LINEAR);
        tcoinlabel.play();

        TranslateTransition menuimg1 =  new TranslateTransition();
        menuimg1.setNode(menuimg);
        menuimg1.setDuration(Duration.millis(400));
        menuimg1.setByX(120);
        menuimg1.setInterpolator(Interpolator.LINEAR);
        menuimg1.play();

        TranslateTransition tt1 =  new TranslateTransition();
        tt1.setNode(pauseimg);
        tt1.setDuration(Duration.millis(400));
        tt1.setByX(120);
        tt1.setInterpolator(Interpolator.LINEAR);
        tt1.play();

        TranslateTransition h =  new TranslateTransition();
        h.setNode(heart);
        h.setDuration(Duration.millis(400));
        h.setByX(120);
        h.setInterpolator(Interpolator.LINEAR);
        h.play();

        TranslateTransition hl =  new TranslateTransition();
        hl.setNode(heartlabel);
        hl.setDuration(Duration.millis(400));
        hl.setByX(120);
        hl.setInterpolator(Interpolator.LINEAR);
        hl.play();

        TranslateTransition bg =  new TranslateTransition();
        bg.setNode(bgnight);
        bg.setDuration(Duration.millis(400));
        bg.setByX(120);
        bg.setInterpolator(Interpolator.LINEAR);
        bg.play();

        TranslateTransition t2 = new TranslateTransition();
        t2.setNode(rect);
        t2.setByX(120);
        // camera.setCache(true);
        // camera.setCacheHint(CacheHint.SPEED);
        t2.setInterpolator(Interpolator.LINEAR);
        t2.setDuration(Duration.millis(400));
        t2.play();

        TranslateTransition t3 = new TranslateTransition();
        t3.setNode(respbox);
        t3.setByX(120);
        // camera.setCache(true);
        // camera.setCacheHint(CacheHint.SPEED);
        t3.setInterpolator(Interpolator.LINEAR);
        t3.setDuration(Duration.millis(400));
        t3.play();





    }

    public void moveUP()
    {
        //System.out.println("UP");
    }

    public void loadhero() throws IOException, ClassNotFoundException {
        deser_save();
    }

int count=0;
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {


    }

//    AnimationTimer collisionTimer = new AnimationTimer() {
//        @Override
//        public void handle(long l) {
//
//            try {
//                checkCollision(heroimg);
//            } catch (InterruptedException e) {
//                e.printStackTrace();
//            }
//        }
//    };

    public void checkCollision(ImageView a) throws InterruptedException {

        for( ImageView x : isl)
        {
            if(heroimg.getBoundsInParent().intersects(x.getBoundsInParent())){


                sequentialTransition.stop();
                //System.out.println("HELLO");


            }}
        for( ImageView x : islands){
            if(a.getBoundsInParent().intersects(x.getBoundsInParent())){

                dead.fire();

            }}
        for( ImageView x : orcs){
            if(a.getBoundsInParent().intersects(pausemenu.localToParent(x.getBoundsInParent()))){

                orctoimg.get(x).setVisible(false);
            //    orckilled.setVisible(true);

            }}

        //orckilled.setVisible(true);

    }
    public void testfunc(ActionEvent event) throws IOException, InterruptedException {

        t1.stop();
        TranslateTransition t4 = new TranslateTransition();
        t4.setNode(heroimg);
        t4.setDuration(Duration.millis(100));
        t4.setByY(500);
        t4.play();

        if(t4.getStatus()==Animation.Status.STOPPED){

            URL url3 = new File("src/main/resources/com/example/willherofxfinal/deadhero.fxml").toURI().toURL();
            root = FXMLLoader.load(url3);
            stage1 = (Stage) ((Node) event.getSource()).getScene().getWindow();
            Scene scene1 = new Scene(root);
            stage1.setScene(scene1);
            stage1.show();}

    }


}

//<ImageView fx:id="abyss" fitHeight="150.0" fitWidth="4000.0" layoutX="57.0" layoutY="733.0" pickOnBounds="true" preserveRatio="true" />




