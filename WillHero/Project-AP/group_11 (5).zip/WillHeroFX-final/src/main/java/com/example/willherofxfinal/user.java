package com.example.willherofxfinal;

import javafx.animation.ParallelTransition;

public class user {
    hero player;
    long score;
    Game newgame;

    public void play()
    {

    }
    public void pause()
    {

    }
    public void resume()
    {

    }
    public void respawn()
    {

    }
    public void restart()
    {

    }
    public long viewhighs()
    {
        return this.score;
    }
    public void setHero(hero Hero)
    {
        this.player=Hero;
    }
    public void setGame(Game g)
    {
        this.newgame=g;
    }

}
