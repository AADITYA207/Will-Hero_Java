package com.example.willherofxfinal;

public class tnt extends obstacles {

    int damage;
    int radius;

    tnt(long id, String type, float x, float y, int x1, int y1) {
        super(id, type, x, y);
        damage=x1;
        radius=y1;
    }
}
