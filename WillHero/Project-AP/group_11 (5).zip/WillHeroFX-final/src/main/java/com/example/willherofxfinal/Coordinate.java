package com.example.willherofxfinal;

public class Coordinate{
    float x;
    float y;
    Coordinate(float x, float y){
        this.x=x;
        this.y=y;
    }
    public void addx(float x){
        this.x+=x;
    }
    public void addy(float x){
        this.y+=x;
    }
}