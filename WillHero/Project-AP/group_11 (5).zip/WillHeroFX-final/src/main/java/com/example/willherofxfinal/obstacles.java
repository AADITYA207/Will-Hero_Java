package com.example.willherofxfinal;

public class obstacles extends gameObjects {

    public static gameObjects getInstance(String g, long id, String type, float x, float y, float l, float h )
    {

        if(!instances.containsKey(g))
        {
            instances.put(g, new obstacles(id, type, x, y));
        }
        return instances.get(g);
    }

     obstacles(long id, String type, float x, float y) {
        super(id, type, x, y);
    }

    @Override
    public boolean collision(hero h, Coordinate c) {
        return false;
    }
}
