package com.example.willherofxfinal;

public class island extends gameObjects {
    float length;
    float height;

    public static gameObjects getInstance(String g, long id, String type, float x, float y, float l, float h )
    {

        if(!instances.containsKey(g))
        {
            instances.put(g, new island(id, type, x, y,l,h));
        }
        return instances.get(g);
    }

   private island(long id, String type, float x, float y, float l, float h) {
        super(id, type, x, y);
        length=l;
        height=h;
    }

    @Override
    public boolean collision(hero h, Coordinate c) {
        return collision(h,c);
    }
}
