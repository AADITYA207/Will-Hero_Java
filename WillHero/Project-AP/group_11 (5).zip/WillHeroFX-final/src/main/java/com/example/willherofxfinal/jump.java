package com.example.willherofxfinal;

public interface jump {
    public void jump();
}
