package com.example.willherofxfinal;

public class helmet extends weapchest{
    weapons w1=null;
    weapons w2=null;

    helmet(long id, String type, float x, float y, float xspeed) {
        super(id, type, x, y, xspeed);
        this.w1=w1;
        this.w2=w2;
    }

    public void setweapon1(weapons w)
    {
        this.w1=w;
    }
    public void setweapon2(weapons w)
    {
        this.w2=w;
    }
}
class weapons extends helmet implements fire {

    float damage;
    String name;

    weapons(long id, String type, float x, float y,float xspeed, float damage, String name){

        super(id,type,x,y,xspeed);
        this.damage=damage;
        this.name=name;
    }
    public void fire()
    {
        Coordinate c = super.getCoord();
        c.addx(50);
        super.setCoord(c.x,c.y);
    }
    public void hurtOrc(float damage, orc o1)
    {
        if(this.getCoord().x==o1.getCoord().x)
        {
            float l=o1.getLife();
            if(l>0){l=l-damage;
            o1.setLife(l);}
        }
    }
    public void upgrade(weapons w)
    {
        this.damage++;
        this.name="Upgraded"+this.name;
    }
}
