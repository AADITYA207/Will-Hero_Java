package com.example.willherofxfinal;

public class coinchest extends treasure{



    coinchest(long id, String type, float x, float y, float xspeed) {
        super(id, type, x, y, xspeed);
    }

    public boolean collision(hero h)
    {
        return super.collision(h);
    }


}
