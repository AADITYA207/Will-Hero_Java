package com.example.willherofxfinal;

import java.util.ArrayList;

public class hero extends gameObjects implements jump{

    private float xspeed;
    private ArrayList<weapons> weaponsList = new ArrayList<weapons>();
    private helmet h;
    private int coinsCollected;

    public static gameObjects getInstance(String g, long id, String type, float x, float y, float xspeed)
    {

        if(!instances.containsKey(g))
        {
            instances.put(g, new hero(id, type, x, y, xspeed));
        }
        return instances.get(g);
    }

    private hero(long id, String type, float x, float y, float xspeed){

        super(id,type,x,y);
        this.xspeed=xspeed;
        this.coinsCollected=0;

    }
    public helmet getH(){
        return this.h;
    }
    public int getCoinsCollected(){
        return this.coinsCollected;
    }

    @Override
    public boolean collision(hero h, Coordinate c) {
        double x = h.getX();
        double y = h.getY();
        if(x==c.x || y==c.y)
        {
            return true;
        }
        return false;
    }


    public void jump()
    {
        Coordinate c = super.getCoord();
        c.addx(120);
        super.setCoord(c.x,c.y);
    }
    public void setCoinsCollected(int c)
    {
        this.coinsCollected+=c;
    }
    public void useWeapon(long x)
    {
        for(weapons w : weaponsList)
        {
            if(w.getObjId()==x)
            {
                w.fire();
            }
        }
    }
}
